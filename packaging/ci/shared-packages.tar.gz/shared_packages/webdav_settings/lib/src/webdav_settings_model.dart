enum ExternalStorageMode { localOnly, webDav }

enum WebDavSyncStatus { notConfigured, syncing, synced, failed, conflict }

class WebDavSettings {
  const WebDavSettings({
    this.mode = ExternalStorageMode.localOnly,
    this.baseUrl = '',
    this.username = '',
    this.password = '',
  });

  final ExternalStorageMode mode;
  final String baseUrl;
  final String username;
  final String password;

  bool get isComplete => baseUrl.trim().isNotEmpty;

  WebDavSettings copyWith({
    ExternalStorageMode? mode,
    String? baseUrl,
    String? username,
    String? password,
  }) {
    return WebDavSettings(
      mode: mode ?? this.mode,
      baseUrl: baseUrl ?? this.baseUrl,
      username: username ?? this.username,
      password: password ?? this.password,
    );
  }

  String get connectionFingerprint =>
      [baseUrl.trim(), username.trim(), password].join('\u0000');
}

class WebDavSyncPresentation {
  const WebDavSyncPresentation({
    this.status = WebDavSyncStatus.notConfigured,
    this.lastSuccessfulSync,
    this.detail,
  });

  final WebDavSyncStatus status;
  final DateTime? lastSuccessfulSync;
  final String? detail;
}
