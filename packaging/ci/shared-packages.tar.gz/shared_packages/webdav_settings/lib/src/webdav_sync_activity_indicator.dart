import 'package:flutter/material.dart';

import 'webdav_settings_model.dart';
import 'webdav_sync_status_icons.dart';

/// A compact global sync affordance for an app shell or toolbar.
///
/// By default the 48 logical-pixel slot remains reserved for backwards
/// compatibility. Apps with a compact action bar can set [collapseWhenIdle]
/// so the indicator occupies no width when it is idle, then expands smoothly
/// in place when syncing or reporting a problem. Following actions participate
/// in the same animation instead of leaving the indicator pinned to the far
/// right edge of the toolbar.
class WebDavSyncActivityIndicator extends StatefulWidget {
  const WebDavSyncActivityIndicator({
    super.key,
    required this.presentation,
    this.onSyncNow,
    this.onOpenConflicts,
    this.size = 48,
    this.collapseWhenIdle = false,
  });

  final WebDavSyncPresentation presentation;
  final Future<void> Function()? onSyncNow;
  final VoidCallback? onOpenConflicts;
  final double size;
  final bool collapseWhenIdle;

  @override
  State<WebDavSyncActivityIndicator> createState() =>
      _WebDavSyncActivityIndicatorState();
}

class _WebDavSyncActivityIndicatorState
    extends State<WebDavSyncActivityIndicator>
    with SingleTickerProviderStateMixin {
  late final AnimationController _rotation = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );

  @override
  void initState() {
    super.initState();
    _updateRotation();
  }

  @override
  void didUpdateWidget(covariant WebDavSyncActivityIndicator oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.presentation.status != widget.presentation.status) {
      _updateRotation();
    }
  }

  bool _reduceMotion = false;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _reduceMotion = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    _updateRotation();
  }

  void _updateRotation() {
    if (widget.presentation.status == WebDavSyncStatus.syncing &&
        !_reduceMotion) {
      _rotation.repeat();
    } else {
      _rotation.stop();
      _rotation.value = 0;
    }
  }

  @override
  void dispose() {
    _rotation.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final status = widget.presentation.status;
    final Widget child = switch (status) {
      WebDavSyncStatus.syncing => IconButton(
        key: const ValueKey('webdav-syncing'),
        onPressed: null,
        tooltip: widget.presentation.detail ?? '正在同步',
        disabledColor: Theme.of(context).colorScheme.primary,
        icon: RotationTransition(
          turns: _rotation,
          child: const Icon(Icons.sync),
        ),
      ),
      WebDavSyncStatus.conflict => IconButton(
        key: const ValueKey('webdav-conflict'),
        onPressed: widget.onOpenConflicts,
        tooltip: widget.presentation.detail ?? '存在同步冲突',
        icon: const WebDavSyncStatusIcon(status: WebDavSyncStatus.conflict),
      ),
      WebDavSyncStatus.failed => IconButton(
        key: const ValueKey('webdav-failed'),
        onPressed: widget.onSyncNow,
        tooltip: widget.presentation.detail ?? '同步失败，点击重试',
        color: Theme.of(context).colorScheme.error,
        icon: const Icon(Icons.cloud_off_outlined),
      ),
      WebDavSyncStatus.notConfigured || WebDavSyncStatus.synced =>
        const SizedBox.shrink(key: ValueKey('webdav-sync-idle')),
    };

    final isIdle =
        status == WebDavSyncStatus.notConfigured ||
        status == WebDavSyncStatus.synced;
    return AnimatedSize(
      duration: _reduceMotion
          ? Duration.zero
          : const Duration(milliseconds: 180),
      curve: Curves.easeOut,
      // Keep the indicator's leading edge anchored to the title/action group.
      // When it becomes active, its width grows toward the following actions;
      // when it becomes idle, those actions glide back into place with it.
      alignment: Alignment.centerLeft,
      child: SizedBox(
        width: widget.collapseWhenIdle && isIdle ? 0 : widget.size,
        height: widget.size,
        child: AnimatedSwitcher(
          duration: _reduceMotion
              ? Duration.zero
              : const Duration(milliseconds: 180),
          switchInCurve: Curves.easeOut,
          switchOutCurve: Curves.easeIn,
          child: child,
        ),
      ),
    );
  }
}
