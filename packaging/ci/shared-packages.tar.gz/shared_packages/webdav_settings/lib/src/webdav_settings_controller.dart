import 'package:flutter/foundation.dart';

import 'webdav_connection_tester.dart';
import 'webdav_settings_model.dart';
import 'webdav_settings_store.dart';

class WebDavSettingsController extends ChangeNotifier {
  WebDavSettingsController({
    required this.store,
    required this.connectionTester,
    this.legacySettings,
  });

  final WebDavSettingsStore store;
  final WebDavConnectionTester connectionTester;
  final WebDavSettings? legacySettings;

  WebDavSettings _saved = const WebDavSettings();
  WebDavSettings _draft = const WebDavSettings();
  WebDavConnectionTestResult? _testResult;
  String? _testedFingerprint;
  bool _isLoaded = false;
  bool _isTesting = false;
  bool _isSaving = false;
  bool _hasLegacyConfiguration = false;

  WebDavSettings get saved => _saved;
  WebDavSettings get draft => _draft;
  WebDavConnectionTestResult? get testResult => _testResult;
  bool get isLoaded => _isLoaded;
  bool get isTesting => _isTesting;
  bool get isSaving => _isSaving;
  bool get hasLegacyConfiguration => _hasLegacyConfiguration;
  bool get canEnableWebDav =>
      _testResult?.isSuccess == true &&
      _testedFingerprint == _draft.connectionFingerprint;

  Future<void> load() async {
    if (_isLoaded) return;
    final stored = await store.load();
    if (stored != null) {
      _saved = stored;
      _draft = stored;
    } else if (legacySettings?.isComplete ?? false) {
      _draft = legacySettings!.copyWith(mode: ExternalStorageMode.webDav);
      _hasLegacyConfiguration = true;
    }
    _isLoaded = true;
    notifyListeners();
  }

  void updateDraft(WebDavSettings settings) {
    _draft = settings;
    if (_testedFingerprint != settings.connectionFingerprint) {
      _testResult = null;
    }
    notifyListeners();
  }

  Future<WebDavConnectionTestResult> testConnection() async {
    _isTesting = true;
    _testResult = null;
    notifyListeners();
    final fingerprint = _draft.connectionFingerprint;
    try {
      final result = await connectionTester.test(_draft);
      _testResult = result;
      _testedFingerprint = result.isSuccess ? fingerprint : null;
      return result;
    } finally {
      _isTesting = false;
      notifyListeners();
    }
  }

  Future<WebDavSettings> enableWebDav() async {
    if (!canEnableWebDav) {
      throw StateError('请先使用当前配置测试连接');
    }
    return _save(_draft.copyWith(mode: ExternalStorageMode.webDav));
  }

  Future<WebDavSettings> useLocalOnly() {
    return _save(_draft.copyWith(mode: ExternalStorageMode.localOnly));
  }

  /// Persists an explicitly imported configuration without issuing a request.
  /// A changed connection is unverified; callers can test and enable it later.
  Future<WebDavSettings> saveConfiguration(WebDavSettings settings) async {
    if (_isSaving || _isTesting) {
      throw StateError('WebDAV configuration is busy');
    }
    _testResult = null;
    _testedFingerprint = null;
    return _save(settings);
  }

  Future<WebDavSettings> _save(WebDavSettings settings) async {
    _isSaving = true;
    notifyListeners();
    try {
      await store.save(settings);
      _saved = settings;
      _draft = settings;
      _hasLegacyConfiguration = false;
      return settings;
    } finally {
      _isSaving = false;
      notifyListeners();
    }
  }
}
