import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'webdav_settings_model.dart';

abstract interface class WebDavSettingsStore {
  Future<WebDavSettings?> load();

  Future<void> save(WebDavSettings settings);
}

class SecureWebDavSettingsStore implements WebDavSettingsStore {
  SecureWebDavSettingsStore({
    required this.appId,
    FlutterSecureStorage? secureStorage,
  }) : _secureStorage = secureStorage ?? const FlutterSecureStorage();

  final String appId;
  final FlutterSecureStorage _secureStorage;

  String get _prefix => 'webdav_settings.$appId';
  String get _modeKey => '$_prefix.mode';
  String get _urlKey => '$_prefix.url';
  String get _usernameKey => '$_prefix.username';
  String get _passwordKey => '$_prefix.password';

  @override
  Future<WebDavSettings?> load() async {
    final preferences = await SharedPreferences.getInstance();
    final storedMode = preferences.getString(_modeKey);
    final url = preferences.getString(_urlKey);
    final username = preferences.getString(_usernameKey);
    if (storedMode == null && url == null && username == null) {
      return null;
    }
    final password = await _secureStorage.read(key: _passwordKey);
    return WebDavSettings(
      mode: ExternalStorageMode.values.firstWhere(
        (mode) => mode.name == storedMode,
        orElse: () => ExternalStorageMode.localOnly,
      ),
      baseUrl: url ?? '',
      username: username ?? '',
      password: password ?? '',
    );
  }

  @override
  Future<void> save(WebDavSettings settings) async {
    final preferences = await SharedPreferences.getInstance();
    final results = await Future.wait<bool>([
      preferences.setString(_modeKey, settings.mode.name),
      preferences.setString(_urlKey, settings.baseUrl.trim()),
      preferences.setString(_usernameKey, settings.username.trim()),
    ]);
    if (results.any((saved) => !saved)) {
      throw StateError('WebDAV 设置保存失败');
    }
    if (settings.password.isEmpty) {
      await _secureStorage.delete(key: _passwordKey);
    } else {
      await _secureStorage.write(key: _passwordKey, value: settings.password);
    }
  }
}
