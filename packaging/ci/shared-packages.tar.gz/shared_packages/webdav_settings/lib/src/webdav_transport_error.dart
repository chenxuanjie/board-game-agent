export 'webdav_transport_error_stub.dart'
    if (dart.library.io) 'webdav_transport_error_io.dart';
