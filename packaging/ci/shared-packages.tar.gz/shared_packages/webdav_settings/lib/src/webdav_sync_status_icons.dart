import 'package:flutter/material.dart';

import 'webdav_settings_model.dart';

/// Renders the canonical icon used for a WebDAV synchronization status.
///
/// The conflict state intentionally uses the original cloud-plus-yellow-badge
/// treatment instead of a generic red warning triangle.
class WebDavSyncStatusIcon extends StatelessWidget {
  const WebDavSyncStatusIcon({super.key, required this.status});

  final WebDavSyncStatus status;

  @override
  Widget build(BuildContext context) => switch (status) {
    WebDavSyncStatus.conflict => const WebDavSyncConflictIcon(),
    _ => Icon(webDavSyncStatusIconData(status)),
  };
}

/// The original cloud icon with a yellow exclamation badge used by Zheri.
class WebDavSyncConflictIcon extends StatelessWidget {
  const WebDavSyncConflictIcon({super.key});

  @override
  Widget build(BuildContext context) => Stack(
    clipBehavior: Clip.none,
    children: [
      const Icon(Icons.cloud_outlined),
      Positioned(
        right: -2,
        top: -5,
        child: Container(
          width: 15,
          height: 15,
          alignment: Alignment.center,
          decoration: const BoxDecoration(
            color: Color(0xFFFFC44D),
            shape: BoxShape.circle,
          ),
          child: const Text(
            '!',
            style: TextStyle(
              color: Color(0xFF1D1A17),
              fontSize: 10,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
        ),
      ),
    ],
  );
}

/// Returns the base Material icon for statuses that do not need a composite
/// treatment. Conflict is rendered by [WebDavSyncConflictIcon].
IconData webDavSyncStatusIconData(WebDavSyncStatus status) => switch (status) {
  WebDavSyncStatus.notConfigured => Icons.cloud_off_outlined,
  WebDavSyncStatus.syncing => Icons.sync,
  WebDavSyncStatus.synced => Icons.cloud_done_outlined,
  WebDavSyncStatus.failed => Icons.cloud_off_outlined,
  WebDavSyncStatus.conflict => Icons.cloud_outlined,
};
