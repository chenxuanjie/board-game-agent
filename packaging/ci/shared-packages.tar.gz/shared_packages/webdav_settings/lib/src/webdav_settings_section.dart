import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'webdav_settings_controller.dart';
import 'webdav_settings_model.dart';
import 'webdav_sync_status_icons.dart';

typedef WebDavSettingsChanged = Future<void> Function(WebDavSettings settings);

class WebDavSettingsSection extends StatefulWidget {
  const WebDavSettingsSection({
    super.key,
    required this.controller,
    required this.presentation,
    required this.onSettingsChanged,
    this.onSyncNow,
    this.webDavLabel = 'WebDAV 同步',
    this.useThemeStyle = false,
    this.baseUrlSuggestions = const [],
    this.usernameSuggestions = const [],
    this.conflictCount = 0,
    this.onOpenConflicts,
  });

  final WebDavSettingsController controller;
  final WebDavSyncPresentation presentation;
  final WebDavSettingsChanged onSettingsChanged;
  final Future<void> Function()? onSyncNow;
  final String webDavLabel;
  final bool useThemeStyle;
  final List<String> baseUrlSuggestions;
  final List<String> usernameSuggestions;
  final int conflictCount;
  final VoidCallback? onOpenConflicts;

  @override
  State<WebDavSettingsSection> createState() => _WebDavSettingsSectionState();
}

class _WebDavSettingsSectionState extends State<WebDavSettingsSection> {
  final _url = TextEditingController();
  TextEditingController? _expandedPreset;
  final _username = TextEditingController();
  final _password = TextEditingController();
  bool _obscurePassword = true;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_controllerChanged);
    _controllerChanged();
    if (!widget.controller.isLoaded) {
      widget.controller.load().catchError(_showError);
    }
  }

  @override
  void didUpdateWidget(covariant WebDavSettingsSection oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_controllerChanged);
      widget.controller.addListener(_controllerChanged);
      _controllerChanged();
      if (!widget.controller.isLoaded) {
        widget.controller.load().catchError(_showError);
      }
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_controllerChanged);
    _url.dispose();
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  void _controllerChanged() {
    if (!mounted) return;
    final draft = widget.controller.draft;
    _setText(_url, draft.baseUrl);
    _setText(_username, draft.username);
    _setText(_password, draft.password);
    setState(() {});
  }

  void _setText(TextEditingController controller, String value) {
    if (controller.text == value) return;
    controller.value = TextEditingValue(
      text: value,
      selection: TextSelection.collapsed(offset: value.length),
    );
  }

  void _updateDraft() {
    widget.controller.updateDraft(
      widget.controller.draft.copyWith(
        baseUrl: _url.text,
        username: _username.text,
        password: _password.text,
      ),
    );
  }

  void _closePreset() {
    if (_expandedPreset != null) setState(() => _expandedPreset = null);
  }

  Widget _presetField({
    required String label,
    required TextEditingController field,
    required List<String> suggestions,
    String? hint,
    TextInputType? keyboardType,
  }) {
    final theme = Theme.of(context);
    final expanded = _expandedPreset == field;
    final decoration = theme.inputDecorationTheme;
    final normalBorder = widget.useThemeStyle
        ? decoration.enabledBorder ?? decoration.border
        : const OutlineInputBorder();
    final radius = normalBorder is OutlineInputBorder
        ? normalBorder.borderRadius
        : BorderRadius.circular(12);
    InputBorder? joinedBorder(InputBorder? border) =>
        expanded && border is OutlineInputBorder
        ? border.copyWith(
            borderRadius: BorderRadius.only(
              topLeft: radius.topLeft,
              topRight: radius.topRight,
            ),
          )
        : border;
    return CallbackShortcuts(
      bindings: {
        const SingleActivator(LogicalKeyboardKey.escape): _closePreset,
      },
      child: TapRegion(
        onTapOutside: (_) {
          // An inactive sibling must not close this field before its arrow
          // handles the same pointer event, otherwise the toggle reopens it.
          if (_expandedPreset == field) _closePreset();
        },
        child: Column(
          key: ValueKey('preset-field-$label'),
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: field,
              keyboardType: keyboardType,
              autocorrect: false,
              decoration: InputDecoration(
                labelText: label,
                hintText: hint,
                hoverColor: expanded ? decoration.fillColor : null,
                border: joinedBorder(
                  widget.useThemeStyle
                      ? decoration.border
                      : const OutlineInputBorder(),
                ),
                enabledBorder: joinedBorder(normalBorder),
                focusedBorder: joinedBorder(
                  widget.useThemeStyle
                      ? decoration.focusedBorder
                      : const OutlineInputBorder(),
                ),
                suffixIcon: suggestions.isEmpty
                    ? null
                    : IconButton(
                        tooltip: '选择$label',
                        icon: Icon(
                          expanded
                              ? Icons.keyboard_arrow_up
                              : Icons.keyboard_arrow_down,
                        ),
                        onPressed:
                            widget.controller.isSaving ||
                                widget.controller.isTesting
                            ? null
                            : () {
                                FocusManager.instance.primaryFocus?.unfocus();
                                setState(
                                  () => _expandedPreset =
                                      _expandedPreset == field ? null : field,
                                );
                              },
                      ),
              ),
              onChanged: (_) => _updateDraft(),
            ),
            if (expanded)
              Material(
                color: decoration.fillColor ?? theme.colorScheme.surface,
                borderRadius: BorderRadius.only(
                  bottomLeft: radius.bottomLeft,
                  bottomRight: radius.bottomRight,
                ),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Divider(
                      height: 1,
                      thickness: .5,
                      indent: 16,
                      endIndent: 16,
                      color: theme.colorScheme.outlineVariant,
                    ),
                    for (final value in suggestions.toSet())
                      Semantics(
                        selected: field.text == value,
                        child: InkWell(
                          key: ValueKey('preset-option-$label-$value'),
                          onTap: () {
                            _setText(field, value);
                            _closePreset();
                            _updateDraft();
                          },
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(minHeight: 48),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 12,
                              ),
                              child: Text(
                                value,
                                style: theme.textTheme.bodyLarge,
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectMode(ExternalStorageMode mode) async {
    widget.controller.updateDraft(widget.controller.draft.copyWith(mode: mode));
    if (mode != ExternalStorageMode.localOnly) return;
    try {
      final settings = await widget.controller.useLocalOnly();
      await widget.onSettingsChanged(settings);
    } catch (error) {
      _showError(error);
    }
  }

  Future<void> _testConnection() async {
    _updateDraft();
    try {
      await widget.controller.testConnection();
    } catch (error) {
      _showError(error);
    }
  }

  Future<void> _enableWebDav() async {
    try {
      final settings = await widget.controller.enableWebDav();
      await widget.onSettingsChanged(settings);
    } catch (error) {
      _showError(error);
    }
  }

  void _showError(Object error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text('$error')));
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    if (!controller.isLoaded) {
      return const Center(child: CircularProgressIndicator());
    }
    final showWebDav = controller.draft.mode == ExternalStorageMode.webDav;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('外部存储', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        DropdownButtonFormField<ExternalStorageMode>(
          key: ValueKey(controller.draft.mode),
          initialValue: controller.draft.mode,
          isExpanded: true,
          decoration: InputDecoration(
            labelText: '存储方式',
            border: widget.useThemeStyle ? null : const OutlineInputBorder(),
          ),
          items: [
            DropdownMenuItem(
              value: ExternalStorageMode.localOnly,
              child: Row(
                children: [
                  Icon(Icons.phone_android_outlined, size: 20),
                  SizedBox(width: 10),
                  Text('仅本地'),
                ],
              ),
            ),
            DropdownMenuItem(
              value: ExternalStorageMode.webDav,
              child: Row(
                children: [
                  Icon(Icons.cloud_outlined, size: 20),
                  SizedBox(width: 10),
                  Text(widget.webDavLabel),
                ],
              ),
            ),
          ],
          onChanged: controller.isSaving
              ? null
              : (mode) {
                  if (mode != null) _selectMode(mode);
                },
        ),
        if (showWebDav) ...[
          const SizedBox(height: 20),
          _presetField(
            label: 'WebDAV 地址',
            field: _url,
            suggestions: widget.baseUrlSuggestions,
            keyboardType: TextInputType.url,
            hint: 'https://example.com/webdav/',
          ),
          const SizedBox(height: 12),
          _presetField(
            label: '账号',
            field: _username,
            suggestions: widget.usernameSuggestions,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _password,
            obscureText: _obscurePassword,
            autocorrect: false,
            enableSuggestions: false,
            decoration: InputDecoration(
              labelText: '密码',
              border: widget.useThemeStyle ? null : const OutlineInputBorder(),
              suffixIcon: IconButton(
                onPressed: () =>
                    setState(() => _obscurePassword = !_obscurePassword),
                tooltip: _obscurePassword ? '显示密码' : '隐藏密码',
                icon: Icon(
                  _obscurePassword
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                ),
              ),
            ),
            onChanged: (_) => _updateDraft(),
          ),
          if (controller.hasLegacyConfiguration) ...[
            const SizedBox(height: 12),
            const _Notice(
              icon: Icons.move_to_inbox_outlined,
              text: '已读取旧版编译配置，请测试连接后保存到设置。',
            ),
          ],
          if (controller.testResult case final result?) ...[
            const SizedBox(height: 12),
            _Notice(
              icon: result.isSuccess
                  ? Icons.check_circle_outline
                  : Icons.error_outline,
              text: result.message,
              isError: !result.isSuccess,
            ),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: controller.isTesting || controller.isSaving
                      ? null
                      : _testConnection,
                  icon: controller.isTesting
                      ? const SizedBox.square(
                          dimension: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.wifi_tethering),
                  label: const Text('测试连接'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  onPressed: controller.canEnableWebDav && !controller.isSaving
                      ? _enableWebDav
                      : null,
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('保存并启用'),
                ),
              ),
            ],
          ),
          if (controller.saved.mode == ExternalStorageMode.webDav) ...[
            const SizedBox(height: 24),
            _SyncStatus(
              presentation: widget.presentation,
              onSyncNow: widget.onSyncNow,
              conflictCount: widget.conflictCount,
              onOpenConflicts: widget.onOpenConflicts,
            ),
          ],
        ],
      ],
    );
  }
}

class _Notice extends StatelessWidget {
  const _Notice({required this.icon, required this.text, this.isError = false});

  final IconData icon;
  final String text;
  final bool isError;

  @override
  Widget build(BuildContext context) {
    final color = isError
        ? Theme.of(context).colorScheme.error
        : Theme.of(context).colorScheme.primary;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 19, color: color),
        const SizedBox(width: 8),
        Expanded(
          child: Text(text, style: TextStyle(color: color)),
        ),
      ],
    );
  }
}

class _SyncStatus extends StatelessWidget {
  const _SyncStatus({
    required this.presentation,
    this.onSyncNow,
    this.conflictCount = 0,
    this.onOpenConflicts,
  });

  final WebDavSyncPresentation presentation;
  final Future<void> Function()? onSyncNow;
  final int conflictCount;
  final VoidCallback? onOpenConflicts;

  @override
  Widget build(BuildContext context) {
    final label = switch (presentation.status) {
      WebDavSyncStatus.notConfigured => '未配置',
      WebDavSyncStatus.syncing => '正在同步',
      WebDavSyncStatus.synced => '已同步',
      WebDavSyncStatus.failed => '同步失败',
      WebDavSyncStatus.conflict => '存在冲突',
    };
    final lastSync = presentation.lastSuccessfulSync;
    final subtitle =
        presentation.detail ??
        (lastSync == null ? null : '最近同步：${_formatDateTime(lastSync)}');
    return Row(
      children: [
        WebDavSyncStatusIcon(status: presentation.status),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
              if (subtitle != null)
                Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
        if (presentation.status == WebDavSyncStatus.conflict &&
            conflictCount > 0 &&
            onOpenConflicts != null)
          OutlinedButton.icon(
            onPressed: onOpenConflicts,
            icon: const Icon(Icons.warning_amber_outlined),
            label: Text('处理 $conflictCount 项'),
          )
        else
          IconButton.outlined(
            onPressed: presentation.status == WebDavSyncStatus.syncing
                ? null
                : onSyncNow,
            tooltip: '立即同步',
            icon: const Icon(Icons.sync),
          ),
      ],
    );
  }

  String _formatDateTime(DateTime value) {
    final local = value.toLocal();
    String two(int number) => number.toString().padLeft(2, '0');
    return '${local.year}-${two(local.month)}-${two(local.day)} '
        '${two(local.hour)}:${two(local.minute)}';
  }
}
