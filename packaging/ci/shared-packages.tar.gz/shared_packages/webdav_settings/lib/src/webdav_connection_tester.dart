import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:webdav_storage/webdav_storage.dart';

import 'webdav_settings_model.dart';
import 'webdav_transport_error.dart';

enum WebDavConnectionFailure {
  invalidAddress,
  unreachable,
  authentication,
  permission,
  readWrite,
  unknown,
}

class WebDavConnectionTestResult {
  const WebDavConnectionTestResult.success()
    : isSuccess = true,
      failure = null,
      message = '连接成功，远程目录可读写';

  const WebDavConnectionTestResult.failure(this.failure, this.message)
    : isSuccess = false;

  final bool isSuccess;
  final WebDavConnectionFailure? failure;
  final String message;
}

abstract interface class WebDavConnectionTester {
  Future<WebDavConnectionTestResult> test(WebDavSettings settings);
}

class DefaultWebDavConnectionTester implements WebDavConnectionTester {
  DefaultWebDavConnectionTester({required this.appId});

  final String appId;

  @override
  Future<WebDavConnectionTestResult> test(WebDavSettings settings) async {
    final uri = Uri.tryParse(settings.baseUrl.trim());
    if (uri == null ||
        !uri.hasScheme ||
        !uri.hasAuthority ||
        (uri.scheme != 'http' && uri.scheme != 'https')) {
      return const WebDavConnectionTestResult.failure(
        WebDavConnectionFailure.invalidAddress,
        '请输入有效的 HTTP 或 HTTPS WebDAV 地址',
      );
    }
    if ((settings.username.isEmpty) != (settings.password.isEmpty)) {
      return const WebDavConnectionTestResult.failure(
        WebDavConnectionFailure.authentication,
        '账号和密码需要同时填写，或同时留空',
      );
    }

    final client = WebDavStorageClient(
      config: WebDavConfig(
        baseUri: uri,
        username: settings.username.trim().isEmpty
            ? null
            : settings.username.trim(),
        password: settings.password.isEmpty ? null : settings.password,
        timeout: const Duration(seconds: 12),
        proxyUri: kIsWeb ? Uri.base.resolve('/webdav-proxy') : null,
      ),
    );
    final directory = 'apps/$appId';
    final path = '$directory/.connection-test.json';
    final nonce =
        '${DateTime.now().microsecondsSinceEpoch}-${Random().nextInt(0x7fffffff)}';
    final payload = jsonEncode({'appId': appId, 'nonce': nonce});
    try {
      await client.ensureDirectory(directory);
      await client.uploadText(
        path,
        payload,
        contentType: 'application/json; charset=utf-8',
      );
      final downloaded = await client.downloadText(path);
      if (downloaded != payload) {
        return const WebDavConnectionTestResult.failure(
          WebDavConnectionFailure.readWrite,
          '服务器返回的数据与测试内容不一致',
        );
      }
      return const WebDavConnectionTestResult.success();
    } on WebDavException catch (error) {
      return _fromWebDavException(error);
    } catch (error) {
      return _transportFailure(error);
    } finally {
      client.close();
    }
  }

  WebDavConnectionTestResult _fromWebDavException(WebDavException error) {
    return switch (error.statusCode) {
      401 => const WebDavConnectionTestResult.failure(
        WebDavConnectionFailure.authentication,
        '认证失败，请检查账号和密码',
      ),
      403 => const WebDavConnectionTestResult.failure(
        WebDavConnectionFailure.permission,
        '账号没有创建目录或读写文件的权限',
      ),
      404 || 405 || 409 => const WebDavConnectionTestResult.failure(
        WebDavConnectionFailure.readWrite,
        '服务器不支持所需的目录或文件操作',
      ),
      null => _transportFailure(error.cause),
      _ => WebDavConnectionTestResult.failure(
        WebDavConnectionFailure.unknown,
        'WebDAV 测试失败（HTTP ${error.statusCode}）',
      ),
    };
  }

  WebDavConnectionTestResult _transportFailure(Object? error) {
    final String message;
    if (error is TimeoutException) {
      message = 'WebDAV 请求超时，请检查服务器、端口和网络后重试';
    } else if (error is StateError &&
        error.message.toString().contains('Insecure HTTP')) {
      message = '系统禁止 HTTP 连接，需要更新应用的网络配置或使用 HTTPS';
    } else {
      message =
          describeWebDavTransportError(error) ??
          (kIsWeb
              ? 'WebDAV 请求失败，请检查网站的 WebDAV 代理、跨域配置和服务器连接'
              : '无法连接 WebDAV 服务，请检查地址、端口和网络');
    }
    return WebDavConnectionTestResult.failure(
      WebDavConnectionFailure.unreachable,
      message,
    );
  }
}
