String? describeWebDavTransportError(Object? error) => null;
