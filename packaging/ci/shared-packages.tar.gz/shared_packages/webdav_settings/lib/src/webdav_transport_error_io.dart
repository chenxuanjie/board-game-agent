import 'dart:io';

// Return fixed messages only; exception text can contain credentials or URLs.
String? describeWebDavTransportError(Object? error) {
  if (error is HandshakeException || error is TlsException) {
    return 'HTTPS 握手失败，请检查证书及协议、端口是否匹配';
  }
  if (error is SocketException) {
    final code = error.osError?.errorCode;
    if ({61, 111, 1225, 10061}.contains(code)) {
      return '服务器拒绝连接，请检查 WebDAV 服务是否开启、端口是否正确';
    }
    if ({60, 110, 10060}.contains(code)) {
      return '连接超时，请检查局域网连接、服务器地址和防火墙';
    }
    if ({51, 65, 101, 113, 1231, 1232, 10051, 10065}.contains(code)) {
      return '无法到达服务器，请确认手机和 NAS 在可互通的网络中';
    }
    if ({7, 8, -2, -3, 11001}.contains(code)) {
      return '无法解析服务器域名，请检查地址和 DNS';
    }
    return '网络连接失败，请检查服务器地址、端口及手机网络';
  }
  return null;
}
