import 'dart:async';
import 'dart:io' show Directory;
import 'package:http/http.dart' as http;
import 'package:remote_update/remote_update.dart';

import 'app_update_models.dart';
import 'app_update_service.dart';
import 'native_app_update_config.dart';

class NativeAppUpdateService
    implements AppUpdateService, CancellableAppUpdateService {
  NativeAppUpdateService({
    required List<NativeUpdateEndpoint> Function() connections,
    required NativeAppUpdateConfig config,
    required UpdateInstaller installer,
    String? Function(Object error, bool downloading)? failureMessage,
    FutureOr<http.Client> Function()? clientFactory,
    Future<(String, int)> Function()? installedVersion,
    Future<String> Function()? architectureProvider,
    Directory? downloadDirectory,
    Future<void> Function()? beforeInstall,
    bool? isSupported,
  });
  @override
  Future<AppUpdateInfo> check() async =>
      const AppUpdateInfo(status: AppUpdateStatus.unsupported);
  @override
  Future<void> install(
    AppUpdateInfo info, {
    void Function(AppUpdateProgress)? onProgress,
  }) async => throw UnsupportedError('浏览器不支持应用内安装');
  @override
  void dispose() {}
  @override
  bool get canCancel => false;
  @override
  void cancel() {}
  void assertInstallationAllowed() => throw UnsupportedError('浏览器不支持应用内安装');
}
