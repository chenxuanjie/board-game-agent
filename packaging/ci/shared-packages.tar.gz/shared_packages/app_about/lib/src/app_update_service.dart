import 'app_update_models.dart';

abstract interface class AppUpdateService {
  Future<AppUpdateInfo> check();

  Future<void> install(
    AppUpdateInfo info, {
    void Function(AppUpdateProgress progress)? onProgress,
  });

  void dispose();
}

abstract interface class CancellableAppUpdateService {
  bool get canCancel;
  void cancel();
}
