export 'native_app_update_service_stub.dart'
    if (dart.library.io) 'native_app_update_service_io.dart';
