import 'package:shared_preferences/shared_preferences.dart';

abstract interface class AppUpdateSuppressionStore {
  Future<bool> isSuppressed({
    required String appId,
    required String version,
    required int build,
  });

  Future<void> suppress({
    required String appId,
    required String version,
    required int build,
  });
}

final class SharedPreferencesAppUpdateSuppressionStore
    implements AppUpdateSuppressionStore {
  const SharedPreferencesAppUpdateSuppressionStore();

  static const _keyPrefix = 'app_about.suppressed_update.';

  @override
  Future<bool> isSuppressed({
    required String appId,
    required String version,
    required int build,
  }) async {
    final preferences = await SharedPreferences.getInstance();
    return preferences.getString('$_keyPrefix$appId') ==
        _versionKey(version, build);
  }

  @override
  Future<void> suppress({
    required String appId,
    required String version,
    required int build,
  }) async {
    final preferences = await SharedPreferences.getInstance();
    final saved = await preferences.setString(
      '$_keyPrefix$appId',
      _versionKey(version, build),
    );
    if (!saved) {
      throw StateError('无法保存更新提示设置');
    }
  }

  String _versionKey(String version, int build) => '$version+$build';
}
