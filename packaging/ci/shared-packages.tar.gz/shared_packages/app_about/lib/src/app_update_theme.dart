import 'package:flutter/material.dart';

/// Update surfaces use Zheri's Material 3 geometry and typography. Only the
/// host palette is inherited, so app-wide dialog/button overrides cannot alter
/// the shared update interface.
ThemeData buildAppUpdateTheme(ThemeData host) => ThemeData(
  useMaterial3: true,
  colorScheme: host.colorScheme,
  fontFamily: 'NotoSansSC',
  fontFamilyFallback: const ['Microsoft YaHei', 'Segoe UI', 'sans-serif'],
  visualDensity: VisualDensity.standard,
  materialTapTargetSize: MaterialTapTargetSize.padded,
  textTheme: const TextTheme(
    headlineLarge: TextStyle(
      fontWeight: FontWeight.w900,
      letterSpacing: 0,
      height: 1.16,
    ),
    headlineMedium: TextStyle(
      fontWeight: FontWeight.w700,
      letterSpacing: 0,
      height: 1.18,
    ),
    titleLarge: TextStyle(
      fontWeight: FontWeight.w700,
      letterSpacing: 0,
      height: 1.25,
    ),
    titleMedium: TextStyle(
      fontWeight: FontWeight.w700,
      letterSpacing: 0,
      height: 1.3,
    ),
    bodyLarge: TextStyle(letterSpacing: 0, height: 1.45),
    bodyMedium: TextStyle(letterSpacing: 0, height: 1.4),
    bodySmall: TextStyle(letterSpacing: 0, height: 1.35),
    labelLarge: TextStyle(
      fontWeight: FontWeight.w700,
      letterSpacing: 0,
      height: 1.25,
    ),
    labelMedium: TextStyle(letterSpacing: 0, height: 1.25),
    labelSmall: TextStyle(letterSpacing: 0, height: 1.2),
  ),
);
