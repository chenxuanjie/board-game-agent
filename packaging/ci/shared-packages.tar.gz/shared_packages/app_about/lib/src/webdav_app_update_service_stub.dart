import 'dart:async';
import 'dart:io' show Directory;
import 'package:http/http.dart' as http;
import 'package:remote_update/remote_update.dart';
import 'package:webdav_settings/webdav_settings.dart';
import 'app_update_models.dart';
import 'app_update_service.dart';
import 'webdav_app_update_config.dart';

class WebDavAppUpdateService implements AppUpdateService, CancellableAppUpdateService {
  WebDavAppUpdateService({
    required WebDavSettings Function() settingsProvider,
    required WebDavAppUpdateConfig config,
    required UpdateInstaller installer,
    List<WebDavSettings> Function()? settingsCandidates,
    FutureOr<http.Client> Function()? clientFactory,
    Future<(String, int)> Function()? installedVersion,
    Future<String> Function()? architectureProvider,
    Directory? downloadDirectory,
    Future<void> Function()? beforeInstall,
    bool? isSupported,
  });
  @override
  Future<AppUpdateInfo> check() async =>
      const AppUpdateInfo(status: AppUpdateStatus.unsupported);
  @override
  Future<void> install(
    AppUpdateInfo info, {
    void Function(AppUpdateProgress)? onProgress,
  }) async => throw UnsupportedError('浏览器不支持应用内安装');
  @override
  void dispose() {}
  @override
  bool get canCancel => false;
  @override
  void cancel() {}
  void assertInstallationAllowed() => throw UnsupportedError('浏览器不支持应用内安装');
}
