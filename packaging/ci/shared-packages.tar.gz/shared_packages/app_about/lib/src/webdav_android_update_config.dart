final class WebDavAndroidUpdateConfig {
  const WebDavAndroidUpdateConfig({
    required this.appId,
    required this.manifestPath,
    required this.fallbackVersion,
    required this.fallbackBuild,
    this.channel = 'stable',
    this.directoryName = 'app_updates',
    this.fallbackArchitecture = 'arm64',
    this.requestTimeout = const Duration(seconds: 12),
    this.trustedCertificateAssetPaths = const <String>[],
  });

  final String appId;
  final String manifestPath;
  final String fallbackVersion;
  final int fallbackBuild;
  final String channel;
  final String directoryName;
  final String fallbackArchitecture;
  final Duration requestTimeout;

  /// PEM or DER certificate assets trusted in addition to the platform roots.
  ///
  /// Use this only when an endpoint omits an otherwise valid intermediate
  /// certificate from its TLS chain.
  final List<String> trustedCertificateAssetPaths;
}
