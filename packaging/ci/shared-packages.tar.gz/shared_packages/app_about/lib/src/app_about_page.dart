import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import 'app_about_config.dart';
import 'app_update_models.dart';
import 'app_update_service.dart';
import 'app_update_content.dart';

class AppAboutPage extends StatefulWidget {
  const AppAboutPage({
    super.key,
    required this.config,
    required this.updateService,
    this.disposeUpdateService = true,
    this.checkOnOpen = false,
  });

  final AppAboutConfig config;
  final AppUpdateService updateService;
  final bool disposeUpdateService;
  final bool checkOnOpen;

  @override
  State<AppAboutPage> createState() => _AppAboutPageState();
}

class _AppAboutPageState extends State<AppAboutPage> {
  late String _version = widget.config.fallbackVersion;
  late String _build = widget.config.fallbackBuild;
  AppUpdateInfo? _updateInfo;
  AppUpdateProgress? _progress;
  bool _checking = false;
  bool _installing = false;
  bool _installerLaunched = false;
  String? _installError;

  @override
  void initState() {
    super.initState();
    _loadPackageInfo();
    if (widget.checkOnOpen && widget.config.showUpdate) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _checkForUpdate();
      });
    }
  }

  @override
  void dispose() {
    if (widget.disposeUpdateService) widget.updateService.dispose();
    super.dispose();
  }

  Future<void> _loadPackageInfo() async {
    try {
      final info = await PackageInfo.fromPlatform();
      if (!mounted) return;
      setState(() {
        _version = info.version;
        _build = info.buildNumber;
      });
    } catch (_) {
      // Tests and unsupported targets can use the configured fallback version.
    }
  }

  Future<void> _checkForUpdate() async {
    if (_checking || _installing) return;
    setState(() {
      _checking = true;
      _updateInfo = null;
      _progress = null;
      _installerLaunched = false;
      _installError = null;
    });
    AppUpdateInfo result;
    try {
      result = await widget.updateService.check();
    } catch (_) {
      result = AppUpdateInfo(
        status: AppUpdateStatus.failed,
        message: '检查更新失败，请重试',
      );
    }
    if (!mounted) return;
    setState(() {
      _checking = false;
      _updateInfo = result;
    });
  }

  Future<void> _installUpdate() async {
    var info = _updateInfo;
    if (info == null || !info.isAvailable || _installing) return;
    if (_installError != null) {
      final previous = info;
      await _checkForUpdate();
      if (!mounted) return;
      info = _updateInfo;
      if (info == null ||
          !info.isAvailable ||
          info.latestBuild != previous.latestBuild ||
          info.latestVersion != previous.latestVersion) {
        return;
      }
    }
    setState(() {
      _installing = true;
      _progress = null;
      _installError = null;
    });
    try {
      await widget.updateService.install(
        info,
        onProgress: (progress) {
          if (mounted) setState(() => _progress = progress);
        },
      );
      if (mounted) setState(() => _installerLaunched = true);
    } catch (error) {
      if (mounted) {
        setState(
          () => _installError = error is AppUpdateFailure
              ? error.message.toString()
              : '更新失败，请重试',
        );
      }
    } finally {
      if (mounted) setState(() => _installing = false);
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !_installing,
    child: Scaffold(
      appBar: AppBar(title: const Text('关于')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 36),
          children: [
            Center(
              child: Column(
                children: [
                  widget.config.appIcon,
                  const SizedBox(height: 16),
                  Text(
                    widget.config.appName,
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    widget.config.subtitle,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.verified_outlined),
                    title: const Text('当前版本'),
                    trailing: Text('$_version ($_build)'),
                  ),
                  if (widget.config.showUpdate) ...[
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.system_update_outlined),
                      title: const Text('检查更新'),
                      subtitle: _updateSubtitle(),
                      trailing: _checking
                          ? const SizedBox.square(
                              dimension: 22,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.chevron_right),
                      onTap: _checking || _installing ? null : _checkForUpdate,
                    ),
                  ],
                ],
              ),
            ),
            if ((_updateInfo?.isAvailable ?? false) && !_installerLaunched) ...[
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      // Notes scroll inside the update card; progress and the
                      // action remain anchored to the card footer.
                      maxHeight: MediaQuery.sizeOf(context).height * 0.55,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          '发现新版本 ${_updateInfo!.latestVersion}',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: 12),
                        Flexible(
                          child: AppUpdateContent(
                            info: _updateInfo!,
                            installing: _installing,
                            progress: _progress,
                            error: _installError,
                            onInstall: _installUpdate,
                            onCancel:
                                widget.updateService
                                        is CancellableAppUpdateService &&
                                    (widget.updateService
                                            as CancellableAppUpdateService)
                                        .canCancel
                                ? (widget.updateService
                                          as CancellableAppUpdateService)
                                      .cancel
                                : null,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    ),
  );

  Widget? _updateSubtitle() {
    if (_installerLaunched) return const Text('安装程序已启动，请完成安装');
    final info = _updateInfo;
    if (_checking) return const Text('正在检查…');
    if (info == null) return Text(widget.config.updateCheckSubtitle);
    final message = info.message;
    return message == null ? null : Text(message);
  }
}
