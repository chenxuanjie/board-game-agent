export 'webdav_app_update_service_stub.dart'
    if (dart.library.io) 'webdav_app_update_service_io.dart';
