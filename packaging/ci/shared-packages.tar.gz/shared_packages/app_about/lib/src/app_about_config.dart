import 'package:flutter/widgets.dart';

final class AppAboutConfig {
  const AppAboutConfig({
    required this.appName,
    required this.subtitle,
    required this.appIcon,
    required this.fallbackVersion,
    required this.fallbackBuild,
    this.showUpdate = true,
    this.updateCheckSubtitle = '检查应用新版本',
  });

  final String appName;
  final String subtitle;
  final Widget appIcon;
  final String fallbackVersion;
  final String fallbackBuild;
  final bool showUpdate;
  final String updateCheckSubtitle;
}
