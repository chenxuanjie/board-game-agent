import 'package:remote_update_webdav/remote_update_webdav.dart';
import 'package:webdav_settings/webdav_settings.dart';
import 'package:webdav_storage/webdav_storage.dart';
import 'native_app_update_config.dart';
import 'native_app_update_service_io.dart';
import 'webdav_app_update_config.dart';

/// Optional DAV adapter; all native sources share one update lifecycle.
class WebDavAppUpdateService extends NativeAppUpdateService {
  WebDavAppUpdateService({
    required WebDavSettings Function() settingsProvider,
    required WebDavAppUpdateConfig config,
    required super.installer,
    List<WebDavSettings> Function()? settingsCandidates,
    super.clientFactory,
    super.installedVersion,
    super.architectureProvider,
    super.downloadDirectory,
    super.beforeInstall,
    super.isSupported,
  }) : super(
         config: config,
         connections: () => [
           for (final setting
               in settingsCandidates?.call() ?? [settingsProvider()])
             if (_valid(setting))
               NativeUpdateEndpoint(
                 key: (
                   setting.mode,
                   setting.baseUrl,
                   setting.username,
                   setting.password,
                 ),
                 source: (client) => WebDavUpdateSource(
                   storage: WebDavStorageClient(
                     config: WebDavConfig(
                       baseUri: Uri.parse(setting.baseUrl.trim()),
                       username: setting.username.isEmpty
                           ? null
                           : setting.username,
                       password: setting.password.isEmpty
                           ? null
                           : setting.password,
                       timeout: config.requestTimeout,
                     ),
                     httpClient: client,
                   ),
                   manifestPath: config.manifestPath,
                 ),
               ),
         ],
         failureMessage: (error, downloading) => error is WebDavException
             ? switch (error.statusCode) {
                 401 || 403 => '更新连接认证或访问权限失败，请检查连接设置',
                 404 => '尚未发布 ${config.label} 更新，或更新文件已移除',
                 429 => '服务器繁忙，请稍后重试',
                 _ =>
                   downloading
                       ? '下载中断，进度已保留。请检查网络后继续下载。'
                       : '无法连接更新服务器，请检查网络后重试',
               }
             : null,
       );
  static bool _valid(WebDavSettings settings) {
    final uri = Uri.tryParse(settings.baseUrl.trim());
    return settings.mode == ExternalStorageMode.webDav &&
        settings.isComplete &&
        uri != null &&
        uri.hasAuthority &&
        uri.host.isNotEmpty &&
        (uri.scheme == 'https' ||
            uri.scheme == 'http' &&
                ['localhost', '127.0.0.1', '::1'].contains(uri.host)) &&
        uri.userInfo.isEmpty &&
        !uri.hasQuery &&
        !uri.hasFragment &&
        settings.username.isEmpty == settings.password.isEmpty;
  }
}
