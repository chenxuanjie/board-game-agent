import 'webdav_app_update_config.dart';

enum AppUpdateStatus { unsupported, notConfigured, upToDate, available, failed }

enum AppUpdatePhase { downloading, verifying, preparing, installing }

/// A deliberately user-facing message, never a raw server or plugin diagnostic.
class AppUpdateFailure extends StateError {
  AppUpdateFailure(super.message);
}

final class AppUpdateInfo {
  const AppUpdateInfo({
    required this.status,
    this.latestVersion,
    this.latestBuild,
    this.releaseNotes = const [],
    this.required = false,
    this.message,
    this.target,
    this.artifactSize,
  });

  final AppUpdateStatus status;
  final String? latestVersion;
  final int? latestBuild;
  final List<String> releaseNotes;
  final bool required;
  final String? message;
  final AppUpdateTarget? target;
  final int? artifactSize;

  bool get isAvailable => status == AppUpdateStatus.available;
}

final class AppUpdateProgress {
  const AppUpdateProgress({
    required this.receivedBytes,
    required this.totalBytes,
    this.phase = AppUpdatePhase.downloading,
  });

  final int receivedBytes;
  final int totalBytes;
  final AppUpdatePhase phase;

  double? get fraction {
    if (totalBytes <= 0) return null;
    return (receivedBytes / totalBytes).clamp(0, 1);
  }
}
