import 'package:flutter/material.dart';
import 'app_update_models.dart';
import 'webdav_app_update_config.dart';
import 'app_update_theme.dart';

/// Shared release notes, progress, errors and primary action for both the About
/// card and the startup dialog, on Android and Windows.
class AppUpdateContent extends StatelessWidget {
  const AppUpdateContent({
    super.key,
    required this.info,
    required this.installing,
    required this.onInstall,
    this.progress,
    this.error,
    this.onCancel,
  });
  final AppUpdateInfo info;
  final bool installing;
  final AppUpdateProgress? progress;
  final String? error;
  final VoidCallback? onInstall, onCancel;
  String get _phase => !installing && error != null
      ? '等待重试'
      : switch (progress?.phase) {
          AppUpdatePhase.verifying => '正在校验安装包',
          AppUpdatePhase.preparing => '正在准备安装',
          AppUpdatePhase.installing => '正在启动安装程序',
          _ => '正在下载更新包',
        };
  @override
  Widget build(BuildContext context) => Theme(
    data: buildAppUpdateTheme(Theme.of(context)),
    child: Builder(builder: _buildContent),
  );

  Widget _buildContent(BuildContext context) => DefaultTextStyle(
    style: Theme.of(context).textTheme.bodyMedium!,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (info.target != null) ...[
          Text(
            info.target == AppUpdateTarget.windows
                ? 'Windows 安装包（EXE）'
                : 'Android 安装包（APK）',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
        ],
        Flexible(
          child: SingleChildScrollView(
            key: const ValueKey('app-update-release-notes'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: info.releaseNotes
                  .map(
                    (note) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text('· $note'),
                    ),
                  )
                  .toList(),
            ),
          ),
        ),
        if (installing || progress != null) ...[
          const SizedBox(height: 12),
          LinearProgressIndicator(
            key: const ValueKey('app-update-progress'),
            value: !installing || progress?.phase == AppUpdatePhase.downloading
                ? progress?.fraction
                : null,
          ),
          const SizedBox(height: 8),
          Text(
            !installing && error != null
                ? (progress?.phase == AppUpdatePhase.downloading &&
                          (progress?.fraction ?? 0) > 0
                      ? '已下载 ${(progress!.fraction! * 100).toStringAsFixed(0)}% · 已暂停'
                      : _phase)
                : progress?.phase == AppUpdatePhase.downloading &&
                      progress?.fraction != null
                ? '已下载 ${(progress!.fraction! * 100).toStringAsFixed(0)}%'
                : _phase,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
        if (error != null) ...[
          const SizedBox(height: 10),
          Semantics(
            liveRegion: true,
            child: Text(
              error!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),
        ],
        const SizedBox(height: 12),
        FilledButton.icon(
          key: const ValueKey('app-update-install'),
          onPressed: installing ? null : onInstall,
          icon: installing
              ? SizedBox.square(
                  dimension: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Theme.of(context).colorScheme.onPrimary,
                  ),
                )
              : const Icon(Icons.system_update_alt),
          label: Text(
            installing
                ? _phase
                : error != null
                ? (progress?.phase == AppUpdatePhase.downloading &&
                          (progress?.fraction ?? 0) > 0 &&
                          (progress?.fraction ?? 0) < 1
                      ? '继续下载'
                      : progress?.phase == AppUpdatePhase.preparing ||
                            progress?.phase == AppUpdatePhase.installing
                      ? '重试安装'
                      : '重试更新')
                : '下载并安装',
          ),
        ),
        if (installing && onCancel != null)
          TextButton(onPressed: onCancel, child: const Text('暂停下载')),
      ],
    ),
  );
}
