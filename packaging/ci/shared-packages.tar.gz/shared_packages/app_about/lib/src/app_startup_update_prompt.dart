import 'package:flutter/material.dart';

import 'app_update_models.dart';
import 'app_update_service.dart';
import 'app_update_content.dart';
import 'app_update_suppression_store.dart';
import 'app_update_theme.dart';

enum AppStartupUpdateResult {
  noUpdate,
  suppressed,
  dismissed,
  installStarted,
  failed,
}

Future<AppStartupUpdateResult> checkForUpdateOnStartup({
  required BuildContext context,
  required String appId,
  required AppUpdateService updateService,
  AppUpdateSuppressionStore suppressionStore =
      const SharedPreferencesAppUpdateSuppressionStore(),
  bool disposeUpdateService = true,
}) async {
  try {
    final info = await updateService.check();
    if (!context.mounted) return AppStartupUpdateResult.noUpdate;
    if (!info.isAvailable) return AppStartupUpdateResult.noUpdate;

    final version = info.latestVersion;
    final build = info.latestBuild;
    if (version == null || build == null) {
      return AppStartupUpdateResult.failed;
    }

    if (!info.required &&
        await suppressionStore.isSuppressed(
          appId: appId,
          version: version,
          build: build,
        )) {
      return AppStartupUpdateResult.suppressed;
    }
    if (!context.mounted) return AppStartupUpdateResult.noUpdate;

    final result = await showDialog<AppStartupUpdateResult>(
      context: context,
      barrierDismissible: !info.required,
      builder: (_) => Theme(
        data: buildAppUpdateTheme(Theme.of(context)),
        child: _StartupUpdateDialog(
          appId: appId,
          info: info,
          updateService: updateService,
          suppressionStore: suppressionStore,
        ),
      ),
    );
    return result ?? AppStartupUpdateResult.dismissed;
  } catch (_) {
    // Startup checks must never block the application from opening.
    return AppStartupUpdateResult.failed;
  } finally {
    if (disposeUpdateService) updateService.dispose();
  }
}

class _StartupUpdateDialog extends StatefulWidget {
  const _StartupUpdateDialog({
    required this.appId,
    required this.info,
    required this.updateService,
    required this.suppressionStore,
  });

  final String appId;
  final AppUpdateInfo info;
  final AppUpdateService updateService;
  final AppUpdateSuppressionStore suppressionStore;

  @override
  State<_StartupUpdateDialog> createState() => _StartupUpdateDialogState();
}

class _StartupUpdateDialogState extends State<_StartupUpdateDialog> {
  late AppUpdateInfo _info = widget.info;
  bool _installing = false;
  bool _retryAfterFailure = false;
  bool _savingPreference = false;
  AppUpdateProgress? _progress;
  String? _error;

  Future<void> _saveSuppression() async {
    if (_info.required) return;
    final version = _info.latestVersion;
    final build = _info.latestBuild;
    if (version == null || build == null) return;
    await widget.suppressionStore.suppress(
      appId: widget.appId,
      version: version,
      build: build,
    );
  }

  Future<void> _dismiss() async {
    if (_installing || _savingPreference) return;
    Navigator.of(context).pop(AppStartupUpdateResult.dismissed);
  }

  Future<void> _skipVersion() async {
    if (_installing || _savingPreference || _info.required) return;
    setState(() {
      _savingPreference = true;
      _error = null;
    });
    try {
      await _saveSuppression();
      if (mounted) {
        Navigator.of(context).pop(AppStartupUpdateResult.suppressed);
      }
    } catch (error) {
      if (mounted) {
        setState(() {
          _savingPreference = false;
          _error = '无法保存更新提示设置，请重试';
        });
      }
    }
  }

  Future<void> _install() async {
    if (_installing || _savingPreference) return;
    setState(() {
      _installing = true;
      _error = null;
      _progress = null;
    });
    try {
      if (_retryAfterFailure) {
        final previous = _info;
        final refreshed = await widget.updateService.check();
        if (!mounted) return;
        if (!refreshed.isAvailable) {
          if (refreshed.status == AppUpdateStatus.upToDate) {
            Navigator.of(context).pop(AppStartupUpdateResult.noUpdate);
            return;
          }
          setState(() {
            _installing = false;
            _error = refreshed.message ?? '暂时无法更新，请重试';
          });
          return;
        }
        _info = refreshed;
        if (_info.latestBuild != previous.latestBuild ||
            _info.latestVersion != previous.latestVersion) {
          setState(() => _installing = false);
          return;
        }
      }
      await widget.updateService.install(
        _info,
        onProgress: (progress) {
          if (mounted) setState(() => _progress = progress);
        },
      );
      if (mounted) {
        Navigator.of(context).pop(AppStartupUpdateResult.installStarted);
      }
    } catch (error) {
      if (mounted) {
        setState(() {
          _installing = false;
          _retryAfterFailure = true;
          _error = error is AppUpdateFailure
              ? error.message.toString()
              : '更新失败，请重试';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final version = _info.latestVersion ?? '';
    final build = _info.latestBuild;
    final versionLabel = build == null ? version : '$version ($build)';
    return PopScope(
      canPop: !_info.required && !_installing,
      child: AlertDialog(
        title: Text('发现新版本 $versionLabel'),
        content: ConstrainedBox(
          constraints: BoxConstraints(
            // Keep the actions and download status on-screen even when a
            // release contains a long list of notes.
            maxHeight: MediaQuery.sizeOf(context).height * 0.62,
          ),
          child: AppUpdateContent(
            info: _info,
            installing: _installing,
            progress: _progress,
            error: _error,
            onInstall: _savingPreference ? null : _install,
            onCancel:
                widget.updateService is CancellableAppUpdateService &&
                    (widget.updateService as CancellableAppUpdateService)
                        .canCancel
                ? (widget.updateService as CancellableAppUpdateService).cancel
                : null,
          ),
        ),
        actions: [
          if (!_info.required)
            TextButton(
              onPressed: _installing || _savingPreference ? null : _dismiss,
              child: const Text('稍后'),
            ),
          if (!_info.required)
            TextButton(
              onPressed: _installing || _savingPreference ? null : _skipVersion,
              child: Text(_savingPreference ? '正在保存…' : '跳过该版本'),
            ),
        ],
      ),
    );
  }
}
