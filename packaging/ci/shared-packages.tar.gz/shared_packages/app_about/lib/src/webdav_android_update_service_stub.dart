import 'package:webdav_settings/webdav_settings.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:remote_update/remote_update.dart';

import 'app_update_models.dart';
import 'app_update_service.dart';
import 'native_app_update_config.dart';
import 'webdav_android_update_config.dart';

AppUpdateService createNativeAndroidUpdateService({
  required List<NativeUpdateEndpoint> Function() connections,
  required NativeAppUpdateConfig config,
  Future<void> Function()? beforeInstall,
  FutureOr<http.Client> Function()? clientFactory,
  String? Function(Object, bool)? failureMessage,
  AndroidInstallPermissionHandler? permissionHandler,
}) => const _UnsupportedUpdateService();

AppUpdateService createWebDavAndroidUpdateService({
  required WebDavSettings Function() settingsProvider,
  required WebDavAndroidUpdateConfig config,
  AndroidInstallPermissionHandler? permissionHandler,
  List<WebDavSettings> Function()? settingsCandidates,
  Future<void> Function()? beforeInstall,
  FutureOr<http.Client> Function()? clientFactory,
}) => const _UnsupportedUpdateService();

final class _UnsupportedUpdateService implements AppUpdateService {
  const _UnsupportedUpdateService();

  @override
  Future<AppUpdateInfo> check() async => const AppUpdateInfo(
    status: AppUpdateStatus.unsupported,
    message: '当前平台不支持应用内安装更新',
  );

  @override
  Future<void> install(
    AppUpdateInfo info, {
    void Function(AppUpdateProgress progress)? onProgress,
  }) async {
    throw StateError('当前平台不支持应用内安装更新');
  }

  @override
  void dispose() {}
}
