export 'webdav_android_update_service_stub.dart'
    if (dart.library.io) 'webdav_android_update_service_io.dart';
