import 'package:flutter/material.dart';

class AppAboutSettingsTile extends StatelessWidget {
  const AppAboutSettingsTile({super.key, required this.onTap});

  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: const Icon(Icons.info_outline),
      title: const Text('关于'),
      subtitle: const Text('版本信息与检查更新'),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    ),
  );
}
