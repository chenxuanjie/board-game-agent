import 'package:http/http.dart' as http;
import 'package:remote_update/remote_update.dart';

enum AppUpdateTarget { android, windows }

class NativeAppUpdateConfig {
  const NativeAppUpdateConfig({
    required this.appId,
    required this.target,
    required this.architecture,
    this.channel = 'stable',
    this.directoryName = 'app_updates',
    this.locale = 'zh-CN',
    this.requestTimeout = const Duration(seconds: 30),
    this.downloadTimeout = const Duration(minutes: 10),
    this.notConfiguredMessage = '请先配置更新连接',
  });
  final String appId, architecture, channel, directoryName, locale;
  final AppUpdateTarget target;
  final Duration requestTimeout, downloadTimeout;
  final String notConfiguredMessage;
  String get extension => target == AppUpdateTarget.windows ? '.exe' : '.apk';
  String get label => target == AppUpdateTarget.windows ? 'Windows' : 'Android';
}

final class NativeUpdateEndpoint {
  const NativeUpdateEndpoint({required this.key, required this.source});
  final Object key;
  final UpdateSource Function(http.Client client) source;
}
