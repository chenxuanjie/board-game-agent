import 'native_app_update_config.dart';
export 'native_app_update_config.dart' show AppUpdateTarget;

final class WebDavAppUpdateConfig extends NativeAppUpdateConfig {
  const WebDavAppUpdateConfig({
    required super.appId,
    required this.manifestPath,
    required super.target,
    required super.architecture,
    super.channel,
    super.directoryName,
    super.locale,
    super.requestTimeout,
    super.downloadTimeout,
    super.notConfiguredMessage,
  });
  final String manifestPath;
}
