import 'dart:async';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/services.dart'
    show MethodChannel, MissingPluginException, PlatformException, rootBundle;
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';
import 'package:remote_update/remote_update.dart';
import 'package:webdav_settings/webdav_settings.dart';
import 'app_update_service.dart';
import 'native_app_update_config.dart';
import 'native_app_update_service_io.dart';
import 'webdav_android_update_config.dart';
import 'webdav_app_update_config.dart';
import 'webdav_app_update_service_io.dart';

AppUpdateService createNativeAndroidUpdateService({
  required List<NativeUpdateEndpoint> Function() connections,
  required NativeAppUpdateConfig config,
  Future<void> Function()? beforeInstall,
  FutureOr<http.Client> Function()? clientFactory,
  String? Function(Object, bool)? failureMessage,
  AndroidInstallPermissionHandler? permissionHandler,
}) {
  late final NativeAppUpdateService service;
  service = NativeAppUpdateService(
    connections: connections,
    config: config,
    architectureProvider: () => _androidArchitecture(config.architecture),
    beforeInstall: beforeInstall,
    clientFactory: clientFactory,
    failureMessage: failureMessage,
    installer: AndroidUpdateInstaller(
      beforeLaunch: () async => service.assertInstallationAllowed(),
      permissionHandler:
          permissionHandler ?? const _PlatformInstallPermissionHandler(),
    ),
  );
  return service;
}

AppUpdateService createWebDavAndroidUpdateService({
  required WebDavSettings Function() settingsProvider,
  required WebDavAndroidUpdateConfig config,
  AndroidInstallPermissionHandler? permissionHandler,
  List<WebDavSettings> Function()? settingsCandidates,
  Future<void> Function()? beforeInstall,
  FutureOr<http.Client> Function()? clientFactory,
}) {
  late final WebDavAppUpdateService service;
  service = WebDavAppUpdateService(
    settingsProvider: settingsProvider,
    settingsCandidates: settingsCandidates,
    beforeInstall: beforeInstall,
    config: WebDavAppUpdateConfig(
      appId: config.appId,
      manifestPath: config.manifestPath,
      target: AppUpdateTarget.android,
      architecture: config.fallbackArchitecture,
      channel: config.channel,
      directoryName: config.directoryName,
      requestTimeout: config.requestTimeout,
    ),
    architectureProvider: () =>
        _androidArchitecture(config.fallbackArchitecture),
    installer: AndroidUpdateInstaller(
      beforeLaunch: () async => service.assertInstallationAllowed(),
      permissionHandler:
          permissionHandler ?? const _PlatformInstallPermissionHandler(),
    ),
    clientFactory:
        clientFactory ??
        () => _createHttpClient(config.trustedCertificateAssetPaths),
  );
  return service;
}

Future<http.Client> _createHttpClient(List<String> assetPaths) async {
  if (assetPaths.isEmpty) return http.Client();
  final context = SecurityContext(withTrustedRoots: true);
  for (final path in assetPaths) {
    final certificate = await rootBundle.load(path);
    context.setTrustedCertificatesBytes(
      certificate.buffer.asUint8List(
        certificate.offsetInBytes,
        certificate.lengthInBytes,
      ),
    );
  }
  return IOClient(HttpClient(context: context));
}

Future<String> _androidArchitecture(String fallback) async {
  final info = await DeviceInfoPlugin().androidInfo;
  for (final abi in info.supportedAbis) {
    switch (abi.toLowerCase()) {
      case 'arm64-v8a':
      case 'aarch64':
        return 'arm64';
      case 'armeabi-v7a':
      case 'armeabi':
        return 'arm';
      case 'x86_64':
        return 'x86_64';
      case 'x86':
        return 'x86';
    }
  }
  return fallback;
}

final class _PlatformInstallPermissionHandler
    implements AndroidInstallPermissionHandler {
  const _PlatformInstallPermissionHandler();

  static const _channel = MethodChannel('app_about/install_permission');

  @override
  Future<AndroidInstallPermissionResult> ensurePermission() async {
    try {
      final raw = await _channel.invokeMethod<Object?>(
        'ensureInstallPermission',
      );
      final result = raw is Map ? Map<Object?, Object?>.from(raw) : const {};
      final granted = result['granted'] == true;
      return AndroidInstallPermissionResult(
        status: granted
            ? AndroidInstallPermissionStatus.granted
            : AndroidInstallPermissionStatus.denied,
        message: granted ? '已获得 Android 安装权限。' : '请在系统设置中允许此应用安装未知来源应用，然后重试。',
      );
    } on MissingPluginException {
      return const AndroidInstallPermissionResult(
        status: AndroidInstallPermissionStatus.unsupported,
        message: '当前 Android 宿主未提供未知来源安装权限处理。',
      );
    } on PlatformException catch (error) {
      return AndroidInstallPermissionResult(
        status: AndroidInstallPermissionStatus.denied,
        message: '无法检查 Android 安装权限：${error.message ?? error.code}',
      );
    }
  }
}
