import 'dart:async';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:remote_update/remote_update.dart';
import 'app_update_models.dart';
import 'app_update_service.dart';
import 'native_app_update_config.dart';

/// Shared check/download/verify/install lifecycle for native application updates.
/// Hosts supply their network policy and platform installer; UI never guesses
/// the target from its theme or downloads a different platform's artifact.
class NativeAppUpdateService
    implements AppUpdateService, CancellableAppUpdateService {
  NativeAppUpdateService({
    required this.connections,
    required this.config,
    required this.installer,
    this.failureMessage,
    FutureOr<http.Client> Function()? clientFactory,
    Future<(String, int)> Function()? installedVersion,
    Future<String> Function()? architectureProvider,
    this.downloadDirectory,
    this.beforeInstall,
    bool? isSupported,
  }) : _clientFactory = clientFactory ?? http.Client.new,
       _installedVersion = installedVersion ?? _readInstalledVersion,
       _architectureProvider = architectureProvider,
       _supported =
           isSupported ??
           (config.target == AppUpdateTarget.windows
               ? Platform.isWindows
               : Platform.isAndroid);
  final List<NativeUpdateEndpoint> Function() connections;
  final String? Function(Object error, bool downloading)? failureMessage;
  final NativeAppUpdateConfig config;
  final UpdateInstaller installer;
  final Future<void> Function()? beforeInstall;
  final Directory? downloadDirectory;
  final FutureOr<http.Client> Function() _clientFactory;
  final Future<(String, int)> Function() _installedVersion;
  final Future<String> Function()? _architectureProvider;
  final bool _supported;
  final _contexts = <_Endpoint>[];
  _Endpoint? _selected;
  UpdateCandidate? _candidate;
  List<Object>? _checkedKeys;
  UpdateCancellationToken? _cancellation;
  bool _busy = false, _disposed = false, _downloading = false;
  int _generation = 0;

  Future<http.Client> _openClient(int generation) async {
    final creation = Future<http.Client>.sync(_clientFactory);
    var waiting = true;
    unawaited(
      creation.then<void>((client) {
        if (!waiting || _disposed || generation != _generation) client.close();
      }, onError: (Object _) {}),
    );
    try {
      return await creation.timeout(config.requestTimeout);
    } finally {
      waiting = false;
    }
  }

  static Future<(String, int)> _readInstalledVersion() async {
    final info = await PackageInfo.fromPlatform();
    final build = int.tryParse(info.buildNumber);
    if (info.version.isEmpty || build == null || build <= 0) {
      throw AppUpdateFailure('无法读取当前应用版本');
    }
    return (info.version, build);
  }

  bool _sameSettings() {
    final old = _checkedKeys, next = connections();
    return old != null &&
        old.length == next.length &&
        List.generate(
          old.length,
          (i) => old[i] == next[i].key,
        ).every((same) => same);
  }

  @override
  Future<AppUpdateInfo> check() async {
    if (_disposed) throw AppUpdateFailure('更新检查已关闭');
    if (_busy) {
      return const AppUpdateInfo(
        status: AppUpdateStatus.failed,
        message: '更新操作正在进行，请稍候',
      );
    }
    if (!_supported) {
      return const AppUpdateInfo(status: AppUpdateStatus.unsupported);
    }
    _busy = true;
    final generation = ++_generation;
    try {
      await _clear();
      final settings = connections();
      final snapshot = [for (final endpoint in settings) endpoint.key];
      if (settings.isEmpty) {
        return AppUpdateInfo(
          status: AppUpdateStatus.notConfigured,
          message: config.notConfiguredMessage,
        );
      }
      final version = await _installedVersion().timeout(config.requestTimeout);
      final architecture =
          await (_architectureProvider?.call() ??
                  Future.value(config.architecture))
              .timeout(config.requestTimeout);
      if (_disposed || generation != _generation) {
        throw AppUpdateFailure('更新已取消');
      }
      final result = Completer<(_Endpoint, UpdateCandidate?)>();
      var remaining = settings.length;
      for (final setting in settings) {
        unawaited(() async {
          _Endpoint? context;
          try {
            final client = await _openClient(generation);
            if (_disposed || generation != _generation || result.isCompleted) {
              client.close();
              return;
            }
            context = _Endpoint(client);
            _contexts.add(context);
            final source = _TargetSource(
              setting.source(client),
              config,
              architecture,
            );
            context.updater = downloadDirectory == null
                ? await RemoteUpdater.create(
                    source: source,
                    installer: installer,
                    directoryName: config.directoryName,
                  )
                : RemoteUpdater(
                    source: source,
                    installer: installer,
                    downloadDirectory: downloadDirectory!,
                  );
            if (_disposed || generation != _generation || result.isCompleted) {
              return;
            }
            final candidate = await context.updater!
                .checkForUpdate(
                  request: UpdateRequest(
                    appId: config.appId,
                    channel: config.channel,
                    platform: config.target.name,
                    architecture: architecture,
                  ),
                  installedVersion: InstalledAppVersion(
                    appId: config.appId,
                    channel: config.channel,
                    platform: config.target.name,
                    architecture: architecture,
                    versionName: version.$1,
                    buildNumber: version.$2,
                  ),
                )
                .timeout(config.requestTimeout);
            if (!_disposed &&
                generation == _generation &&
                !result.isCompleted) {
              result.complete((context, candidate));
            }
          } catch (error) {
            if (remaining == 1 && !result.isCompleted) {
              result.completeError(error);
            }
          } finally {
            remaining--;
            if (remaining == 0 && !result.isCompleted) {
              result.completeError(StateError('更新已取消'));
            }
          }
        }());
      }
      final winner = await result.future;
      if (_disposed || generation != _generation) {
        throw AppUpdateFailure('更新已取消');
      }
      _selected = winner.$1;
      _candidate = winner.$2;
      _checkedKeys = snapshot;
      for (final context in List.of(_contexts)) {
        if (!identical(context, _selected)) unawaited(context.close());
      }
      if (!_sameSettings()) throw AppUpdateFailure('连接设置已改变，请重新检查更新');
      final candidate = _candidate;
      if (candidate == null) {
        return const AppUpdateInfo(
          status: AppUpdateStatus.upToDate,
          message: '当前已是最新版本',
        );
      }
      return AppUpdateInfo(
        status: AppUpdateStatus.available,
        latestVersion: candidate.manifest.versionName,
        latestBuild: candidate.manifest.buildNumber,
        releaseNotes: candidate.manifest.releaseNotesFor(config.locale),
        required: candidate.required,
        target: config.target,
        artifactSize: candidate.artifact.size,
      );
    } catch (error) {
      await _clear();
      return AppUpdateInfo(
        status: AppUpdateStatus.failed,
        message: _failureMessage(error),
      );
    } finally {
      _busy = false;
    }
  }

  @override
  bool get canCancel => _downloading && _cancellation != null;

  /// Revalidate after permission dialogs or disk checks, just before launch.
  void assertInstallationAllowed() {
    if (_disposed || !_sameSettings()) {
      throw AppUpdateFailure('更新已取消或连接设置已改变，请重新检查');
    }
    _cancellation?.throwIfCancelled();
  }

  @override
  void cancel() {
    if (!canCancel) return;
    _cancellation?.cancel();
    _selected?.client.close();
  }

  @override
  Future<void> install(
    AppUpdateInfo info, {
    void Function(AppUpdateProgress)? onProgress,
  }) async {
    final updater = _selected?.updater, candidate = _candidate;
    if (_disposed ||
        _busy ||
        updater == null ||
        candidate == null ||
        !info.isAvailable ||
        info.latestBuild != candidate.manifest.buildNumber ||
        info.latestVersion != candidate.manifest.versionName) {
      throw AppUpdateFailure('请重新检查更新');
    }
    if (!_sameSettings()) throw AppUpdateFailure('连接设置已改变，请重新检查更新');
    _busy = true;
    _downloading = true;
    final cancellation = UpdateCancellationToken();
    _cancellation = cancellation;
    var timedOut = false;
    final deadline = Timer(config.downloadTimeout, () {
      timedOut = true;
      cancellation.cancel();
      _selected?.client.close();
    });
    var received = 0, total = candidate.artifact.size;
    void progress(AppUpdatePhase phase) {
      if (!_disposed) {
        onProgress?.call(
          AppUpdateProgress(
            receivedBytes: received,
            totalBytes: total,
            phase: phase,
          ),
        );
      }
    }

    final subscription = updater.states.listen((state) {
      if (state case UpdateDownloading(
        :final receivedBytes,
        :final totalBytes,
      )) {
        received = receivedBytes;
        total = totalBytes;
        progress(AppUpdatePhase.downloading);
      } else if (state is UpdateVerifying) {
        progress(AppUpdatePhase.verifying);
      } else if (state case UpdateFailed(:final error)) {
        if (error.code == RemoteUpdateFailureCode.checksumMismatch ||
            error.code == RemoteUpdateFailureCode.sizeMismatch) {
          // A rejected response/package must not advertise resumable progress.
          progress(AppUpdatePhase.verifying);
        }
      }
    });
    try {
      final downloaded = await updater.download(
        candidate,
        cancellationToken: cancellation,
      );
      deadline.cancel();
      _downloading = false;
      received = candidate.artifact.size;
      total = candidate.artifact.size;
      progress(AppUpdatePhase.preparing);
      await beforeInstall?.call();
      if (_disposed || !_sameSettings()) {
        throw AppUpdateFailure('更新已取消或连接设置已改变，请重新检查');
      }
      cancellation.throwIfCancelled();
      progress(AppUpdatePhase.installing);
      await updater.install(downloaded);
      _candidate = null;
    } catch (error) {
      if (timedOut || cancellation.isCancelled) {
        await _clear();
        throw AppUpdateFailure(
          timedOut ? '下载超时，进度已保留。请继续下载。' : '已取消本次下载，进度已保留。可继续下载。',
        );
      }
      if (error is AppUpdateFailure) rethrow;
      throw AppUpdateFailure(_failureMessage(error));
    } finally {
      deadline.cancel();
      await subscription.cancel();
      _cancellation = null;
      _downloading = false;
      _busy = false;
    }
  }

  String _failureMessage(Object error) {
    if (error is AppUpdateFailure) return error.message.toString();
    final cause = error is RemoteUpdateException ? error.cause : error;
    if (cause is FileSystemException) {
      return '无法保存安装包，请检查存储空间后重试';
    }
    if (cause is TimeoutException) {
      return '下载超时，进度已保留。请继续下载。';
    }
    final custom = failureMessage?.call(cause ?? error, _downloading);
    if (custom != null) return custom;
    if (error is RemoteUpdateException) {
      if (error.code == RemoteUpdateFailureCode.downloadFailed) {
        return '下载中断，进度已保留。请检查网络后继续下载。';
      }
      if (error.code == RemoteUpdateFailureCode.checksumMismatch) {
        return '安装包校验失败，请重新下载';
      }
      if (error.code == RemoteUpdateFailureCode.sizeMismatch) {
        return '安装包大小与更新信息不一致，请重新检查更新';
      }
      if (error.code == RemoteUpdateFailureCode.installPermissionRequired) {
        return '请允许安装应用后重试';
      }
      if ([
        RemoteUpdateFailureCode.invalidManifest,
        RemoteUpdateFailureCode.appMismatch,
        RemoteUpdateFailureCode.channelMismatch,
        RemoteUpdateFailureCode.targetUnsupported,
      ].contains(error.code)) {
        return '更新清单无效或与当前应用不匹配，请稍后重试';
      }
    }
    if (error is FormatException) return '更新清单无效或与当前应用不匹配，请稍后重试';
    return '更新操作失败，请检查网络或关闭安装程序后重试';
  }

  Future<void> _clear() async {
    final contexts = List.of(_contexts);
    _contexts.clear();
    _selected = null;
    _candidate = null;
    _checkedKeys = null;
    await Future.wait(contexts.map((context) => context.close()));
  }

  @override
  void dispose() {
    _disposed = true;
    ++_generation;
    _cancellation?.cancel();
    unawaited(_clear());
  }
}

class _Endpoint {
  _Endpoint(this.client);
  final http.Client client;
  RemoteUpdater? updater;
  bool closed = false;
  Future<void> close() async {
    if (closed) return;
    closed = true;
    client.close();
    await updater?.close();
  }
}

class _TargetSource implements ResumableUpdateSource {
  _TargetSource(this.source, this.config, this.architecture);
  final UpdateSource source;
  final NativeAppUpdateConfig config;
  final String architecture;
  @override
  Future<UpdateManifest> fetchManifest(UpdateRequest request) async {
    final manifest = await source.fetchManifest(request);
    final artifact = manifest.artifactFor(
      platform: config.target.name,
      architecture: architecture,
    );
    if (artifact == null ||
        !artifact.path.toLowerCase().endsWith(config.extension) ||
        Uri.tryParse(artifact.path)?.hasScheme == true ||
        artifact.path.startsWith('/') ||
        (config.target == AppUpdateTarget.windows &&
            artifact.architecture != architecture)) {
      throw const FormatException('Update target mismatch');
    }
    return manifest;
  }

  @override
  Future<UpdateDownload> openDownload(UpdateArtifact artifact) =>
      source.openDownload(artifact);

  @override
  Future<UpdateDownload> openDownloadRange(
    UpdateArtifact artifact, {
    required int startByte,
  }) => source is ResumableUpdateSource
      ? (source as ResumableUpdateSource).openDownloadRange(
          artifact,
          startByte: startByte,
        )
      : source.openDownload(artifact);
}
