/// Pure Dart update manifest models for tooling that does not need Flutter.
///
/// Import this entry point from command-line tools and build scripts. The
/// Flutter-facing API remains available from `remote_update.dart`.
library;

export 'src/update_artifact.dart';
export 'src/update_manifest.dart';
