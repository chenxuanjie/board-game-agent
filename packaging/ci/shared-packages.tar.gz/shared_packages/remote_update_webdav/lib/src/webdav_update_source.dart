import 'dart:convert';

import 'package:remote_update/remote_update.dart';
import 'package:webdav_storage/webdav_storage.dart';

final class WebDavUpdateSource implements ResumableUpdateSource {
  WebDavUpdateSource({
    required RemoteStorage storage,
    required this.manifestPath,
    RemoteStreamStorage? streamStorage,
  }) : _storage = storage,
       _streamStorage = streamStorage ?? _requireStreamStorage(storage) {
    final normalized = manifestPath.replaceAll('\\', '/');
    if (normalized.trim().isEmpty ||
        normalized.startsWith('/') ||
        normalized.split('/').contains('..')) {
      throw ArgumentError.value(
        manifestPath,
        'manifestPath',
        'Must be a safe relative path.',
      );
    }
  }

  final RemoteStorage _storage;
  final RemoteStreamStorage _streamStorage;
  final String manifestPath;

  static RemoteStreamStorage _requireStreamStorage(RemoteStorage storage) {
    if (storage is RemoteStreamStorage) {
      return storage as RemoteStreamStorage;
    }
    throw ArgumentError(
      'storage must implement RemoteStreamStorage or streamStorage must be provided.',
    );
  }

  @override
  Future<UpdateManifest> fetchManifest(UpdateRequest request) async {
    try {
      final source = await _storage.downloadText(manifestPath);
      final json = Map<String, Object?>.from(jsonDecode(source) as Map);
      return UpdateManifest.fromJson(json);
    } on RemoteUpdateException {
      rethrow;
    } on FormatException catch (error) {
      throw RemoteUpdateException(
        RemoteUpdateFailureCode.invalidManifest,
        'The WebDAV update manifest is invalid.',
        cause: error,
      );
    } on WebDavException catch (error) {
      throw RemoteUpdateException(
        RemoteUpdateFailureCode.sourceUnavailable,
        'Failed to download the WebDAV update manifest.',
        cause: error,
      );
    } catch (error) {
      throw RemoteUpdateException(
        RemoteUpdateFailureCode.invalidManifest,
        'The WebDAV update manifest could not be decoded.',
        cause: error,
      );
    }
  }

  @override
  Future<UpdateDownload> openDownload(UpdateArtifact artifact) async {
    return openDownloadRange(artifact, startByte: 0);
  }

  @override
  Future<UpdateDownload> openDownloadRange(
    UpdateArtifact artifact, {
    required int startByte,
  }) async {
    if (startByte < 0 || startByte >= artifact.size) {
      throw ArgumentError.value(startByte, 'startByte');
    }
    try {
      final remotePath = _resolveArtifactPath(artifact.path);
      WebDavReadStream response;
      var offset = startByte;
      try {
        response = await _streamStorage.openRead(
          remotePath,
          startByte: offset == 0 ? null : offset,
        );
      } on WebDavException catch (error) {
        // A server may ignore Range or replace the published file. Never append
        // a full response to an existing prefix; restart only after opening it.
        if (offset == 0 || ![200, 416].contains(error.statusCode)) rethrow;
        response = await _streamStorage.openRead(remotePath);
        offset = 0;
      }
      if (offset > 0) {
        final range = RegExp(
          r'^bytes (\d+)-(\d+)/(\d+)$',
        ).firstMatch(response.headers['content-range'] ?? '');
        if (response.statusCode != 206 ||
            range == null ||
            int.parse(range.group(1)!) != offset ||
            int.parse(range.group(2)!) != artifact.size - 1 ||
            int.parse(range.group(3)!) != artifact.size ||
            (response.contentLength != null &&
                response.contentLength != artifact.size - offset)) {
          await response.bytes.listen((_) {}).cancel();
          throw const RemoteUpdateException(
            RemoteUpdateFailureCode.downloadFailed,
            'The update server returned an invalid download range.',
          );
        }
      }
      return UpdateDownload(
        bytes: response.bytes,
        contentLength: response.contentLength,
        startByte: offset,
      );
    } on WebDavException catch (error) {
      throw RemoteUpdateException(
        RemoteUpdateFailureCode.sourceUnavailable,
        'Failed to open the WebDAV update artifact.',
        cause: error,
      );
    }
  }

  String _resolveArtifactPath(String artifactPath) {
    final normalized = artifactPath.replaceAll('\\', '/');
    if (normalized.startsWith('/') ||
        Uri.tryParse(normalized)?.hasScheme == true) {
      throw const RemoteUpdateException(
        RemoteUpdateFailureCode.invalidManifest,
        'WebDAV artifact paths must be relative to the manifest.',
      );
    }
    final separator = manifestPath.replaceAll('\\', '/').lastIndexOf('/');
    final parent = separator < 0 ? '' : manifestPath.substring(0, separator);
    return parent.isEmpty ? normalized : '$parent/$normalized';
  }
}
