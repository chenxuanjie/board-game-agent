import 'sync_exception.dart';

final class SyncDeviceHead {
  const SyncDeviceHead({
    required this.deviceId,
    required this.sequence,
    required this.operationId,
    required this.updatedAt,
  });

  factory SyncDeviceHead.empty(String deviceId) => SyncDeviceHead(
    deviceId: deviceId,
    sequence: 0,
    operationId: null,
    updatedAt: DateTime.fromMillisecondsSinceEpoch(0, isUtc: true),
  );

  factory SyncDeviceHead.fromJson(Map<String, Object?> json) {
    final deviceId = _requiredString(json, 'deviceId');
    final sequence = _requiredInt(json, 'sequence');
    final operationId = json['operationId'];
    if (operationId != null &&
        (operationId is! String || operationId.trim().isEmpty)) {
      throw const SyncProtocolException('设备 head operationId 非法。');
    }
    final updatedAt = _requiredDate(json, 'updatedAt');
    if (sequence == 0 && operationId != null) {
      throw const SyncProtocolException('空 head 不能包含 operationId。');
    }
    if (sequence > 0 && operationId == null) {
      throw const SyncProtocolException('非空 head 必须包含 operationId。');
    }
    if (sequence < 0) {
      throw const SyncProtocolException('设备 head sequence 不能为负数。');
    }
    return SyncDeviceHead(
      deviceId: deviceId,
      sequence: sequence,
      operationId: operationId as String?,
      updatedAt: updatedAt,
    );
  }

  final String deviceId;
  final int sequence;
  final String? operationId;
  final DateTime updatedAt;

  Map<String, Object?> toJson() => {
    'deviceId': deviceId,
    'sequence': sequence,
    'operationId': operationId,
    'updatedAt': updatedAt.toUtc().toIso8601String(),
  };
}

/// Small remote index. It describes stream heads, never business rows.
final class SyncManifest {
  SyncManifest({
    required this.protocolVersion,
    required this.datasetId,
    required Map<String, SyncDeviceHead> devices,
    required DateTime updatedAt,
  }) : devices = Map.unmodifiable(devices),
       updatedAt = updatedAt.toUtc() {
    if (protocolVersion != 1) {
      throw SyncProtocolException('不支持的清单协议版本：$protocolVersion。');
    }
    if (datasetId.trim().isEmpty) {
      throw const SyncProtocolException('清单 datasetId 不能为空。');
    }
    for (final entry in this.devices.entries) {
      if (entry.key != entry.value.deviceId) {
        throw const SyncProtocolException('清单设备索引与 head 不一致。');
      }
    }
  }

  factory SyncManifest.empty(String datasetId, {DateTime? now}) => SyncManifest(
    protocolVersion: 1,
    datasetId: datasetId,
    devices: const {},
    updatedAt: now ?? DateTime.now().toUtc(),
  );

  factory SyncManifest.fromJson(Map<String, Object?> json) {
    final rawDevices = json['devices'];
    if (rawDevices is! List || rawDevices.any((item) => item is! Map)) {
      throw const SyncProtocolException('清单 devices 必须是对象数组。');
    }
    final devices = <String, SyncDeviceHead>{};
    for (final item in rawDevices) {
      final head = SyncDeviceHead.fromJson(
        Map<String, Object?>.from(item as Map),
      );
      if (devices.containsKey(head.deviceId)) {
        throw SyncProtocolException('清单重复设备：${head.deviceId}。');
      }
      devices[head.deviceId] = head;
    }
    return SyncManifest(
      protocolVersion: _requiredInt(json, 'protocolVersion'),
      datasetId: _requiredString(json, 'datasetId'),
      devices: devices,
      updatedAt: _requiredDate(json, 'updatedAt'),
    );
  }

  final int protocolVersion;
  final String datasetId;
  final Map<String, SyncDeviceHead> devices;
  final DateTime updatedAt;

  SyncManifest withHead(SyncDeviceHead head, {DateTime? now}) {
    if (head.deviceId.trim().isEmpty) {
      throw const SyncProtocolException('设备 ID 不能为空。');
    }
    return SyncManifest(
      protocolVersion: protocolVersion,
      datasetId: datasetId,
      devices: {...devices, head.deviceId: head},
      updatedAt: now ?? DateTime.now().toUtc(),
    );
  }

  Map<String, Object?> toJson() => {
    'protocolVersion': protocolVersion,
    'datasetId': datasetId,
    'devices': [
      for (final deviceId in devices.keys.toList()..sort())
        devices[deviceId]!.toJson(),
    ],
    'updatedAt': updatedAt.toUtc().toIso8601String(),
  };
}

String _requiredString(Map<String, Object?> json, String key) {
  final value = json[key];
  if (value is! String || value.trim().isEmpty) {
    throw SyncProtocolException('清单 $key 必须是非空字符串。');
  }
  return value;
}

int _requiredInt(Map<String, Object?> json, String key) {
  final value = json[key];
  if (value is! num || value.isNaN || value.isInfinite || value % 1 != 0) {
    throw SyncProtocolException('清单 $key 必须是整数。');
  }
  return value.toInt();
}

DateTime _requiredDate(Map<String, Object?> json, String key) {
  final value = json[key];
  final date = value is String ? DateTime.tryParse(value) : null;
  if (date == null) throw SyncProtocolException('清单 $key 无法解析。');
  return date;
}
