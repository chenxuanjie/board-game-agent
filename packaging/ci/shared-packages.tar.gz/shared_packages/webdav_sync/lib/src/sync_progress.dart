/// Coarse-grained phases emitted by the generic incremental sync engine.
///
/// These events describe one continuous sync task. They are intentionally
/// transport- and UI-agnostic so Flutter apps can choose their own feedback.
enum SyncPhase {
  preparing,
  checking,
  downloading,
  merging,
  uploading,
  completed,
  conflict,
  failed,
}

final class SyncProgress {
  const SyncProgress({
    required this.phase,
    this.round = 0,
    this.itemCount = 0,
    this.error,
  });

  final SyncPhase phase;
  final int round;
  final int itemCount;
  final Object? error;

  bool get isActive => switch (phase) {
    SyncPhase.preparing ||
    SyncPhase.checking ||
    SyncPhase.downloading ||
    SyncPhase.merging ||
    SyncPhase.uploading => true,
    SyncPhase.completed || SyncPhase.conflict || SyncPhase.failed => false,
  };
}

typedef SyncProgressCallback = void Function(SyncProgress progress);
