import 'sync_cursor.dart';

/// Local durable progress for both upload and pull sides of one device.
final class SyncCheckpoint {
  const SyncCheckpoint({
    required this.pullCursor,
    required this.uploadSequence,
  });

  factory SyncCheckpoint.empty() =>
      SyncCheckpoint(pullCursor: SyncCursor.empty(), uploadSequence: 0);

  factory SyncCheckpoint.fromJson(Map<String, Object?> json) {
    final rawCursor = json['pullCursor'];
    if (rawCursor is! Map) {
      throw const FormatException('同步检查点缺少 pullCursor。');
    }
    final rawSequence = json['uploadSequence'];
    if (rawSequence is! num || rawSequence % 1 != 0 || rawSequence < 0) {
      throw const FormatException('同步检查点 uploadSequence 非法。');
    }
    return SyncCheckpoint(
      pullCursor: SyncCursor.fromJson(Map<String, Object?>.from(rawCursor)),
      uploadSequence: rawSequence.toInt(),
    );
  }

  final SyncCursor pullCursor;
  final int uploadSequence;

  SyncCheckpoint copyWith({SyncCursor? pullCursor, int? uploadSequence}) {
    final nextSequence = uploadSequence ?? this.uploadSequence;
    if (nextSequence < 0) {
      throw ArgumentError.value(nextSequence, 'uploadSequence');
    }
    return SyncCheckpoint(
      pullCursor: pullCursor ?? this.pullCursor,
      uploadSequence: nextSequence,
    );
  }

  Map<String, Object?> toJson() => {
    'pullCursor': pullCursor.toJson(),
    'uploadSequence': uploadSequence,
  };
}
