import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:webdav_storage/webdav_storage.dart';

import 'canonical_json.dart';
import 'sync_exception.dart';
import 'sync_cursor.dart';
import 'sync_manifest.dart';
import 'sync_operation.dart';
import 'sync_remote_store.dart';
import 'webdav_sync_paths.dart';

const _initialLastModifiedSkew = Duration(seconds: 1);
const _maximumLastModifiedSkew = Duration(seconds: 5);

/// WebDAV-backed implementation of the generic operation repository.
///
/// It uses immutable operation files, per-device heads, and a small manifest.
/// The manifest is updated with ETag compare-and-swap and is never treated as
/// a business-data snapshot.
final class WebDavSyncStore implements SyncRemoteStore {
  WebDavSyncStore({
    required this.storage,
    required this.datasetId,
    String root = 'sync/v1',
    DateTime Function()? clock,
    this.maxCasRetries = 5,
  }) : paths = WebDavSyncPaths(root: root),
       clock = clock ?? DateTime.now {
    if (datasetId.trim().isEmpty) {
      throw ArgumentError.value(datasetId, 'datasetId');
    }
    if (maxCasRetries < 1) {
      throw ArgumentError.value(maxCasRetries, 'maxCasRetries');
    }
  }

  final RemoteStorage storage;
  final String datasetId;
  final WebDavSyncPaths paths;
  final DateTime Function() clock;
  final int maxCasRetries;

  @override
  Future<SyncRemoteSnapshot> read({required SyncCursor cursor}) async {
    final manifestDocument = await _readManifest();
    if (!manifestDocument.exists) {
      return SyncRemoteSnapshot(
        manifest: SyncManifest.empty(datasetId, now: clock()),
        operations: const [],
      );
    }
    final operations = await _readOperations(
      cursor: cursor,
      manifest: manifestDocument.manifest,
    );
    return SyncRemoteSnapshot(
      manifest: manifestDocument.manifest,
      operations: operations,
    );
  }

  @override
  Future<SyncAppendResult> append(SyncOperation operation) async {
    _validateOperation(operation);
    await storage.ensureDirectory(
      paths.operationsDirectory(operation.deviceId),
    );
    await storage.ensureDirectory(paths.devicesDirectory(operation.deviceId));
    final created = await _writeImmutableOperation(operation);
    final head = SyncDeviceHead(
      deviceId: operation.deviceId,
      sequence: operation.sequence,
      operationId: operation.operationId,
      updatedAt: operation.changedAt,
    );
    await _writeHead(head);
    await _updateManifest(head);
    return SyncAppendResult(
      created ? SyncAppendStatus.created : SyncAppendStatus.duplicate,
    );
  }

  Future<bool> _writeImmutableOperation(SyncOperation operation) async {
    final path = paths.operation(operation);
    try {
      await storage.uploadText(
        path,
        operation.canonicalJson,
        contentType: 'application/json; charset=utf-8',
        overwrite: false,
      );
      return true;
    } on WebDavException catch (error) {
      if (error.statusCode != 409 && error.statusCode != 412) rethrow;
      final existing = await _readOperation(path);
      if (existing == operation) return false;
      throw SyncProtocolException('不可变操作文件已存在但内容不一致：$path。', cause: error);
    }
  }

  Future<void> _writeHead(SyncDeviceHead next) async {
    String? previousConditionMarker;
    var lastModifiedSkew = _initialLastModifiedSkew;
    final path = paths.head(next.deviceId);
    for (var attempt = 0; attempt < maxCasRetries; attempt++) {
      final current = await _readHead(next.deviceId);
      if (current == null) {
        if (next.sequence != 1) {
          throw SyncProtocolException(
            '设备 ${next.deviceId} 的 head 缺失，不能直接写入 sequence ${next.sequence}。',
          );
        }
        try {
          await _uploadJson(path, next.toJson(), overwrite: false);
          return;
        } on WebDavException catch (error) {
          if (error.statusCode == 409 || error.statusCode == 412) continue;
          rethrow;
        }
      }

      final currentHead = current.head;
      if (currentHead.sequence > next.sequence) {
        return;
      }
      if (currentHead.sequence == next.sequence) {
        if (currentHead.operationId != next.operationId) {
          throw SyncProtocolException(
            '设备 ${next.deviceId} 的 sequence ${next.sequence} 对应多个 operationId。',
          );
        }
        return;
      }
      if (currentHead.sequence + 1 != next.sequence) {
        throw SyncProtocolException(
          '设备 ${next.deviceId} 的 head 出现序列间隙：${currentHead.sequence} -> ${next.sequence}。',
        );
      }
      final conditionMarker = _conditionMarker(
        current.etag,
        current.lastModified,
      );
      if (conditionMarker == previousConditionMarker) {
        lastModifiedSkew = _increaseLastModifiedSkew(lastModifiedSkew);
      } else {
        lastModifiedSkew = _initialLastModifiedSkew;
      }
      previousConditionMarker = conditionMarker;
      final condition = _casCondition(
        resource: 'head',
        etag: current.etag,
        lastModified: current.lastModified,
        lastModifiedSkew: lastModifiedSkew,
      );
      try {
        await _uploadJson(
          path,
          next.toJson(),
          ifMatch: condition.ifMatch,
          ifUnmodifiedSince: condition.ifUnmodifiedSince,
        );
        return;
      } on WebDavException catch (error) {
        if (error.statusCode == 409 || error.statusCode == 412) continue;
        rethrow;
      }
    }
    throw SyncProtocolException('head 条件更新重试次数耗尽：${next.deviceId}。');
  }

  Future<void> _updateManifest(SyncDeviceHead next) async {
    String? previousConditionMarker;
    var lastModifiedSkew = _initialLastModifiedSkew;
    for (var attempt = 0; attempt < maxCasRetries; attempt++) {
      final current = await _readManifest();
      final manifest = current.manifest;
      final existing = manifest.devices[next.deviceId];
      if (existing != null && existing.sequence > next.sequence) return;
      if (existing != null && existing.sequence == next.sequence) {
        if (existing.operationId != next.operationId) {
          throw SyncProtocolException(
            '清单中的 sequence ${next.sequence} 对应多个 operationId。',
          );
        }
        return;
      }
      final updated = manifest.withHead(next, now: clock());
      try {
        if (!current.exists) {
          await _uploadJson(paths.manifest, updated.toJson(), overwrite: false);
        } else {
          final conditionMarker = _conditionMarker(
            current.etag,
            current.lastModified,
          );
          if (conditionMarker == previousConditionMarker) {
            lastModifiedSkew = _increaseLastModifiedSkew(lastModifiedSkew);
          } else {
            lastModifiedSkew = _initialLastModifiedSkew;
          }
          previousConditionMarker = conditionMarker;
          final condition = _casCondition(
            resource: 'manifest',
            etag: current.etag,
            lastModified: current.lastModified,
            lastModifiedSkew: lastModifiedSkew,
          );
          await _uploadJson(
            paths.manifest,
            updated.toJson(),
            ifMatch: condition.ifMatch,
            ifUnmodifiedSince: condition.ifUnmodifiedSince,
          );
        }
        return;
      } on WebDavException catch (error) {
        if (error.statusCode == 412) continue;
        rethrow;
      }
    }
    throw const SyncProtocolException('manifest 条件更新重试次数耗尽。');
  }

  Future<List<SyncOperation>> _readOperations({
    required SyncCursor cursor,
    required SyncManifest manifest,
  }) async {
    final directoryStorage = storage is RemoteDirectoryStorage
        ? storage as RemoteDirectoryStorage
        : null;
    if (directoryStorage == null && manifest.devices.isNotEmpty) {
      throw const SyncProtocolException(
        '当前 WebDAV 存储未提供目录枚举（PROPFIND），无法按游标读取操作流。',
      );
    }

    final operations = <SyncOperation>[];
    for (final deviceId in manifest.devices.keys.toList()..sort()) {
      final head = manifest.devices[deviceId]!;
      final after = cursor.forDevice(deviceId);
      if (head.sequence <= after) continue;
      final resources = await directoryStorage!.list(
        paths.operationsDirectory(deviceId),
      );
      final filesBySequence = <int, RemoteResource>{};
      final filePattern = RegExp(r'^([1-9][0-9]*)-(.+)\.json$');
      for (final resource in resources) {
        if (resource.isCollection) continue;
        final match = filePattern.firstMatch(resource.name);
        if (match == null) continue;
        final sequence = int.tryParse(match.group(1)!);
        if (sequence == null || sequence <= after) continue;
        if (filesBySequence.containsKey(sequence)) {
          throw SyncProtocolException(
            '设备 $deviceId 存在重复 sequence $sequence 的操作文件。',
          );
        }
        filesBySequence[sequence] = resource;
      }

      for (var sequence = after + 1; sequence <= head.sequence; sequence++) {
        final resource = filesBySequence[sequence];
        if (resource == null) {
          throw SyncProtocolException(
            '设备 $deviceId 缺少 sequence $sequence 的操作文件。',
          );
        }
        final path = '${paths.operationsDirectory(deviceId)}/${resource.name}';
        final operation = await _readOperation(path);
        if (operation.datasetId != datasetId ||
            operation.deviceId != deviceId ||
            operation.sequence != sequence) {
          throw SyncProtocolException('操作文件与路径索引不一致：$path。');
        }
        if (resource.name != paths.operationFileName(operation)) {
          throw SyncProtocolException('操作文件名与 operationId 不一致：$path。');
        }
        operations.add(operation);
      }
    }

    operations.sort(_compareOperations);
    return List.unmodifiable(operations);
  }

  Future<SyncOperation> _readOperation(String path) async {
    try {
      final result = await storage.downloadBytes(path);
      final rawJson = utf8.decode(result.data);
      final decoded = Map<String, Object?>.from(jsonDecode(rawJson) as Map);
      try {
        return SyncOperation.fromJson(decoded);
      } on SyncProtocolException catch (error) {
        if (error.message != '操作 payloadHash 校验失败。' ||
            !_matchesLegacyRawPayloadHash(rawJson, decoded)) {
          rethrow;
        }

        // Older VM builds hashed integer-valued doubles as `2000.0`, while
        // JavaScript serializes the same value as `2000`. The raw legacy hash
        // is still verified before upgrading the in-memory operation to the
        // platform-independent canonical number representation.
        decoded['payloadHash'] = 'sha256:${sha256Json(decoded['payload'])}';
        return SyncOperation.fromJson(decoded);
      }
    } on SyncProtocolException catch (error, stackTrace) {
      // Preserve the protocol error while identifying the exact remote file.
      // This is essential for diagnosing one stale operation among many.
      Error.throwWithStackTrace(
        SyncProtocolException('远端操作文件校验失败：$path；${error.message}'),
        stackTrace,
      );
    }
  }

  bool _matchesLegacyRawPayloadHash(
    String rawJson,
    Map<String, Object?> decoded,
  ) {
    final declared = decoded['payloadHash'];
    if (declared is! String) return false;
    final rawPayload = _topLevelJsonValue(rawJson, 'payload');
    if (rawPayload == null) return false;
    final actual = sha256.convert(utf8.encode(rawPayload)).toString();
    return declared == 'sha256:$actual';
  }

  String? _topLevelJsonValue(String source, String key) {
    final marker = '"$key":';
    final markerIndex = source.indexOf(marker);
    if (markerIndex < 0) return null;
    final start = markerIndex + marker.length;
    var inString = false;
    var escaped = false;
    var objectDepth = 0;
    var arrayDepth = 0;
    for (var index = start; index < source.length; index++) {
      final char = source[index];
      if (inString) {
        if (escaped) {
          escaped = false;
        } else if (char == r'\') {
          escaped = true;
        } else if (char == '"') {
          inString = false;
        }
        continue;
      }
      if (char == '"') {
        inString = true;
      } else if (char == '{') {
        objectDepth++;
      } else if (char == '}') {
        if (objectDepth == 0 && arrayDepth == 0) {
          return source.substring(start, index).trim();
        }
        objectDepth--;
      } else if (char == '[') {
        arrayDepth++;
      } else if (char == ']') {
        arrayDepth--;
      } else if (char == ',' && objectDepth == 0 && arrayDepth == 0) {
        return source.substring(start, index).trim();
      }
    }
    return source.substring(start).trim();
  }

  Future<_HeadDocument?> _readHead(String deviceId) async {
    try {
      final result = await storage.downloadBytes(paths.head(deviceId));
      final decoded = jsonDecode(utf8.decode(result.data)) as Map;
      final head = SyncDeviceHead.fromJson(Map<String, Object?>.from(decoded));
      if (head.deviceId != deviceId) {
        throw SyncProtocolException('head 文件设备 ID 不一致：$deviceId。');
      }
      return _HeadDocument(
        head: head,
        etag: result.etag,
        lastModified: result.lastModified,
      );
    } on WebDavException catch (error) {
      if (error.statusCode == 404) return null;
      rethrow;
    }
  }

  Future<_ManifestDocument> _readManifest() async {
    try {
      final result = await storage.downloadBytes(paths.manifest);
      final decoded = jsonDecode(utf8.decode(result.data)) as Map;
      final manifest = SyncManifest.fromJson(
        Map<String, Object?>.from(decoded),
      );
      if (manifest.datasetId != datasetId) {
        throw SyncProtocolException(
          '远端 manifest datasetId 不一致：${manifest.datasetId}。',
        );
      }
      return _ManifestDocument(
        manifest: manifest,
        etag: result.etag,
        lastModified: result.lastModified,
        exists: true,
      );
    } on WebDavException catch (error) {
      if (error.statusCode == 404) {
        return _ManifestDocument(
          manifest: SyncManifest.empty(datasetId, now: clock()),
          etag: null,
          lastModified: null,
          exists: false,
        );
      }
      rethrow;
    }
  }

  Future<void> _uploadJson(
    String path,
    Map<String, Object?> json, {
    bool overwrite = true,
    String? ifMatch,
    String? ifUnmodifiedSince,
  }) => storage.uploadText(
    path,
    canonicalJson(json),
    contentType: 'application/json; charset=utf-8',
    overwrite: overwrite,
    ifMatch: ifMatch,
    ifUnmodifiedSince: ifUnmodifiedSince,
  );

  _CasCondition _casCondition({
    required String resource,
    required String? etag,
    required String? lastModified,
    Duration lastModifiedSkew = _initialLastModifiedSkew,
  }) {
    final normalizedEtag = etag?.trim();
    if (normalizedEtag != null &&
        normalizedEtag.isNotEmpty &&
        !normalizedEtag.toUpperCase().startsWith('W/')) {
      return _CasCondition(ifMatch: normalizedEtag);
    }
    final normalizedLastModified = lastModified?.trim();
    if (normalizedLastModified != null && normalizedLastModified.isNotEmpty) {
      // Some WebDAV servers (including the NAS used by Zheri) expose only a
      // weak ETag and truncate Last-Modified to whole seconds. Advancing the
      // condition by one second avoids false 412 responses caused by the
      // sub-second write time while still rejecting later modifications.
      return _CasCondition(
        ifUnmodifiedSince: _relaxLastModified(
          normalizedLastModified,
          skew: lastModifiedSkew,
        ),
      );
    }
    throw SyncProtocolException(
      'WebDAV 服务器未返回可用的 $resource ETag/Last-Modified，无法安全执行条件更新。',
    );
  }

  void _validateOperation(SyncOperation operation) {
    if (operation.datasetId != datasetId) {
      throw SyncProtocolException(
        '操作 datasetId 不一致：${operation.datasetId} != $datasetId。',
      );
    }
  }
}

String _conditionMarker(String? etag, String? lastModified) =>
    '${etag ?? ''}\u0000${lastModified ?? ''}';

Duration _increaseLastModifiedSkew(Duration current) {
  final next = current + const Duration(seconds: 1);
  return next.compareTo(_maximumLastModifiedSkew) > 0
      ? _maximumLastModifiedSkew
      : next;
}

String _relaxLastModified(
  String value, {
  Duration skew = _initialLastModifiedSkew,
}) {
  final match = RegExp(
    r'^[A-Za-z]{3}, (\d{2}) ([A-Za-z]{3}) (\d{4}) '
    r'(\d{2}):(\d{2}):(\d{2}) GMT$',
  ).firstMatch(value);
  if (match == null) return value;
  const monthNumbers = <String, int>{
    'JAN': 1,
    'FEB': 2,
    'MAR': 3,
    'APR': 4,
    'MAY': 5,
    'JUN': 6,
    'JUL': 7,
    'AUG': 8,
    'SEP': 9,
    'OCT': 10,
    'NOV': 11,
    'DEC': 12,
  };
  const weekdays = <String>['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const months = <String>[
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  final month = monthNumbers[match.group(2)!.toUpperCase()];
  if (month == null) return value;
  final updated = DateTime.utc(
    int.parse(match.group(3)!),
    month,
    int.parse(match.group(1)!),
    int.parse(match.group(4)!),
    int.parse(match.group(5)!),
    int.parse(match.group(6)!),
  ).add(skew);
  String twoDigits(int number) => number.toString().padLeft(2, '0');
  return '${weekdays[updated.weekday - 1]}, ${twoDigits(updated.day)} '
      '${months[updated.month - 1]} ${updated.year.toString().padLeft(4, '0')} '
      '${twoDigits(updated.hour)}:${twoDigits(updated.minute)}:'
      '${twoDigits(updated.second)} GMT';
}

final class _ManifestDocument {
  const _ManifestDocument({
    required this.manifest,
    required this.etag,
    required this.lastModified,
    required this.exists,
  });

  final SyncManifest manifest;
  final String? etag;
  final String? lastModified;
  final bool exists;
}

final class _HeadDocument {
  const _HeadDocument({
    required this.head,
    required this.etag,
    required this.lastModified,
  });

  final SyncDeviceHead head;
  final String? etag;
  final String? lastModified;
}

final class _CasCondition {
  const _CasCondition({this.ifMatch, this.ifUnmodifiedSince});

  final String? ifMatch;
  final String? ifUnmodifiedSince;
}

int _compareOperations(SyncOperation left, SyncOperation right) {
  final clock = left.logicalClock.compareTo(right.logicalClock);
  if (clock != 0) return clock;
  final device = left.deviceId.compareTo(right.deviceId);
  if (device != 0) return device;
  final sequence = left.sequence.compareTo(right.sequence);
  if (sequence != 0) return sequence;
  return left.operationId.compareTo(right.operationId);
}
