import 'package:webdav_storage/webdav_storage.dart';

enum SyncFailureKind {
  network,
  authentication,
  protocol,
  conflict,
  remoteUnavailable,
  unknown,
}

SyncFailureKind classifySyncFailure(Object error) {
  if (error is SyncProtocolException) return SyncFailureKind.protocol;
  if (error is SyncConflictException) return SyncFailureKind.conflict;
  if (error is WebDavException) {
    if (error.statusCode == 401 || error.statusCode == 403) {
      return SyncFailureKind.authentication;
    }
    if (error.statusCode == null || error.statusCode == 408) {
      return SyncFailureKind.network;
    }
    return SyncFailureKind.remoteUnavailable;
  }
  return SyncFailureKind.unknown;
}

/// Error raised when a remote sync document violates the protocol.
final class SyncProtocolException implements Exception {
  const SyncProtocolException(this.message, {this.cause});

  final String message;
  final Object? cause;

  @override
  String toString() => 'SyncProtocolException: $message';
}

/// Error raised when a sync operation cannot be applied without user input.
final class SyncConflictException implements Exception {
  const SyncConflictException(this.message);

  final String message;

  @override
  String toString() => 'SyncConflictException: $message';
}
