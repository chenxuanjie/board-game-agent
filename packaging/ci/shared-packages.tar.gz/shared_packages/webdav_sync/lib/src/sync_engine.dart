import 'dart:async';

import 'sync_checkpoint.dart';
import 'sync_conflict.dart';
import 'sync_exception.dart';
import 'sync_local_store.dart';
import 'sync_progress.dart';
import 'sync_remote_store.dart';
import 'sync_retry_policy.dart';

/// Coordinates pull, local application, immutable operation upload, and
/// durable cursors. The app adapter owns all business conflict decisions.
final class IncrementalSyncEngine {
  IncrementalSyncEngine({
    required this.local,
    required this.remote,
    this.batchSize = 500,
    this.maxRounds = 8,
    this.retryPolicy = const SyncRetryPolicy(),
    this.onProgress,
    Future<void> Function(Duration delay)? sleep,
  }) : _sleep = sleep ?? Future<void>.delayed {
    if (batchSize < 1) throw ArgumentError.value(batchSize, 'batchSize');
    if (maxRounds < 1) throw ArgumentError.value(maxRounds, 'maxRounds');
  }

  final SyncLocalStore local;
  final SyncRemoteStore remote;
  final int batchSize;
  final int maxRounds;
  final SyncRetryPolicy retryPolicy;
  final SyncProgressCallback? onProgress;
  final Future<void> Function(Duration delay) _sleep;

  Future<SyncResult> synchronize() async {
    _emit(SyncPhase.preparing);
    var checkpoint = await local.loadCheckpoint();
    var rounds = 0;
    var progressed = false;
    var stoppedOnConflict = false;
    final pull = _PullTotals();
    final push = _PushTotals();
    final conflicts = <SyncConflict>[];
    SyncFailureKind? failureKind;
    Object? failure;

    try {
      do {
        rounds++;
        progressed = false;

        _emit(SyncPhase.checking, round: rounds);
        final remoteSnapshot = await _withRetry(
          () => remote.read(cursor: checkpoint.pullCursor),
        );
        if (remoteSnapshot.operations.isNotEmpty) {
          _emit(
            SyncPhase.downloading,
            round: rounds,
            itemCount: remoteSnapshot.operations.length,
          );
          _emit(
            SyncPhase.merging,
            round: rounds,
            itemCount: remoteSnapshot.operations.length,
          );
          final applied = await local.applyRemoteOperations(
            operations: remoteSnapshot.operations,
            currentCursor: checkpoint.pullCursor,
          );
          checkpoint = checkpoint.copyWith(pullCursor: applied.cursor);
          await local.saveCheckpoint(checkpoint);
          pull.received += remoteSnapshot.operations.length;
          pull.applied += applied.applied;
          pull.skipped += applied.skipped;
          pull.duplicates += applied.duplicates;
          conflicts.addAll(applied.conflicts);
          progressed = true;
          if (applied.conflicts.isNotEmpty) {
            stoppedOnConflict = true;
            _emit(
              SyncPhase.conflict,
              round: rounds,
              itemCount: applied.conflicts.length,
            );
            break;
          }
        }

        final pending = await local.pendingOperations(
          afterSequence: checkpoint.uploadSequence,
          limit: batchSize,
        );
        if (pending.isNotEmpty) {
          _emit(SyncPhase.uploading, round: rounds, itemCount: pending.length);
        }
        for (final operation in pending) {
          if (operation.deviceId != local.deviceId) {
            throw StateError(
              '本地待上传操作设备不匹配: ${operation.deviceId} != ${local.deviceId}.',
            );
          }
          if (operation.sequence <= checkpoint.uploadSequence) continue;
          final result = await _withRetry(() => remote.append(operation));
          checkpoint = checkpoint.copyWith(
            uploadSequence: operation.sequence,
            pullCursor: checkpoint.pullCursor.advance(
              operation.deviceId,
              operation.sequence,
            ),
          );
          await local.saveCheckpoint(checkpoint);
          push.attempted++;
          if (result.created) {
            push.uploaded++;
          } else {
            push.duplicates++;
          }
          progressed = true;
        }
      } while (progressed && rounds < maxRounds);
    } catch (error) {
      failure = error;
      failureKind = classifySyncFailure(error);
      progressed = false;
      _emit(SyncPhase.failed, round: rounds, error: error);
    }

    if (failureKind == null && !stoppedOnConflict) {
      _emit(SyncPhase.completed, round: rounds);
    }

    return SyncResult(
      checkpoint: checkpoint,
      pull: pull.result,
      push: push.result,
      conflicts: List.unmodifiable(conflicts),
      rounds: rounds,
      completed: !progressed && !stoppedOnConflict && failureKind == null,
      failureKind: failureKind,
      failure: failure,
    );
  }

  void _emit(
    SyncPhase phase, {
    int round = 0,
    int itemCount = 0,
    Object? error,
  }) {
    onProgress?.call(
      SyncProgress(
        phase: phase,
        round: round,
        itemCount: itemCount,
        error: error,
      ),
    );
  }

  Future<T> _withRetry<T>(Future<T> Function() action) async {
    Object? lastError;
    StackTrace? lastStack;
    for (var attempt = 1; attempt <= retryPolicy.maxAttempts; attempt++) {
      try {
        return await action();
      } catch (error, stackTrace) {
        lastError = error;
        lastStack = stackTrace;
        if (attempt >= retryPolicy.maxAttempts ||
            !retryPolicy.shouldRetry(error)) {
          Error.throwWithStackTrace(error, stackTrace);
        }
        await _sleep(retryPolicy.delay * attempt);
      }
    }
    Error.throwWithStackTrace(lastError!, lastStack!);
  }
}

typedef SyncEngine = IncrementalSyncEngine;

final class SyncPullResult {
  const SyncPullResult({
    required this.received,
    required this.applied,
    required this.skipped,
    required this.duplicates,
  });

  final int received;
  final int applied;
  final int skipped;
  final int duplicates;
}

final class SyncPushResult {
  const SyncPushResult({
    required this.attempted,
    required this.uploaded,
    required this.duplicates,
  });

  final int attempted;
  final int uploaded;
  final int duplicates;
}

final class SyncResult {
  const SyncResult({
    required this.checkpoint,
    required this.pull,
    required this.push,
    required this.conflicts,
    required this.rounds,
    required this.completed,
    this.failureKind,
    this.failure,
  });

  final SyncCheckpoint checkpoint;
  final SyncPullResult pull;
  final SyncPushResult push;
  final List<SyncConflict> conflicts;
  final int rounds;
  final bool completed;
  final SyncFailureKind? failureKind;
  final Object? failure;

  bool get failed => failureKind != null;

  int get uploaded => push.uploaded;
  int get downloaded => pull.received;
  bool get hasConflicts => conflicts.isNotEmpty;
}

final class _PullTotals {
  var received = 0;
  var applied = 0;
  var skipped = 0;
  var duplicates = 0;

  SyncPullResult get result => SyncPullResult(
    received: received,
    applied: applied,
    skipped: skipped,
    duplicates: duplicates,
  );
}

final class _PushTotals {
  var attempted = 0;
  var uploaded = 0;
  var duplicates = 0;

  SyncPushResult get result => SyncPushResult(
    attempted: attempted,
    uploaded: uploaded,
    duplicates: duplicates,
  );
}
