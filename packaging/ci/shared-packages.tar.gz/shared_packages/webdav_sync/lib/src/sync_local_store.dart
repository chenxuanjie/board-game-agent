import 'sync_checkpoint.dart';
import 'sync_conflict.dart';
import 'sync_cursor.dart';
import 'sync_operation.dart';

/// Adapter contract implemented by an app's local SQLite/Drift layer.
///
/// `applyRemoteOperations` must commit business-row changes, applied-operation
/// idempotency records, and its returned cursor in one local transaction.
abstract interface class SyncLocalStore {
  String get deviceId;

  Future<SyncCheckpoint> loadCheckpoint();

  Future<List<SyncOperation>> pendingOperations({
    required int afterSequence,
    int limit = 500,
  });

  Future<SyncApplyResult> applyRemoteOperations({
    required Iterable<SyncOperation> operations,
    required SyncCursor currentCursor,
  });

  Future<void> saveCheckpoint(SyncCheckpoint checkpoint);
}

final class SyncApplyResult {
  const SyncApplyResult({
    required this.cursor,
    this.applied = 0,
    this.skipped = 0,
    this.duplicates = 0,
    this.conflicts = const [],
  });

  final SyncCursor cursor;
  final int applied;
  final int skipped;
  final int duplicates;
  final List<SyncConflict> conflicts;
}
