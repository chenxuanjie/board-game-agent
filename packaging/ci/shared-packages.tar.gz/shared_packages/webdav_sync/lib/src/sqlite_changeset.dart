import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:sqlite3/common.dart';

/// Wire-format version for the reusable SQLite changeset envelope.
const sqliteChangesetProtocolVersion = 1;

/// A self-contained binary changeset with enough metadata to reject an
/// incompatible or corrupted payload before it reaches the local database.
///
/// The envelope is deliberately independent from WebDAV. It can be stored in
/// an operation file, sent through another transport, or used in tests without
/// coupling the SQLite layer to the sync service.
final class SqliteChangesetEnvelope {
  SqliteChangesetEnvelope({
    required this.changesetId,
    required this.deviceId,
    required this.schemaVersion,
    required this.schemaHash,
    required this.createdAt,
    required Uint8List payload,
    this.protocolVersion = sqliteChangesetProtocolVersion,
    String? sha256,
  }) : payload = Uint8List.fromList(payload),
       sha256 = sha256 ?? sha256Digest(payload) {
    if (changesetId.trim().isEmpty) {
      throw ArgumentError.value(changesetId, 'changesetId');
    }
    if (deviceId.trim().isEmpty) {
      throw ArgumentError.value(deviceId, 'deviceId');
    }
    if (schemaVersion < 0) {
      throw ArgumentError.value(schemaVersion, 'schemaVersion');
    }
    if (schemaHash.trim().isEmpty) {
      throw ArgumentError.value(schemaHash, 'schemaHash');
    }
    if (this.sha256.length != 64) {
      throw ArgumentError.value(this.sha256, 'sha256');
    }
  }

  final int protocolVersion;
  final String changesetId;
  final String deviceId;
  final int schemaVersion;
  final String schemaHash;
  final DateTime createdAt;
  final Uint8List payload;
  final String sha256;

  /// Creates an envelope and calculates the payload digest.
  factory SqliteChangesetEnvelope.create({
    required String changesetId,
    required String deviceId,
    required int schemaVersion,
    required String schemaHash,
    required DateTime createdAt,
    required Uint8List payload,
  }) {
    return SqliteChangesetEnvelope(
      changesetId: changesetId,
      deviceId: deviceId,
      schemaVersion: schemaVersion,
      schemaHash: schemaHash,
      createdAt: createdAt.toUtc(),
      payload: payload,
    );
  }

  factory SqliteChangesetEnvelope.fromJson(Map<String, Object?> json) {
    final encodedPayload = json['payload'];
    if (encodedPayload is! String) {
      throw const FormatException('changeset payload must be base64 text');
    }
    final createdAt = DateTime.tryParse(json['createdAt'] as String? ?? '');
    if (createdAt == null) {
      throw const FormatException('changeset createdAt is invalid');
    }
    final protocolVersion = json['protocolVersion'];
    final schemaVersion = json['schemaVersion'];
    if (protocolVersion is! int || schemaVersion is! int) {
      throw const FormatException('changeset version metadata is invalid');
    }

    return SqliteChangesetEnvelope(
      protocolVersion: protocolVersion,
      changesetId: json['changesetId'] as String? ?? '',
      deviceId: json['deviceId'] as String? ?? '',
      schemaVersion: schemaVersion,
      schemaHash: json['schemaHash'] as String? ?? '',
      createdAt: createdAt.toUtc(),
      payload: Uint8List.fromList(base64Decode(encodedPayload)),
      sha256: json['sha256'] as String? ?? '',
    );
  }

  factory SqliteChangesetEnvelope.decode(String encoded) {
    final decoded = jsonDecode(encoded);
    if (decoded is! Map) {
      throw const FormatException('changeset envelope must be a JSON object');
    }
    return SqliteChangesetEnvelope.fromJson(
      decoded.map((key, value) => MapEntry('$key', value)),
    );
  }

  Map<String, Object?> toJson() => {
    'protocolVersion': protocolVersion,
    'changesetId': changesetId,
    'deviceId': deviceId,
    'schemaVersion': schemaVersion,
    'schemaHash': schemaHash,
    'createdAt': createdAt.toUtc().toIso8601String(),
    'sha256': sha256,
    'payload': base64Encode(payload),
  };

  String encode() => jsonEncode(toJson());

  /// Validates the envelope itself and optional database compatibility data.
  void validate({
    int expectedProtocolVersion = sqliteChangesetProtocolVersion,
    int? expectedSchemaVersion,
    String? expectedSchemaHash,
  }) {
    if (protocolVersion != expectedProtocolVersion) {
      throw SqliteChangesetValidationException(
        'Unsupported changeset protocol version $protocolVersion',
      );
    }
    final actualDigest = sha256Digest(payload);
    if (actualDigest != sha256) {
      throw SqliteChangesetValidationException(
        'Changeset payload digest does not match its metadata',
      );
    }
    if (expectedSchemaVersion != null &&
        schemaVersion != expectedSchemaVersion) {
      throw SqliteChangesetValidationException(
        'Changeset schema version $schemaVersion does not match '
        '$expectedSchemaVersion',
      );
    }
    if (expectedSchemaHash != null && schemaHash != expectedSchemaHash) {
      throw SqliteChangesetValidationException(
        'Changeset schema hash does not match the local database',
      );
    }
  }
}

/// Computes the hexadecimal SHA-256 digest used by changeset metadata.
String sha256Digest(Uint8List bytes) => sha256.convert(bytes).toString();

/// Computes a stable digest for the SQLite schema used by a changeset.
///
/// When [tables] is omitted, all user tables are included. Passing an explicit
/// allow-list is preferable for sync because unrelated local tables should not
/// invalidate an otherwise compatible changeset.
String sqliteSchemaHash(
  CommonDatabase database, {
  Iterable<String> tables = const [],
}) {
  final allowList = {
    for (final table in tables)
      if (table.trim().isNotEmpty) table.trim(),
  };
  final rows = database.select('''
    SELECT type, name, COALESCE(sql, '') AS sql
    FROM sqlite_master
    WHERE type IN ('table', 'index', 'trigger', 'view')
      AND name NOT LIKE 'sqlite_%'
    ORDER BY type, name
  ''');
  final canonical = <String>[
    for (final row in rows)
      if (allowList.isEmpty || allowList.contains(row['name']))
        '${row['type']}|${row['name']}|${row['sql']}',
  ].join('\n');
  return sha256Digest(Uint8List.fromList(utf8.encode(canonical)));
}

/// Captures row changes made through one SQLite connection.
///
/// The session must be created on the same [CommonDatabase] connection that
/// performs the writes. This is why this class is initially an isolated
/// prototype: Drift's native and Web worker connections still need a small
/// bridge before production code can use it directly.
final class SqliteChangesetCapture {
  SqliteChangesetCapture(this.database, {this.tables = const []});

  final CommonDatabase database;
  final List<String> tables;
  Session? _session;

  bool get isCapturing => _session != null;

  /// Starts a new capture window.
  void begin() {
    if (_session != null) {
      throw StateError('A SQLite changeset capture is already active');
    }
    final session = Session(database);
    try {
      if (tables.isEmpty) {
        session.attach();
      } else {
        for (final table in tables) {
          final normalized = table.trim();
          if (normalized.isEmpty) {
            throw ArgumentError.value(table, 'tables');
          }
          session.attach(normalized);
        }
      }
      _session = session;
    } on Object {
      session.delete();
      rethrow;
    }
  }

  /// Ends capture and returns null when no database row changed.
  SqliteChangesetEnvelope? finish({
    required String changesetId,
    required String deviceId,
    required int schemaVersion,
    required String schemaHash,
    DateTime? createdAt,
  }) {
    final session = _session;
    if (session == null) {
      throw StateError('No SQLite changeset capture is active');
    }
    try {
      if (session.isEmpty) return null;
      final bytes = Uint8List.fromList(session.changeset().bytes);
      return SqliteChangesetEnvelope.create(
        changesetId: changesetId,
        deviceId: deviceId,
        schemaVersion: schemaVersion,
        schemaHash: schemaHash,
        createdAt: createdAt ?? DateTime.now().toUtc(),
        payload: bytes,
      );
    } finally {
      session.delete();
      _session = null;
    }
  }

  /// Cancels capture without producing a changeset.
  void cancel() {
    final session = _session;
    _session = null;
    session?.delete();
  }

  /// Captures writes performed by [action] and closes the session afterwards.
  Future<SqliteChangesetEnvelope?> capture(
    FutureOr<void> Function() action, {
    required String changesetId,
    required String deviceId,
    required int schemaVersion,
    required String schemaHash,
    DateTime? createdAt,
  }) async {
    begin();
    try {
      await action();
      return finish(
        changesetId: changesetId,
        deviceId: deviceId,
        schemaVersion: schemaVersion,
        schemaHash: schemaHash,
        createdAt: createdAt,
      );
    } on Object {
      cancel();
      rethrow;
    }
  }
}

/// How SQLite should handle a conflict detected while applying a changeset.
enum SqliteChangesetConflictPolicy {
  /// Reject the whole changeset before mutating the target database.
  abort,

  /// Prefer the incoming row when SQLite reports a conflict.
  replace,

  /// Keep the local row when SQLite reports a conflict.
  omit,
}

/// A row-level conflict candidate found during the safe preflight pass.
///
/// SQLite's Session extension works at row granularity. The Zheri adapter can
/// later use [expectedOldValues] and [currentValues] to implement a compact
/// field-level preview, but this lower layer intentionally does not guess
/// business priorities such as whether a rename beats a price edit.
final class SqliteChangesetConflict {
  const SqliteChangesetConflict({
    required this.table,
    required this.operation,
    required this.kind,
    required this.expectedOldValues,
    required this.incomingValues,
    required this.currentValues,
  });

  final String table;
  final SqliteUpdateKind operation;
  final SqliteChangesetConflictKind kind;
  final List<Object?>? expectedOldValues;
  final List<Object?>? incomingValues;
  final List<Object?>? currentValues;

  @override
  String toString() =>
      'SqliteChangesetConflict(table: $table, operation: $operation, '
      'kind: $kind)';
}

enum SqliteChangesetConflictKind {
  /// The target row exists but no longer matches the changeset's base row.
  data,

  /// The changeset expected a row that is absent from the target database.
  notFound,

  /// The changeset inserted a primary key already used by another row.
  constraint,
}

final class SqliteChangesetApplyResult {
  const SqliteChangesetApplyResult({
    required this.applied,
    required this.alreadyApplied,
    required this.operations,
    required this.conflicts,
  });

  final bool applied;
  final bool alreadyApplied;
  final int operations;
  final List<SqliteChangesetConflict> conflicts;
}

final class SqliteChangesetConflictException implements Exception {
  const SqliteChangesetConflictException(this.conflicts);

  final List<SqliteChangesetConflict> conflicts;

  @override
  String toString() =>
      'SqliteChangesetConflictException(${conflicts.length} conflict(s))';
}

final class SqliteChangesetValidationException implements Exception {
  const SqliteChangesetValidationException(this.message);

  final String message;

  @override
  String toString() => 'SqliteChangesetValidationException: $message';
}

final class SqliteChangesetApplyException implements Exception {
  const SqliteChangesetApplyException(this.cause, this.stackTrace);

  final Object cause;
  final StackTrace stackTrace;

  @override
  String toString() => 'SqliteChangesetApplyException: $cause';
}

/// Applies a changeset after validating its metadata and checking the target
/// rows against the changeset's old values.
final class SqliteChangesetApplier {
  SqliteChangesetApplier(this.sqlite3);

  final CommonSqlite3 sqlite3;

  SqliteChangesetApplyResult apply(
    SqliteChangesetEnvelope envelope,
    CommonDatabase database, {
    int? expectedSchemaVersion,
    String? expectedSchemaHash,
    SqliteChangesetConflictPolicy policy = SqliteChangesetConflictPolicy.abort,
  }) {
    envelope.validate(
      expectedSchemaVersion: expectedSchemaVersion,
      expectedSchemaHash: expectedSchemaHash,
    );
    final changeset = Changeset.fromBytes(envelope.payload, sqlite3);
    final operations = [for (final operation in changeset) operation];
    final assessments = [
      for (final operation in operations) _assessOperation(database, operation),
    ];
    final conflicts = [
      for (final assessment in assessments)
        if (assessment.conflict != null) assessment.conflict!,
    ];

    if (policy == SqliteChangesetConflictPolicy.abort && conflicts.isNotEmpty) {
      throw SqliteChangesetConflictException(conflicts);
    }

    if (operations.isEmpty ||
        assessments.every((assessment) => assessment.alreadyApplied)) {
      return SqliteChangesetApplyResult(
        applied: false,
        alreadyApplied: operations.isNotEmpty,
        operations: operations.length,
        conflicts: conflicts,
      );
    }

    try {
      changeset.applyTo(
        database,
        ApplyChangesetOptions(
          onConflict: switch (policy) {
            SqliteChangesetConflictPolicy.abort => ApplyChangesetConflict.abort,
            SqliteChangesetConflictPolicy.replace =>
              ApplyChangesetConflict.replace,
            SqliteChangesetConflictPolicy.omit => ApplyChangesetConflict.omit,
          },
        ),
      );
    } on Object catch (error, stackTrace) {
      throw SqliteChangesetApplyException(error, stackTrace);
    }
    return SqliteChangesetApplyResult(
      applied: true,
      alreadyApplied: false,
      operations: operations.length,
      conflicts: conflicts,
    );
  }

  _OperationAssessment _assessOperation(
    CommonDatabase database,
    ChangesetOperation operation,
  ) {
    final tableInfo = _tableInfo(database, operation.table);
    if (tableInfo == null || tableInfo.primaryKeyIndexes.isEmpty) {
      // SQLite does not record changes for tables without a primary key. A
      // missing schema description therefore means there is no safe preflight
      // decision to make; SQLite itself remains the final authority.
      return const _OperationAssessment();
    }

    // For UPDATE rows SQLite stores the primary key in the old-value side;
    // unchanged columns in the old/new arrays are represented as undefined
    // (the Dart binding exposes those entries as null). INSERT uses new values
    // and DELETE uses old values.
    final values = operation.operation == SqliteUpdateKind.insert
        ? operation.newValues!
        : operation.oldValues!;
    final keyValues = [
      for (final index in tableInfo.primaryKeyIndexes) values[index],
    ];
    final current = _findRow(database, tableInfo, keyValues);

    switch (operation.operation) {
      case SqliteUpdateKind.insert:
        if (current == null) return const _OperationAssessment();
        if (_sameValues(current, operation.newValues!)) {
          return const _OperationAssessment(alreadyApplied: true);
        }
        return _OperationAssessment(
          conflict: SqliteChangesetConflict(
            table: operation.table,
            operation: operation.operation,
            kind: SqliteChangesetConflictKind.constraint,
            expectedOldValues: null,
            incomingValues: operation.newValues,
            currentValues: current,
          ),
        );
      case SqliteUpdateKind.update:
        if (current == null) {
          return _OperationAssessment(
            conflict: SqliteChangesetConflict(
              table: operation.table,
              operation: operation.operation,
              kind: SqliteChangesetConflictKind.notFound,
              expectedOldValues: operation.oldValues,
              incomingValues: operation.newValues,
              currentValues: null,
            ),
          );
        }
        if (_matchesDefinedValues(current, operation.newValues!)) {
          return const _OperationAssessment(alreadyApplied: true);
        }
        if (_matchesDefinedValues(current, operation.oldValues!)) {
          return const _OperationAssessment();
        }
        return _OperationAssessment(
          conflict: SqliteChangesetConflict(
            table: operation.table,
            operation: operation.operation,
            kind: SqliteChangesetConflictKind.data,
            expectedOldValues: operation.oldValues,
            incomingValues: operation.newValues,
            currentValues: current,
          ),
        );
      case SqliteUpdateKind.delete:
        if (current == null) {
          return const _OperationAssessment(alreadyApplied: true);
        }
        if (_matchesDefinedValues(current, operation.oldValues!)) {
          return const _OperationAssessment();
        }
        return _OperationAssessment(
          conflict: SqliteChangesetConflict(
            table: operation.table,
            operation: operation.operation,
            kind: SqliteChangesetConflictKind.data,
            expectedOldValues: operation.oldValues,
            incomingValues: null,
            currentValues: current,
          ),
        );
    }
  }

  _TableInfo? _tableInfo(CommonDatabase database, String table) {
    final escaped = _quoteIdentifier(table);
    final result = database.select('PRAGMA table_info($escaped)');
    if (result.isEmpty) return null;
    final primaryKeyIndexes = <({int order, int index})>[];
    for (final row in result) {
      final order = row['pk'];
      if (order is int && order > 0) {
        primaryKeyIndexes.add((order: order, index: row['cid'] as int));
      }
    }
    primaryKeyIndexes.sort((left, right) => left.order.compareTo(right.order));
    return _TableInfo(
      table: table,
      columns: [for (final row in result) row['name'] as String],
      primaryKeyIndexes: [for (final key in primaryKeyIndexes) key.index],
    );
  }

  List<Object?>? _findRow(
    CommonDatabase database,
    _TableInfo table,
    List<Object?> keyValues,
  ) {
    final predicates = [
      for (var index = 0; index < table.primaryKeyIndexes.length; index++)
        '${_quoteIdentifier(table.columns[table.primaryKeyIndexes[index]])} = ?',
    ];
    final result = database.select(
      'SELECT * FROM ${_quoteIdentifier(table.table)} '
      'WHERE ${predicates.join(' AND ')} LIMIT 1',
      keyValues,
    );
    return result.isEmpty ? null : List<Object?>.from(result.first.values);
  }
}

final class _TableInfo {
  const _TableInfo({
    required this.table,
    required this.columns,
    required this.primaryKeyIndexes,
  });

  final String table;
  final List<String> columns;
  final List<int> primaryKeyIndexes;
}

final class _OperationAssessment {
  const _OperationAssessment({this.alreadyApplied = false, this.conflict});

  final bool alreadyApplied;
  final SqliteChangesetConflict? conflict;
}

String _quoteIdentifier(String value) => '"${value.replaceAll('"', '""')}"';

bool _sameValues(List<Object?> left, List<Object?> right) {
  if (left.length != right.length) return false;
  for (var index = 0; index < left.length; index++) {
    if (!_sameValue(left[index], right[index])) return false;
  }
  return true;
}

/// Changeset UPDATE records omit unchanged columns. The public sqlite3 Dart
/// API represents both an omitted value and a SQL NULL as null, so the
/// preflight comparison intentionally treats null entries as unspecified. The
/// eventual production adapter will use SQLite's own conflict callback as the
/// final authority for nullable-column edge cases.
bool _matchesDefinedValues(List<Object?> current, List<Object?> expected) {
  if (current.length != expected.length) return false;
  for (var index = 0; index < current.length; index++) {
    final value = expected[index];
    if (value == null) continue;
    if (!_sameValue(current[index], value)) return false;
  }
  return true;
}

bool _sameValue(Object? left, Object? right) {
  if (left is num && right is num) return left == right;
  if (left is Uint8List && right is Uint8List) {
    if (left.length != right.length) return false;
    for (var index = 0; index < left.length; index++) {
      if (left[index] != right[index]) return false;
    }
    return true;
  }
  return left == right;
}
