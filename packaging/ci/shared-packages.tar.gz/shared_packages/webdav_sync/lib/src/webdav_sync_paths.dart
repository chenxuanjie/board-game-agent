import 'sync_exception.dart';
import 'sync_operation.dart';

/// Deterministic remote layout for one sync dataset.
final class WebDavSyncPaths {
  WebDavSyncPaths({required String root}) : root = _normalizeRoot(root);

  final String root;

  String get manifest => '$root/manifest.json';

  String devicesDirectory(String deviceId) =>
      '$root/devices/${_safeSegment(deviceId)}';

  String head(String deviceId) => '${devicesDirectory(deviceId)}/head.json';

  String operationsDirectory(String deviceId) =>
      '$root/operations/${_safeSegment(deviceId)}';

  String operationFileName(SyncOperation operation) =>
      '${operation.sequence}-${_safeSegment(operation.operationId)}.json';

  String operation(SyncOperation operation) =>
      '${operationsDirectory(operation.deviceId)}/${operationFileName(operation)}';
}

String _normalizeRoot(String value) {
  final normalized = value.replaceAll(r'\', '/');
  final segments = normalized
      .split('/')
      .where((segment) => segment.isNotEmpty)
      .toList(growable: false);
  if (segments.isEmpty ||
      segments.any((segment) => segment == '.' || segment == '..')) {
    throw const SyncProtocolException('同步根路径必须是安全的相对路径。');
  }
  return segments.join('/');
}

String _safeSegment(String value) {
  if (value.isEmpty ||
      value == '.' ||
      value == '..' ||
      value.contains('/') ||
      value.contains('\\')) {
    throw SyncProtocolException('同步路径段不安全：$value。');
  }
  return value;
}
