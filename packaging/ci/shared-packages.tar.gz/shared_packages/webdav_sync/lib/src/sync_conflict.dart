import 'sync_operation.dart';

enum SyncConflictStatus { unresolved, resolved, discarded }

/// A conflict is persisted as data so a UI can show and resolve it later.
final class SyncConflict {
  SyncConflict({
    required this.conflictId,
    required this.entityType,
    required this.entityId,
    required this.localOperation,
    required this.remoteOperation,
    required Iterable<String> commonParents,
    required this.reason,
    required this.status,
    required this.occurredAt,
  }) : commonParents = List<String>.unmodifiable(
         commonParents.toSet().toList()..sort(),
       ) {
    if (localOperation.entityType != entityType ||
        remoteOperation.entityType != entityType ||
        localOperation.entityId != entityId ||
        remoteOperation.entityId != entityId) {
      throw const FormatException('冲突操作与实体索引不一致。');
    }
  }

  factory SyncConflict.fromJson(Map<String, Object?> json) {
    final local = json['localOperation'];
    final remote = json['remoteOperation'];
    if (local is! Map || remote is! Map) {
      throw const FormatException('冲突缺少本地或远端操作。');
    }
    final statusName = json['status'];
    final status = switch (statusName) {
      'unresolved' => SyncConflictStatus.unresolved,
      'resolved' => SyncConflictStatus.resolved,
      'discarded' => SyncConflictStatus.discarded,
      _ => throw FormatException('未知冲突状态：$statusName。'),
    };
    final occurredAt = json['occurredAt'];
    final date = occurredAt is String ? DateTime.tryParse(occurredAt) : null;
    if (date == null) throw const FormatException('冲突 occurredAt 非法。');
    return SyncConflict(
      conflictId: _requiredString(json, 'conflictId'),
      entityType: _requiredString(json, 'entityType'),
      entityId: _requiredString(json, 'entityId'),
      localOperation: SyncOperation.fromJson(Map<String, Object?>.from(local)),
      remoteOperation: SyncOperation.fromJson(
        Map<String, Object?>.from(remote),
      ),
      commonParents: _requiredStrings(json, 'commonParents'),
      reason: _requiredString(json, 'reason'),
      status: status,
      occurredAt: date,
    );
  }

  final String conflictId;
  final String entityType;
  final String entityId;
  final SyncOperation localOperation;
  final SyncOperation remoteOperation;
  final List<String> commonParents;
  final String reason;
  final SyncConflictStatus status;
  final DateTime occurredAt;

  Map<String, Object?> toJson() => {
    'conflictId': conflictId,
    'entityType': entityType,
    'entityId': entityId,
    'localOperation': localOperation.toJson(),
    'remoteOperation': remoteOperation.toJson(),
    'commonParents': commonParents,
    'reason': reason,
    'status': status.name,
    'occurredAt': occurredAt.toUtc().toIso8601String(),
  };
}

List<String> _requiredStrings(Map<String, Object?> json, String key) {
  final value = json[key];
  if (value is! List || value.any((item) => item is! String)) {
    throw FormatException('冲突 $key 必须是字符串数组。');
  }
  return value.cast<String>();
}

String _requiredString(Map<String, Object?> json, String key) {
  final value = json[key];
  if (value is! String || value.trim().isEmpty) {
    throw FormatException('冲突 $key 必须是非空字符串。');
  }
  return value;
}
