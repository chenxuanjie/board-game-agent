import 'sync_cursor.dart';
import 'sync_manifest.dart';
import 'sync_operation.dart';

/// Remote side of the generic sync engine.
///
/// The interface deliberately exposes operations and indexes only. It has no
/// API for uploading a full database snapshot.
abstract interface class SyncRemoteStore {
  Future<SyncRemoteSnapshot> read({required SyncCursor cursor});

  Future<SyncAppendResult> append(SyncOperation operation);
}

/// Protocol-facing name used by adapters that prefer to describe the remote
/// append-only change feed rather than its WebDAV implementation.
typedef RemoteChangeStore = SyncRemoteStore;

enum SyncAppendStatus { created, duplicate }

final class SyncAppendResult {
  const SyncAppendResult(this.status);

  final SyncAppendStatus status;

  bool get created => status == SyncAppendStatus.created;
  bool get duplicate => status == SyncAppendStatus.duplicate;
}

final class SyncRemoteSnapshot {
  const SyncRemoteSnapshot({required this.manifest, required this.operations});

  final SyncManifest manifest;
  final List<SyncOperation> operations;
}
