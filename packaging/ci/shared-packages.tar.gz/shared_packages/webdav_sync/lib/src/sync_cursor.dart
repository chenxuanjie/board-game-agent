import 'sync_exception.dart';

/// Pull position for every device's append-only operation stream.
final class SyncCursor {
  const SyncCursor(this.positions);

  factory SyncCursor.empty() => const SyncCursor({});

  factory SyncCursor.fromJson(Map<String, Object?> json) {
    final positions = <String, int>{};
    for (final entry in json.entries) {
      final value = entry.value;
      if (entry.key.trim().isEmpty ||
          value is! num ||
          value.isNaN ||
          value.isInfinite ||
          value % 1 != 0 ||
          value < 0) {
        throw SyncProtocolException('游标包含非法位置：${entry.key}。');
      }
      positions[entry.key] = value.toInt();
    }
    return SyncCursor(Map.unmodifiable(positions));
  }

  final Map<String, int> positions;

  int forDevice(String deviceId) => positions[deviceId] ?? 0;

  SyncCursor advance(String deviceId, int sequence) {
    if (deviceId.trim().isEmpty || sequence < 0) {
      throw ArgumentError('游标设备 ID 不能为空，位置不能为负数。');
    }
    final current = forDevice(deviceId);
    if (sequence <= current) return this;
    return SyncCursor({...positions, deviceId: sequence});
  }

  SyncCursor merge(SyncCursor other) {
    final merged = <String, int>{...positions};
    for (final entry in other.positions.entries) {
      if (entry.value > (merged[entry.key] ?? 0)) {
        merged[entry.key] = entry.value;
      }
    }
    return SyncCursor(Map.unmodifiable(merged));
  }

  Map<String, Object?> toJson() => {
    for (final key in positions.keys.toList()..sort()) key: positions[key],
  };

  @override
  bool operator ==(Object other) =>
      other is SyncCursor && _mapsEqual(positions, other.positions);

  @override
  int get hashCode {
    final keys = positions.keys.toList()..sort();
    return Object.hashAll([
      for (final key in keys) Object.hash(key, positions[key]),
    ]);
  }
}

bool _mapsEqual(Map<String, int> left, Map<String, int> right) {
  if (left.length != right.length) return false;
  for (final entry in left.entries) {
    if (right[entry.key] != entry.value) return false;
  }
  return true;
}
