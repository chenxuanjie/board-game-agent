import 'canonical_json.dart' as canonical;
import 'sync_exception.dart';

enum SyncOperationType { upsert, delete }

/// One immutable business-entity change in the remote operation stream.
final class SyncOperation {
  SyncOperation({
    required this.protocolVersion,
    required this.datasetId,
    required this.operationId,
    required this.deviceId,
    required this.sequence,
    required this.logicalClock,
    required this.entityType,
    required this.entityId,
    required this.operation,
    required Map<String, Object?>? payload,
    required Iterable<String> parents,
    Iterable<String>? entityParents,
    Map<String, int> seen = const <String, int>{},
    required DateTime changedAt,
    String? payloadHash,
  }) : payload = _freezeMap(payload),
       parents = _normalizeParents(parents),
       entityParents = entityParents == null
           ? null
           : _normalizeEntityParents(entityParents),
       seen = _normalizeSeen(seen),
       changedAt = changedAt.toUtc(),
       payloadHash = payloadHash ?? _payloadHash(payload) {
    _validate();
  }

  factory SyncOperation.fromJson(Map<String, Object?> json) {
    final payload = json['payload'];
    if (payload != null && payload is! Map) {
      throw const SyncProtocolException('操作 payload 必须是对象或 null。');
    }
    final rawParents = json['parents'];
    if (rawParents is! List || rawParents.any((item) => item is! String)) {
      throw const SyncProtocolException('操作 parents 必须是字符串数组。');
    }
    final hasEntityParents = json.containsKey('entityParents');
    final rawEntityParents = json['entityParents'];
    if (hasEntityParents &&
        (rawEntityParents is! List ||
            rawEntityParents.any((item) => item is! String))) {
      throw const SyncProtocolException('操作 entityParents 必须是字符串数组。');
    }
    final rawSeen = json['seen'];
    if (rawSeen != null && rawSeen is! Map) {
      throw const SyncProtocolException('操作 seen 必须是对象。');
    }
    final seen = <String, int>{};
    if (rawSeen is Map) {
      for (final entry in rawSeen.entries) {
        final key = entry.key;
        final value = entry.value;
        if (key is! String ||
            key.trim().isEmpty ||
            value is! num ||
            value.isNaN ||
            value.isInfinite ||
            value % 1 != 0 ||
            value < 0) {
          throw const SyncProtocolException('操作 seen 包含非法设备序号。');
        }
        seen[key] = value.toInt();
      }
    }
    final operationName = json['operation'];
    final operation = switch (operationName) {
      'upsert' => SyncOperationType.upsert,
      'delete' => SyncOperationType.delete,
      _ => throw SyncProtocolException('未知操作类型：$operationName。'),
    };
    final changedAt = json['changedAt'];
    if (changedAt is! String) {
      throw const SyncProtocolException('操作 changedAt 必须是 ISO-8601 字符串。');
    }
    final parsedChangedAt = DateTime.tryParse(changedAt);
    if (parsedChangedAt == null) {
      throw SyncProtocolException('操作 changedAt 无法解析：$changedAt。');
    }

    final parsed = SyncOperation(
      protocolVersion: _requiredInt(json, 'protocolVersion'),
      datasetId: _requiredString(json, 'datasetId'),
      operationId: _requiredString(json, 'operationId'),
      deviceId: _requiredString(json, 'deviceId'),
      sequence: _requiredInt(json, 'sequence'),
      logicalClock: _requiredInt(json, 'logicalClock'),
      entityType: _requiredString(json, 'entityType'),
      entityId: _requiredString(json, 'entityId'),
      operation: operation,
      payload: payload == null
          ? null
          : Map<String, Object?>.from(payload as Map),
      parents: rawParents.cast<String>(),
      entityParents: hasEntityParents
          ? (rawEntityParents as List).cast<String>()
          : null,
      seen: seen,
      changedAt: parsedChangedAt,
      payloadHash: _requiredString(json, 'payloadHash'),
    );

    if (parsed.payloadHash != _payloadHash(parsed.payload)) {
      throw const SyncProtocolException('操作 payloadHash 校验失败。');
    }
    if (parsed.operation == SyncOperationType.delete &&
        parsed.payload != null) {
      throw const SyncProtocolException('删除操作不能包含 payload。');
    }
    if (parsed.operation == SyncOperationType.upsert &&
        parsed.payload == null) {
      throw const SyncProtocolException('upsert 操作必须包含 payload。');
    }
    return parsed;
  }

  final int protocolVersion;
  final String datasetId;
  final String operationId;
  final String deviceId;
  final int sequence;
  final int logicalClock;
  final String entityType;
  final String entityId;
  final SyncOperationType operation;
  final Map<String, Object?>? payload;

  /// Legacy/global causal parents. New operations should use entityParents.
  final List<String> parents;

  /// Version parents for this exact entity. Null means legacy operation.
  final List<String>? entityParents;

  /// Per-device causal frontier observed before this operation was created.
  final Map<String, int> seen;
  final DateTime changedAt;
  final String payloadHash;

  Map<String, Object?> toJson() => {
    'protocolVersion': protocolVersion,
    'datasetId': datasetId,
    'operationId': operationId,
    'deviceId': deviceId,
    'sequence': sequence,
    'logicalClock': logicalClock,
    'entityType': entityType,
    'entityId': entityId,
    'operation': operation.name,
    'payload': payload,
    'parents': parents,
    if (entityParents != null) 'entityParents': entityParents,
    if (seen.isNotEmpty) 'seen': seen,
    'changedAt': changedAt.toIso8601String(),
    'payloadHash': payloadHash,
  };

  String get canonicalJson => canonicalJsonFor(this);

  @override
  bool operator ==(Object other) =>
      other is SyncOperation && canonicalJson == other.canonicalJson;

  @override
  int get hashCode => canonicalJson.hashCode;

  static String canonicalJsonFor(SyncOperation operation) =>
      canonical.canonicalJson(operation.toJson());

  void _validate() {
    if (protocolVersion != 1) {
      throw SyncProtocolException('不支持的同步协议版本：$protocolVersion。');
    }
    _requireNonEmpty(datasetId, 'datasetId');
    _requireNonEmpty(operationId, 'operationId');
    _requireNonEmpty(deviceId, 'deviceId');
    _requireNonEmpty(entityType, 'entityType');
    _requireNonEmpty(entityId, 'entityId');
    if (sequence < 1) {
      throw const SyncProtocolException('操作 sequence 必须从 1 开始。');
    }
    if (logicalClock < 0) {
      throw const SyncProtocolException('操作 logicalClock 不能为负数。');
    }
    if (operation == SyncOperationType.delete && payload != null) {
      throw const SyncProtocolException('删除操作不能包含 payload。');
    }
    if (operation == SyncOperationType.upsert && payload == null) {
      throw const SyncProtocolException('upsert 操作必须包含 payload。');
    }
    if (!RegExp(r'^sha256:[0-9a-f]{64}$').hasMatch(payloadHash)) {
      throw const SyncProtocolException(
        'payloadHash 必须使用 sha256:<64 位小写十六进制> 格式。',
      );
    }
    if (parents.any((parent) => parent == operationId)) {
      throw const SyncProtocolException('操作不能把自身列为父版本。');
    }
  }

  static void _requireNonEmpty(String value, String name) {
    if (value.trim().isEmpty) {
      throw SyncProtocolException('$name 不能为空。');
    }
  }
}

Map<String, Object?>? _freezeMap(Map<String, Object?>? value) {
  if (value == null) return null;
  final canonicalValue = canonical.canonicalizeJson(value);
  return Map<String, Object?>.unmodifiable(
    canonicalValue! as Map<String, Object?>,
  );
}

List<String> _normalizeParents(Iterable<String> values) {
  final parents = values.toSet().toList()..sort();
  if (parents.any((parent) => parent.trim().isEmpty)) {
    throw const SyncProtocolException('操作 parents 不能包含空值。');
  }
  return List<String>.unmodifiable(parents);
}

List<String> _normalizeEntityParents(Iterable<String> values) {
  final parents = values.toSet().toList()..sort();
  if (parents.any((parent) => parent.trim().isEmpty)) {
    throw const SyncProtocolException('操作 entityParents 不能包含空值。');
  }
  return List<String>.unmodifiable(parents);
}

Map<String, int> _normalizeSeen(Map<String, int> values) {
  final normalized = <String, int>{};
  for (final entry in values.entries) {
    if (entry.key.trim().isEmpty || entry.value < 0) {
      throw const SyncProtocolException('操作 seen 包含非法设备序号。');
    }
    normalized[entry.key] = entry.value;
  }
  final keys = normalized.keys.toList()..sort();
  return Map.unmodifiable({for (final key in keys) key: normalized[key]!});
}

String _payloadHash(Object? payload) =>
    'sha256:${canonical.sha256Json(payload)}';

String _requiredString(Map<String, Object?> json, String key) {
  final value = json[key];
  if (value is! String || value.trim().isEmpty) {
    throw SyncProtocolException('操作 $key 必须是非空字符串。');
  }
  return value;
}

int _requiredInt(Map<String, Object?> json, String key) {
  final value = json[key];
  if (value is! num || value.isNaN || value.isInfinite || value % 1 != 0) {
    throw SyncProtocolException('操作 $key 必须是整数。');
  }
  return value.toInt();
}
