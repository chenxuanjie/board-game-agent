import 'package:webdav_storage/webdav_storage.dart';

import 'sync_exception.dart';

final class SyncRetryPolicy {
  const SyncRetryPolicy({
    this.maxAttempts = 3,
    this.delay = const Duration(milliseconds: 250),
  }) : assert(maxAttempts > 0);

  final int maxAttempts;
  final Duration delay;

  bool shouldRetry(Object error) {
    if (error is SyncProtocolException || error is SyncConflictException) {
      return false;
    }
    if (error is WebDavException) {
      final status = error.statusCode;
      return status == null || status == 408 || status == 429 || status >= 500;
    }
    return false;
  }
}
