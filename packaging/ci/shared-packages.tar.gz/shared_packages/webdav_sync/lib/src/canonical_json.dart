import 'dart:convert';

import 'package:crypto/crypto.dart';

/// Returns a deeply immutable JSON-compatible value with object keys sorted.
///
/// Stable ordering makes hashes and idempotency comparisons independent of the
/// map insertion order used by an app adapter.
Object? canonicalizeJson(Object? value) {
  if (value is num) {
    if (!value.isFinite) {
      throw ArgumentError.value(value, 'value', 'JSON numbers must be finite.');
    }
    // Dart VM preserves 2000.0 while JavaScript represents it as 2000.
    // Normalize integer-valued numbers so hashes are platform independent.
    return value % 1 == 0 ? value.toInt() : value;
  }
  if (value == null || value is String || value is bool) {
    return value;
  }
  if (value is List) {
    return List<Object?>.unmodifiable(value.map<Object?>(canonicalizeJson));
  }
  if (value is Map) {
    final entries = <MapEntry<String, Object?>>[];
    for (final entry in value.entries) {
      if (entry.key is! String) {
        throw ArgumentError.value(
          entry.key,
          'value',
          'JSON object keys must be strings.',
        );
      }
      entries.add(MapEntry(entry.key as String, canonicalizeJson(entry.value)));
    }
    entries.sort((left, right) => left.key.compareTo(right.key));
    return Map<String, Object?>.unmodifiable({
      for (final entry in entries) entry.key: entry.value,
    });
  }
  throw ArgumentError.value(value, 'value', 'Value is not JSON-compatible.');
}

/// Encodes a JSON-compatible value with deterministic object-key ordering.
String canonicalJson(Object? value) => jsonEncode(canonicalizeJson(value));

/// Calculates the SHA-256 hash used by sync operation payloads.
String sha256Json(Object? value) =>
    sha256.convert(utf8.encode(canonicalJson(value))).toString();
