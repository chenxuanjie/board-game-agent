import 'package:http/http.dart' as http;

http.Client createDefaultAiHttpClient() => http.Client();
