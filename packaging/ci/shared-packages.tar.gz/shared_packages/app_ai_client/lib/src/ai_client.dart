import 'models.dart';

/// Provider-neutral contract consumed by application-specific AI services.
abstract interface class AiClient {
  Future<List<AiModel>> listModels(AiEndpointConfig endpoint);

  Future<AiResponse> complete(AiRequest request);

  Stream<AiStreamEvent> stream(AiRequest request, {Future<void>? abortTrigger});

  Future<AiHealthResult> check(AiEndpointConfig endpoint);

  void close();
}
