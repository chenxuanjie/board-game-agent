import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';
import 'package:win32_registry/win32_registry.dart';

http.Client createDefaultAiHttpClient() {
  final HttpClient client = HttpClient()
    ..connectionTimeout = const Duration(seconds: 20)
    ..findProxy = _findProxy;
  return IOClient(client);
}

String _findProxy(Uri uri) {
  final String environmentProxy = HttpClient.findProxyFromEnvironment(uri);
  if (environmentProxy.trim().toUpperCase() != 'DIRECT') {
    return environmentProxy;
  }

  final String? windowsProxy = _readWindowsProxy(uri);
  if (windowsProxy == null || windowsProxy.isEmpty) {
    return environmentProxy;
  }
  return 'PROXY $windowsProxy; DIRECT';
}

String? _readWindowsProxy(Uri uri) {
  if (!Platform.isWindows) {
    return null;
  }

  RegistryKey? key;
  try {
    key = Registry.openPath(
      RegistryHive.currentUser,
      path: r'Software\Microsoft\Windows\CurrentVersion\Internet Settings',
    );
    if (key.getIntValue('ProxyEnable') != 1) {
      return null;
    }

    final String? rawProxy = key.getStringValue('ProxyServer')?.trim();
    if (rawProxy == null || rawProxy.isEmpty) {
      return null;
    }

    final List<String> entries = rawProxy
        .split(';')
        .map((String value) => value.trim())
        .where((String value) => value.isNotEmpty)
        .toList(growable: false);
    final String schemePrefix = '${uri.scheme.toLowerCase()}=';
    for (final String entry in entries) {
      if (entry.toLowerCase().startsWith(schemePrefix)) {
        return entry.substring(schemePrefix.length).trim();
      }
    }
    return entries.any((String entry) => entry.contains('='))
        ? null
        : entries.first;
  } catch (_) {
    return null;
  } finally {
    key?.close();
  }
}
