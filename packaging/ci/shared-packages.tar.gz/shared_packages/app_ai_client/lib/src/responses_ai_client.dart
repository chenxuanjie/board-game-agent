import 'responses_models.dart';

/// Provider-neutral Responses API contract.
abstract interface class ResponsesAiClient {
  Future<ResponsesResponse> complete(
    ResponsesRequest request, {
    Future<void>? abortTrigger,
  });

  Stream<ResponsesStreamEvent> stream(
    ResponsesRequest request, {
    Future<void>? abortTrigger,
  });

  void close();
}
