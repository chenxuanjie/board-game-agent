/// The participant role for a plain-text chat message.
enum AiMessageRole { system, user, assistant }

/// Provider-neutral model metadata returned by an OpenAI-compatible `/models`.
class AiModel {
  const AiModel({
    required this.id,
    this.displayName,
    this.ownedBy,
    this.createdAt,
  });

  final String id;
  final String? displayName;
  final String? ownedBy;
  final DateTime? createdAt;

  String get label =>
      displayName?.trim().isNotEmpty == true ? displayName!.trim() : id;

  @override
  bool operator ==(Object other) => other is AiModel && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

/// A provider-neutral plain-text chat message.
class AiMessage {
  const AiMessage({required this.role, required this.content});

  const AiMessage.system(String content)
    : role = AiMessageRole.system,
      content = content;

  const AiMessage.user(String content)
    : role = AiMessageRole.user,
      content = content;

  const AiMessage.assistant(String content)
    : role = AiMessageRole.assistant,
      content = content;

  final AiMessageRole role;
  final String content;
}

/// Retry policy independent from a specific provider SDK.
class AiRetryPolicy {
  const AiRetryPolicy({
    this.maxRetries = 2,
    this.initialDelay = const Duration(milliseconds: 500),
    this.maxDelay = const Duration(seconds: 8),
    this.jitter = 0.1,
  }) : assert(maxRetries >= 0),
       assert(jitter >= 0 && jitter <= 1);

  final int maxRetries;
  final Duration initialDelay;
  final Duration maxDelay;
  final double jitter;
}

/// Connection settings for an OpenAI-compatible chat endpoint.
///
/// Keep this object at an integration boundary. Production mobile apps should
/// normally point to an application gateway rather than embed an upstream key.
class AiEndpointConfig {
  const AiEndpointConfig({
    required this.name,
    required this.baseUrl,
    required this.apiKey,
    required this.model,
    this.apiKeyHeader = 'Authorization',
    this.chatPath = '/chat/completions',
    this.defaultHeaders = const <String, String>{},
    this.timeout = const Duration(seconds: 60),
    this.connectTimeout = const Duration(seconds: 20),
    this.modelListTimeout = const Duration(seconds: 15),
    this.retryPolicy = const AiRetryPolicy(),
  });

  final String name;
  final String baseUrl;
  final String apiKey;
  final String model;

  /// Header used to carry [apiKey].
  ///
  /// When this is `Authorization`, the OpenAI-compatible adapter sends the
  /// value as `Bearer <apiKey>`. Other headers receive the raw key value.
  final String apiKeyHeader;
  final String chatPath;
  final Map<String, String> defaultHeaders;
  final Duration timeout;
  final Duration connectTimeout;

  /// Hard deadline for model discovery.
  ///
  /// Model discovery is a settings operation, so it should fail visibly
  /// instead of leaving a settings panel in a loading state for the much
  /// longer chat-completion deadline.
  final Duration modelListTimeout;
  final AiRetryPolicy retryPolicy;
}

/// Generation controls that are common to OpenAI-compatible chat APIs.
class AiGenerationOptions {
  const AiGenerationOptions({
    this.temperature,
    this.topP,
    this.maxCompletionTokens,
    this.frequencyPenalty,
    this.presencePenalty,
    this.user,
    this.reasoningEffort,
    this.serviceTier,
  });

  final double? temperature;
  final double? topP;
  final int? maxCompletionTokens;
  final double? frequencyPenalty;
  final double? presencePenalty;
  final String? user;

  /// Optional OpenAI-compatible reasoning effort, such as `low`, `medium`,
  /// or `high`. Keep this null unless the caller explicitly selected a value;
  /// many compatible providers do not implement this optional field.
  final String? reasoningEffort;

  /// Optional provider service tier / response-speed hint. The exact values
  /// are provider-specific (for example `default` or `fast`), so the
  /// shared package forwards an explicit value without inventing a portable
  /// speed guarantee.
  final String? serviceTier;
}

/// A model completion request without app-domain concepts or provider types.
class AiRequest {
  AiRequest({
    required this.endpoint,
    required List<AiMessage> messages,
    this.options = const AiGenerationOptions(),
  }) : messages = List<AiMessage>.unmodifiable(messages);

  final AiEndpointConfig endpoint;
  final List<AiMessage> messages;
  final AiGenerationOptions options;
}

/// Token usage reported by a provider, when available.
class AiUsage {
  const AiUsage({
    required this.promptTokens,
    required this.totalTokens,
    this.completionTokens,
    this.reasoningTokens,
  });

  final int promptTokens;
  final int totalTokens;
  final int? completionTokens;

  /// Tokens spent on hidden reasoning, when the provider reports them.
  final int? reasoningTokens;
}

/// A normalized completion response.
class AiResponse {
  const AiResponse({
    required this.text,
    required this.model,
    this.id,
    this.finishReason,
    this.usage,
  });

  final String text;
  final String model;
  final String? id;
  final String? finishReason;
  final AiUsage? usage;
}

/// A normalized streaming update.
class AiStreamEvent {
  const AiStreamEvent({
    required this.delta,
    this.model,
    this.finishReason,
    this.usage,
  });

  final String delta;
  final String? model;
  final String? finishReason;
  final AiUsage? usage;
}

/// Result of a small provider request used to validate endpoint settings.
class AiHealthResult {
  const AiHealthResult({
    required this.success,
    required this.message,
    required this.latency,
    this.model,
  });

  final bool success;
  final String message;
  final Duration latency;
  final String? model;
}
