import 'models.dart';

/// Role used by a Responses input message.
enum ResponsesInputRole { user, assistant, developer }

extension ResponsesInputRoleX on ResponsesInputRole {
  String get wireValue => switch (this) {
    ResponsesInputRole.user => 'user',
    ResponsesInputRole.assistant => 'assistant',
    ResponsesInputRole.developer => 'developer',
  };
}

/// A provider-neutral input item for the Responses API.
sealed class ResponsesInputItem {
  const ResponsesInputItem({this.role = ResponsesInputRole.user});

  final ResponsesInputRole role;

  Map<String, dynamic> toJson();
}

/// Plain text input. Assistant items are serialized as `output_text` so they
/// can safely be sent as conversation history.
class ResponsesTextInput extends ResponsesInputItem {
  const ResponsesTextInput(this.text, {super.role});

  final String text;

  @override
  Map<String, dynamic> toJson() => <String, dynamic>{
    'type': 'message',
    'role': role.wireValue,
    'content': <Map<String, dynamic>>[
      <String, dynamic>{
        'type': role == ResponsesInputRole.assistant
            ? 'output_text'
            : 'input_text',
        'text': text,
      },
    ],
  };
}

/// File input from a public URL or base64 data downloaded by the app.
class ResponsesFileInput extends ResponsesInputItem {
  const ResponsesFileInput.url(
    this.fileUrl, {
    super.role,
    this.filename,
    this.detail,
  }) : fileData = null,
       mediaType = null;

  const ResponsesFileInput.data(
    this.fileData, {
    required this.mediaType,
    super.role,
    this.filename,
    this.detail,
  }) : fileUrl = null;

  final String? fileUrl;
  final String? fileData;
  final String? mediaType;
  final String? filename;
  final String? detail;

  @override
  Map<String, dynamic> toJson() => <String, dynamic>{
    'type': 'message',
    'role': role.wireValue,
    'content': <Map<String, dynamic>>[
      <String, dynamic>{
        'type': 'input_file',
        if (fileUrl != null) 'file_url': fileUrl,
        if (fileData != null)
          'file_data':
              'data:${mediaType ?? 'application/octet-stream'};base64,$fileData',
        if (filename != null) 'filename': filename,
        if (detail != null) 'detail': detail,
      },
    ],
  };
}

/// A raw Responses output item that must be round-tripped as input.
///
/// Responses compaction returns opaque encrypted items. They are not meant to
/// be rendered as chat text, but the client must send them back on a later
/// turn to continue the compacted conversation.
class ResponsesRawInput extends ResponsesInputItem {
  const ResponsesRawInput(this.value);

  final Map<String, dynamic> value;

  @override
  Map<String, dynamic> toJson() => Map<String, dynamic>.unmodifiable(value);
}

/// A built-in Responses tool definition.
class ResponsesToolDefinition {
  const ResponsesToolDefinition.webSearch({this.searchContextSize = 'medium'})
    : kind = ResponsesToolKind.webSearch;

  final ResponsesToolKind kind;
  final String? searchContextSize;
}

enum ResponsesToolKind { webSearch }

/// Server-side context management requested from a Responses provider.
class ResponsesContextManagement {
  const ResponsesContextManagement({required this.type, this.compactThreshold});

  const ResponsesContextManagement.compaction({this.compactThreshold})
    : type = 'compaction';

  final String type;
  final int? compactThreshold;
}

/// A provider-neutral structured output format for Responses text.
///
/// This intentionally models only the JSON Schema form needed by the app's
/// small routing classifier. Providers that do not support the field can fall
/// back to a plain-text request and the caller can still use its safe local
/// route.
class ResponsesStructuredOutput {
  const ResponsesStructuredOutput.jsonSchema({
    required this.name,
    required this.schema,
    this.description,
    this.strict = true,
  });

  final String name;
  final String? description;
  final Map<String, dynamic> schema;
  final bool strict;
}

/// Provider-neutral Responses request.
class ResponsesRequest {
  ResponsesRequest({
    required this.endpoint,
    required List<ResponsesInputItem> input,
    this.instructions,
    List<ResponsesToolDefinition> tools = const <ResponsesToolDefinition>[],
    this.maxOutputTokens,
    this.reasoningEffort,
    this.serviceTier,
    List<ResponsesContextManagement> contextManagement =
        const <ResponsesContextManagement>[],
    this.structuredOutput,
    this.store = false,
  }) : input = List<ResponsesInputItem>.unmodifiable(input),
       tools = List<ResponsesToolDefinition>.unmodifiable(tools),
       contextManagement = List<ResponsesContextManagement>.unmodifiable(
         contextManagement,
       );

  final AiEndpointConfig endpoint;
  final List<ResponsesInputItem> input;
  final String? instructions;
  final List<ResponsesToolDefinition> tools;
  final int? maxOutputTokens;
  final String? reasoningEffort;
  final String? serviceTier;
  final List<ResponsesContextManagement> contextManagement;
  final ResponsesStructuredOutput? structuredOutput;
  final bool store;
}

/// A file citation returned by Responses.
class ResponsesFileCitation {
  const ResponsesFileCitation({required this.fileId, required this.filename});

  final String fileId;
  final String filename;
}

/// A web citation returned by Responses web search.
class ResponsesWebSearchCitation {
  const ResponsesWebSearchCitation({required this.url, required this.title});

  final String url;
  final String title;
}

/// Normalized Responses response.
class ResponsesResponse {
  const ResponsesResponse({
    required this.text,
    required this.model,
    this.id,
    this.status,
    this.fileCitations = const <ResponsesFileCitation>[],
    this.webSearchCitations = const <ResponsesWebSearchCitation>[],
    this.outputItems = const <ResponsesInputItem>[],
    this.usage,
  });

  final String text;
  final String model;
  final String? id;
  final String? status;
  final List<ResponsesFileCitation> fileCitations;
  final List<ResponsesWebSearchCitation> webSearchCitations;

  /// Raw output items that may need to be supplied to the next request.
  final List<ResponsesInputItem> outputItems;
  final AiUsage? usage;
}

enum ResponsesStreamEventType {
  status,
  outputItemAdded,
  outputItemDone,
  contentPartAdded,
  contentPartDone,
  textDelta,
  textDone,
  fileCitation,
  webSearchCitation,
  toolCallDelta,
  toolCallDone,
  completed,
  incomplete,
  failed,
  error,
  unknown,
}

/// Normalized Responses streaming event.
class ResponsesStreamEvent {
  const ResponsesStreamEvent({
    required this.type,
    this.status,
    this.rawType,
    this.sequenceNumber,
    this.delta = '',
    this.text,
    this.outputIndex,
    this.contentIndex,
    this.itemId,
    this.outputItem,
    this.toolName,
    this.toolArguments,
    this.fileCitation,
    this.webSearchCitation,
    this.response,
    this.errorCode,
    this.errorMessage,
    this.rawEvent = const <String, dynamic>{},
  });

  const ResponsesStreamEvent.status(
    String status, {
    String? rawType,
    int? sequenceNumber,
    Map<String, dynamic> rawEvent = const <String, dynamic>{},
  }) : this(
         type: ResponsesStreamEventType.status,
         status: status,
         rawType: rawType,
         sequenceNumber: sequenceNumber,
         rawEvent: rawEvent,
       );

  const ResponsesStreamEvent.text(
    String delta, {
    String? rawType,
    int? sequenceNumber,
    int? outputIndex,
    int? contentIndex,
    String? itemId,
    Map<String, dynamic> rawEvent = const <String, dynamic>{},
  }) : this(
         type: ResponsesStreamEventType.textDelta,
         delta: delta,
         rawType: rawType,
         sequenceNumber: sequenceNumber,
         outputIndex: outputIndex,
         contentIndex: contentIndex,
         itemId: itemId,
         rawEvent: rawEvent,
       );

  const ResponsesStreamEvent.textDone(
    String text, {
    String? rawType,
    int? sequenceNumber,
    int? outputIndex,
    int? contentIndex,
    String? itemId,
    Map<String, dynamic> rawEvent = const <String, dynamic>{},
  }) : this(
         type: ResponsesStreamEventType.textDone,
         text: text,
         rawType: rawType,
         sequenceNumber: sequenceNumber,
         outputIndex: outputIndex,
         contentIndex: contentIndex,
         itemId: itemId,
         rawEvent: rawEvent,
       );

  const ResponsesStreamEvent.completed(
    ResponsesResponse response, {
    String? rawType,
    int? sequenceNumber,
    Map<String, dynamic> rawEvent = const <String, dynamic>{},
  }) : this(
         type: ResponsesStreamEventType.completed,
         response: response,
         rawType: rawType,
         sequenceNumber: sequenceNumber,
         rawEvent: rawEvent,
       );

  const ResponsesStreamEvent.incomplete(
    String message, {
    String? rawType,
    int? sequenceNumber,
    ResponsesResponse? response,
    String? errorCode,
    Map<String, dynamic> rawEvent = const <String, dynamic>{},
  }) : this(
         type: ResponsesStreamEventType.incomplete,
         response: response,
         rawType: rawType,
         sequenceNumber: sequenceNumber,
         errorCode: errorCode,
         errorMessage: message,
         rawEvent: rawEvent,
       );

  const ResponsesStreamEvent.failed(
    String message, {
    String? rawType,
    int? sequenceNumber,
    ResponsesResponse? response,
    String? errorCode,
    Map<String, dynamic> rawEvent = const <String, dynamic>{},
  }) : this(
         type: ResponsesStreamEventType.failed,
         response: response,
         rawType: rawType,
         sequenceNumber: sequenceNumber,
         errorCode: errorCode,
         errorMessage: message,
         rawEvent: rawEvent,
       );

  const ResponsesStreamEvent.error(
    String message, {
    String? rawType,
    int? sequenceNumber,
    String? errorCode,
    Map<String, dynamic> rawEvent = const <String, dynamic>{},
  }) : this(
         type: ResponsesStreamEventType.error,
         errorMessage: message,
         rawType: rawType,
         sequenceNumber: sequenceNumber,
         errorCode: errorCode,
         rawEvent: rawEvent,
       );

  final ResponsesStreamEventType type;
  final String? status;

  /// Exact provider event type, for diagnostics and protocol replay.
  final String? rawType;

  /// Provider sequence number when supplied by Responses.
  final int? sequenceNumber;
  final String delta;

  /// Complete text supplied by `response.output_text.done`.
  final String? text;
  final int? outputIndex;
  final int? contentIndex;
  final String? itemId;

  /// Raw output item, preserved so callers can round-trip it if needed.
  final ResponsesRawInput? outputItem;
  final String? toolName;
  final String? toolArguments;
  final ResponsesFileCitation? fileCitation;
  final ResponsesWebSearchCitation? webSearchCitation;
  final ResponsesResponse? response;
  final String? errorCode;
  final String? errorMessage;

  /// Provider event payload. Consumers should redact secrets before logging.
  final Map<String, dynamic> rawEvent;
}
