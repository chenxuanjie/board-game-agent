/// Base exception exposed by the shared client package.
sealed class AiClientException implements Exception {
  const AiClientException(this.message, {this.cause});

  final String message;
  final Object? cause;

  @override
  String toString() => 'AiClientException: $message';
}

class AiConfigurationException extends AiClientException {
  const AiConfigurationException(super.message, {super.cause});
}

class AiTransportException extends AiClientException {
  const AiTransportException(super.message, {super.cause});
}

class AiProtocolException extends AiClientException {
  const AiProtocolException(super.message, {super.cause});
}
