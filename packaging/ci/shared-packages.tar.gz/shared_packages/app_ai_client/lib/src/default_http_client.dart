import 'package:http/http.dart' as http;

import 'default_http_client_web.dart'
    if (dart.library.io) 'default_http_client_io.dart'
    as platform;

/// Creates the default HTTP client used by the shared AI adapter.
///
/// The platform implementation keeps browser requests on the browser client
/// and lets native clients honor the host system's proxy configuration.
http.Client createDefaultAiHttpClient() => platform.createDefaultAiHttpClient();
