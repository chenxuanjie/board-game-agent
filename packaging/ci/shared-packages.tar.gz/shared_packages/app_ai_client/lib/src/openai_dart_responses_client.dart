import 'dart:async';

import 'package:http/http.dart' as http;
import 'package:openai_dart/openai_dart.dart' as openai;

import 'default_http_client.dart';
import 'errors.dart';
import 'models.dart';
import 'responses_ai_client.dart';
import 'responses_models.dart';

/// Responses adapter backed by the real `openai_dart` Responses resources.
class OpenAiDartResponsesAiClient implements ResponsesAiClient {
  OpenAiDartResponsesAiClient({
    http.Client? httpClient,
    http.Client Function()? streamClientFactory,
  }) : _httpClient = httpClient ?? createDefaultAiHttpClient(),
       _ownsHttpClient = httpClient == null,
       _streamClientFactory = streamClientFactory ?? createDefaultAiHttpClient;

  final http.Client _httpClient;
  final bool _ownsHttpClient;
  final http.Client Function()? _streamClientFactory;
  final Set<String> _compactionUnsupportedEndpoints = <String>{};
  final Set<String> _webSearchUnsupportedEndpoints = <String>{};
  bool _closed = false;

  @override
  Future<ResponsesResponse> complete(
    ResponsesRequest request, {
    Future<void>? abortTrigger,
  }) async {
    _ensureOpen();
    final openai.OpenAIClient client = _buildClient(request.endpoint);
    try {
      bool includeCompaction = true;
      bool includeWebSearch = true;
      late openai.Response response;
      while (true) {
        try {
          response = await client.responses
              .create(
                _buildRequest(
                  request,
                  includeCompaction: includeCompaction,
                  includeWebSearch: includeWebSearch,
                ),
                abortTrigger: abortTrigger,
              )
              .timeout(request.endpoint.timeout);
          break;
        } catch (error) {
          if (includeCompaction &&
              _shouldRetryWithoutCompaction(request, error)) {
            _markCompactionUnsupported(request.endpoint);
            includeCompaction = false;
            continue;
          }
          if (includeWebSearch &&
              _shouldRetryWithoutWebSearch(request, error)) {
            _markWebSearchUnsupported(request.endpoint);
            includeWebSearch = false;
            continue;
          }
          rethrow;
        }
      }
      final ResponsesResponse normalized = _normalizeResponse(
        response,
        request.endpoint,
      );
      if (normalized.text.trim().isEmpty) {
        throw const AiProtocolException(
          'The Responses endpoint returned an empty response.',
        );
      }
      return normalized;
    } on AiClientException {
      rethrow;
    } catch (error) {
      throw AiTransportException(
        'Responses request failed: ${_describeError(error, request.endpoint)}',
        cause: error,
      );
    } finally {
      client.close();
    }
  }

  @override
  Stream<ResponsesStreamEvent> stream(
    ResponsesRequest request, {
    Future<void>? abortTrigger,
  }) async* {
    _ensureOpen();
    final openai.OpenAIClient client = _buildClient(request.endpoint);
    try {
      bool includeCompaction = true;
      bool includeWebSearch = true;
      bool terminalSeen = false;
      while (true) {
        bool emitted = false;
        try {
          await for (final openai.ResponseStreamEvent event
              in client.responses.createStream(
                _buildRequest(
                  request,
                  includeCompaction: includeCompaction,
                  includeWebSearch: includeWebSearch,
                ),
                abortTrigger: abortTrigger,
              )) {
            final ResponsesStreamEvent? normalized = _normalizeStreamEvent(
              event,
              request.endpoint,
            );
            if (normalized != null) {
              if (_isTerminal(normalized.type)) terminalSeen = true;
              emitted = true;
              yield normalized;
              // A terminal Responses event is authoritative. Do not keep
              // retrying this request. Continue draining because providers
              // may send output-item metadata after response.completed, while
              // the catch below swallows a close-time transport error.
            }
          }
          if (!terminalSeen) {
            yield const ResponsesStreamEvent.incomplete(
              'Responses stream ended before a terminal response event.',
              rawType: 'stream.end',
            );
          }
          return;
        } catch (error) {
          // Once a terminal event was delivered, the response is complete (or
          // explicitly failed/incomplete). A close-time transport exception
          // must not replay the request or create a second terminal outcome.
          if (terminalSeen) return;
          // A provider can reject an optional capability before emitting any
          // SSE event. Retry once without that capability, but never replay a
          // partially emitted stream because doing so would duplicate text.
          if (emitted) rethrow;
          if (includeCompaction &&
              _shouldRetryWithoutCompaction(request, error)) {
            _markCompactionUnsupported(request.endpoint);
            includeCompaction = false;
            continue;
          }
          if (includeWebSearch &&
              _shouldRetryWithoutWebSearch(request, error)) {
            _markWebSearchUnsupported(request.endpoint);
            includeWebSearch = false;
            continue;
          }
          rethrow;
        }
      }
    } on AiClientException {
      rethrow;
    } catch (error) {
      throw AiTransportException(
        'Responses streaming request failed: ${_describeError(error, request.endpoint)}',
        cause: error,
      );
    } finally {
      client.close();
    }
  }

  @override
  void close() {
    if (_closed) return;
    _closed = true;
    if (_ownsHttpClient) _httpClient.close();
  }

  openai.OpenAIClient _buildClient(AiEndpointConfig endpoint) {
    final String baseUrl = _normalizedBaseUrl(endpoint.baseUrl);
    final String apiKey = endpoint.apiKey.trim();
    final String apiKeyHeader = endpoint.apiKeyHeader.trim();
    if (apiKey.isEmpty) {
      throw const AiConfigurationException('An API key is required.');
    }
    if (endpoint.model.trim().isEmpty) {
      throw const AiConfigurationException('A model name is required.');
    }
    if (apiKeyHeader.isEmpty) {
      throw const AiConfigurationException('An API key header is required.');
    }
    return openai.OpenAIClient(
      config: openai.OpenAIConfig(
        baseUrl: baseUrl,
        timeout: endpoint.timeout,
        connectTimeout: endpoint.connectTimeout,
        retryPolicy: openai.RetryPolicy(
          maxRetries: endpoint.retryPolicy.maxRetries,
          initialDelay: endpoint.retryPolicy.initialDelay,
          maxDelay: endpoint.retryPolicy.maxDelay,
          jitter: endpoint.retryPolicy.jitter,
        ),
        defaultHeaders: <String, String>{
          ...endpoint.defaultHeaders,
          apiKeyHeader: _apiKeyHeaderValue(apiKeyHeader, apiKey),
        },
      ),
      httpClient: _httpClient,
      streamClientFactory: _streamClientFactory,
    );
  }

  openai.CreateResponseRequest _buildRequest(
    ResponsesRequest request, {
    bool includeCompaction = true,
    bool includeWebSearch = true,
  }) {
    final List<Map<String, dynamic>> input = request.input
        .map((ResponsesInputItem item) => item.toJson())
        .toList(growable: false);
    return openai.CreateResponseRequest(
      model: request.endpoint.model,
      input: openai.ResponseInput.fromOutputItems(input),
      instructions: request.instructions,
      tools: includeWebSearch && !_isWebSearchUnsupported(request.endpoint)
          ? request.tools.map(_toTool).toList(growable: false)
          : const <openai.ResponseTool>[],
      maxOutputTokens: request.maxOutputTokens,
      reasoning: _toReasoning(request.reasoningEffort),
      text: request.structuredOutput == null
          ? null
          : openai.TextConfig(
              format: openai.JsonSchemaFormat(
                name: request.structuredOutput!.name,
                description: request.structuredOutput!.description,
                schema: request.structuredOutput!.schema,
                strict: request.structuredOutput!.strict,
              ),
            ),
      serviceTier: _toServiceTier(request.serviceTier),
      contextManagement:
          includeCompaction &&
              request.contextManagement.isNotEmpty &&
              !_isCompactionUnsupported(request.endpoint)
          ? request.contextManagement
                .map(
                  (ResponsesContextManagement item) => openai.ContextManagement(
                    type: item.type,
                    compactThreshold: item.compactThreshold,
                  ),
                )
                .toList(growable: false)
          : null,
      store: request.store,
    );
  }

  openai.ResponseTool _toTool(ResponsesToolDefinition tool) {
    return switch (tool.kind) {
      ResponsesToolKind.webSearch => openai.WebSearchTool(
        type: 'web_search',
        searchContextSize: tool.searchContextSize,
      ),
    };
  }

  openai.ReasoningConfig? _toReasoning(String? value) {
    final String normalized = value?.trim().toLowerCase() ?? '';
    if (normalized.isEmpty ||
        normalized == 'auto' ||
        normalized == 'automatic') {
      return null;
    }
    final openai.ReasoningEffort effort = openai.ReasoningEffort.fromJson(
      normalized,
    );
    if (effort == openai.ReasoningEffort.unknown) {
      throw AiConfigurationException('Unsupported reasoning effort "$value".');
    }
    return openai.ReasoningConfig(effort: effort);
  }

  openai.ServiceTier? _toServiceTier(String? value) {
    final String normalized = value?.trim() ?? '';
    return normalized.isEmpty ? null : openai.ServiceTier.fromJson(normalized);
  }

  ResponsesResponse _normalizeResponse(
    openai.Response response,
    AiEndpointConfig endpoint,
  ) {
    final List<ResponsesFileCitation> files = <ResponsesFileCitation>[];
    final List<ResponsesWebSearchCitation> web = <ResponsesWebSearchCitation>[];
    for (final openai.OutputItem item in response.output) {
      if (item is openai.MessageOutputItem) {
        for (final openai.OutputContent content in item.content) {
          if (content is openai.OutputTextContent) {
            _collectAnnotations(content.annotations, files, web);
          }
        }
      }
    }
    return ResponsesResponse(
      text: response.outputText,
      model: response.model?.trim().isNotEmpty == true
          ? response.model!.trim()
          : endpoint.model,
      id: response.id,
      status: response.status.value,
      fileCitations: List<ResponsesFileCitation>.unmodifiable(files),
      webSearchCitations: List<ResponsesWebSearchCitation>.unmodifiable(web),
      outputItems: response.output
          .map((openai.OutputItem item) => ResponsesRawInput(item.toJson()))
          .toList(growable: false),
      usage: _toUsage(response.usage),
    );
  }

  ResponsesStreamEvent? _normalizeStreamEvent(
    openai.ResponseStreamEvent event,
    AiEndpointConfig endpoint,
  ) {
    final Map<String, dynamic> rawEvent = Map<String, dynamic>.unmodifiable(
      event.toJson(),
    );
    if (event is openai.OutputTextDeltaEvent) {
      return ResponsesStreamEvent.text(
        event.delta,
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        outputIndex: event.outputIndex,
        contentIndex: event.contentIndex,
        itemId: event.itemId,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.OutputTextDoneEvent) {
      return ResponsesStreamEvent.textDone(
        event.text,
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        outputIndex: event.outputIndex,
        contentIndex: event.contentIndex,
        itemId: event.itemId,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.OutputItemAddedEvent) {
      return ResponsesStreamEvent(
        type: ResponsesStreamEventType.outputItemAdded,
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        outputIndex: event.outputIndex,
        outputItem: ResponsesRawInput(event.item.toJson()),
        rawEvent: rawEvent,
      );
    }
    if (event is openai.OutputItemDoneEvent) {
      return ResponsesStreamEvent(
        type: ResponsesStreamEventType.outputItemDone,
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        outputIndex: event.outputIndex,
        outputItem: ResponsesRawInput(event.item.toJson()),
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ContentPartAddedEvent) {
      return ResponsesStreamEvent(
        type: ResponsesStreamEventType.contentPartAdded,
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        outputIndex: event.outputIndex,
        contentIndex: event.contentIndex,
        itemId: event.itemId,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ContentPartDoneEvent) {
      return ResponsesStreamEvent(
        type: ResponsesStreamEventType.contentPartDone,
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        outputIndex: event.outputIndex,
        contentIndex: event.contentIndex,
        itemId: event.itemId,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.FunctionCallArgumentsDeltaEvent) {
      return ResponsesStreamEvent(
        type: ResponsesStreamEventType.toolCallDelta,
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        outputIndex: event.outputIndex,
        itemId: event.itemId,
        delta: event.delta,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.FunctionCallArgumentsDoneEvent) {
      return ResponsesStreamEvent(
        type: ResponsesStreamEventType.toolCallDone,
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        outputIndex: event.outputIndex,
        itemId: event.itemId,
        toolName: event.name,
        toolArguments: event.arguments,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ResponseWebSearchCallInProgressEvent ||
        event is openai.ResponseWebSearchCallSearchingEvent) {
      return ResponsesStreamEvent.status(
        'web_search',
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ResponseWebSearchCallCompletedEvent) {
      return ResponsesStreamEvent(
        type: ResponsesStreamEventType.toolCallDone,
        status: 'web_search_completed',
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        outputIndex: event.outputIndex,
        itemId: event.itemId,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.OutputTextAnnotationAddedEvent) {
      final List<ResponsesFileCitation> files = <ResponsesFileCitation>[];
      final List<ResponsesWebSearchCitation> web =
          <ResponsesWebSearchCitation>[];
      _collectAnnotations(<openai.Annotation>[event.annotation], files, web);
      if (files.isNotEmpty) {
        return ResponsesStreamEvent(
          type: ResponsesStreamEventType.fileCitation,
          rawType: event.type,
          sequenceNumber: event.sequenceNumber,
          outputIndex: event.outputIndex,
          contentIndex: event.contentIndex,
          itemId: event.itemId,
          fileCitation: files.first,
          rawEvent: rawEvent,
        );
      }
      if (web.isNotEmpty) {
        return ResponsesStreamEvent(
          type: ResponsesStreamEventType.webSearchCitation,
          rawType: event.type,
          sequenceNumber: event.sequenceNumber,
          outputIndex: event.outputIndex,
          contentIndex: event.contentIndex,
          itemId: event.itemId,
          webSearchCitation: web.first,
          rawEvent: rawEvent,
        );
      }
    }
    if (event is openai.ResponseCompletedEvent) {
      return ResponsesStreamEvent.completed(
        _normalizeResponse(event.response, endpoint),
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ResponseFailedEvent) {
      return ResponsesStreamEvent.failed(
        event.response.error?.message ?? 'Responses request failed.',
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        response: _normalizeResponse(event.response, endpoint),
        errorCode: event.response.error?.code,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ResponseIncompleteEvent) {
      return ResponsesStreamEvent.incomplete(
        event.response.incompleteDetails?.reason ??
            'Responses request was incomplete.',
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        response: _normalizeResponse(event.response, endpoint),
        errorCode: event.response.incompleteDetails?.reason,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ErrorEvent) {
      return ResponsesStreamEvent.error(
        event.message,
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        errorCode: event.code,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ResponseCreatedEvent) {
      return ResponsesStreamEvent.status(
        'created',
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ResponseQueuedEvent) {
      return ResponsesStreamEvent.status(
        'queued',
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        rawEvent: rawEvent,
      );
    }
    if (event is openai.ResponseInProgressEvent) {
      return ResponsesStreamEvent.status(
        'in_progress',
        rawType: event.type,
        sequenceNumber: event.sequenceNumber,
        rawEvent: rawEvent,
      );
    }
    // Keep every provider event observable, even when this adapter does not
    // yet have a domain-specific projection for it (reasoning, audio, file
    // search, code interpreter, and future Responses event types). The raw
    // payload is intentionally retained for diagnostics and forward
    // compatibility instead of being silently dropped.
    return ResponsesStreamEvent(
      type: ResponsesStreamEventType.unknown,
      rawType: event.type,
      sequenceNumber: event.sequenceNumber,
      rawEvent: rawEvent,
    );
  }

  bool _isTerminal(ResponsesStreamEventType type) =>
      type == ResponsesStreamEventType.completed ||
      type == ResponsesStreamEventType.failed ||
      type == ResponsesStreamEventType.incomplete ||
      type == ResponsesStreamEventType.error;

  void _collectAnnotations(
    List<openai.Annotation>? annotations,
    List<ResponsesFileCitation> files,
    List<ResponsesWebSearchCitation> web,
  ) {
    for (final openai.Annotation annotation in annotations ?? const []) {
      if (annotation is openai.FileCitation) {
        if (!files.any((item) => item.fileId == annotation.fileId)) {
          files.add(
            ResponsesFileCitation(
              fileId: annotation.fileId,
              filename: annotation.filename,
            ),
          );
        }
      } else if (annotation is openai.UrlCitation) {
        if (!web.any((item) => item.url == annotation.url)) {
          web.add(
            ResponsesWebSearchCitation(
              url: annotation.url,
              title: annotation.title,
            ),
          );
        }
      }
    }
  }

  AiUsage? _toUsage(openai.ResponseUsage? usage) {
    if (usage == null) return null;
    return AiUsage(
      promptTokens: usage.inputTokens,
      totalTokens: usage.totalTokens,
      completionTokens: usage.outputTokens,
      reasoningTokens: usage.outputTokensDetails?.reasoningTokens,
    );
  }

  String _normalizedBaseUrl(String value) {
    final String trimmed = value.trim();
    if (trimmed.isEmpty) {
      throw const AiConfigurationException('A base URL is required.');
    }
    return trimmed.endsWith('/')
        ? trimmed.substring(0, trimmed.length - 1)
        : trimmed;
  }

  String _apiKeyHeaderValue(String header, String apiKey) {
    if (header.toLowerCase() != 'authorization') return apiKey;
    return apiKey.toLowerCase().startsWith('bearer ')
        ? apiKey
        : 'Bearer $apiKey';
  }

  String _describeError(Object error, AiEndpointConfig endpoint) {
    final String apiKey = endpoint.apiKey.trim();
    String redact(String value) =>
        apiKey.isEmpty ? value : value.replaceAll(apiKey, '<redacted>');
    if (error is openai.ApiException) {
      final String message = redact(error.message.trim());
      return 'HTTP ${error.statusCode}${message.isEmpty ? '' : ': $message'}';
    }
    if (error is openai.RequestTimeoutException || error is TimeoutException) {
      return 'request timed out';
    }
    if (error is openai.ConnectionException) {
      final String message = redact(error.message.trim());
      return message.isEmpty ? 'connection failed' : message;
    }
    if (error is openai.ParseException) return 'invalid JSON response';
    if (error is http.ClientException) {
      final String message = redact(error.message.trim());
      return message.isEmpty ? 'network request failed' : message;
    }
    return 'network request failed (${error.runtimeType}: ${redact(error.toString())})';
  }

  bool _isCompactionUnsupported(AiEndpointConfig endpoint) {
    return _compactionUnsupportedEndpoints.contains(_endpointKey(endpoint));
  }

  void _markCompactionUnsupported(AiEndpointConfig endpoint) {
    _compactionUnsupportedEndpoints.add(_endpointKey(endpoint));
  }

  bool _isWebSearchUnsupported(AiEndpointConfig endpoint) {
    return _webSearchUnsupportedEndpoints.contains(_endpointKey(endpoint));
  }

  void _markWebSearchUnsupported(AiEndpointConfig endpoint) {
    _webSearchUnsupportedEndpoints.add(_endpointKey(endpoint));
  }

  String _endpointKey(AiEndpointConfig endpoint) =>
      '${_normalizedBaseUrl(endpoint.baseUrl)}|${endpoint.model.trim()}';

  bool _shouldRetryWithoutCompaction(ResponsesRequest request, Object error) {
    if (request.contextManagement.isEmpty ||
        _isCompactionUnsupported(request.endpoint)) {
      return false;
    }
    if (error is! openai.ApiException) return false;
    if (error.statusCode != 400 &&
        error.statusCode != 404 &&
        error.statusCode != 422) {
      return false;
    }
    final String message = error.message.toLowerCase();
    return message.contains('context_management') ||
        message.contains('compaction') ||
        message.contains('compact_threshold') ||
        message.contains('unsupported field') ||
        message.contains('unknown field');
  }

  bool _shouldRetryWithoutWebSearch(ResponsesRequest request, Object error) {
    if (request.tools.isEmpty || _isWebSearchUnsupported(request.endpoint)) {
      return false;
    }
    if (error is! openai.ApiException ||
        (error.statusCode != 400 &&
            error.statusCode != 404 &&
            error.statusCode != 422)) {
      return false;
    }
    final String message = <String?>[
      error.message,
      error.code,
      error.param,
      error.type,
    ].whereType<String>().join(' ').toLowerCase();
    final bool namesWebSearch =
        message.contains('web_search') || message.contains('web search');
    final bool rejectsTool =
        message.contains('tool') &&
        (message.contains('unsupported') ||
            message.contains('unknown') ||
            message.contains('not support') ||
            message.contains('not allowed') ||
            message.contains('invalid') ||
            message.contains('not permitted'));
    return namesWebSearch || rejectsTool;
  }

  void _ensureOpen() {
    if (_closed) {
      throw const AiConfigurationException('The AI client has been closed.');
    }
  }
}
