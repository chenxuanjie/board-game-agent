import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:openai_dart/openai_dart.dart' as openai;

import 'ai_client.dart';
import 'default_http_client.dart';
import 'errors.dart';
import 'models.dart';

/// An [AiClient] implementation backed by `openai_dart` chat completions.
///
/// It intentionally supports only the portable, plain-text portion of the
/// OpenAI-compatible chat contract. Provider-specific features stay outside
/// the shared API until a second consumer needs them.
class OpenAiDartAiClient implements AiClient {
  OpenAiDartAiClient({
    http.Client? httpClient,
    http.Client Function()? streamClientFactory,
  }) : _httpClient = httpClient ?? createDefaultAiHttpClient(),
       _ownsHttpClient = httpClient == null,
       _streamClientFactory = streamClientFactory ?? createDefaultAiHttpClient;

  final http.Client _httpClient;
  final bool _ownsHttpClient;
  final http.Client Function()? _streamClientFactory;
  bool _closed = false;

  @override
  Future<List<AiModel>> listModels(AiEndpointConfig endpoint) async {
    _ensureOpen();
    final openai.OpenAIClient client = _buildClient(
      endpoint,
      requireModel: false,
      normalizeModelResponses: true,
    );
    try {
      final openai.ModelList response = await client.models.list().timeout(
        endpoint.modelListTimeout,
      );
      final Map<String, AiModel> unique = <String, AiModel>{};
      for (final openai.Model model in response.data) {
        final String id = model.id.trim();
        if (id.isEmpty) {
          continue;
        }
        unique[id] = AiModel(
          id: id,
          ownedBy: model.ownedBy,
          createdAt: model.createdAt,
        );
      }
      final List<AiModel> models = unique.values.toList()
        ..sort((AiModel left, AiModel right) => left.id.compareTo(right.id));
      if (models.isEmpty) {
        throw const AiProtocolException(
          'The AI endpoint returned an empty model list.',
        );
      }
      return List<AiModel>.unmodifiable(models);
    } on AiClientException {
      rethrow;
    } catch (error) {
      throw AiTransportException(
        'AI model request failed: ${_describeTransportError(error, endpoint)}',
        cause: error,
      );
    } finally {
      client.close();
    }
  }

  @override
  Future<AiResponse> complete(AiRequest request) async {
    _ensureOpen();
    final openai.OpenAIClient client = _buildClient(request.endpoint);
    try {
      final openai.ChatCompletion response = await client.chat.completions
          .create(_buildRequest(request));
      final String text = response.text?.trim() ?? '';
      if (text.isEmpty) {
        throw const AiProtocolException(
          'The AI endpoint returned an empty completion.',
        );
      }
      return AiResponse(
        text: text,
        id: response.id,
        model: response.model.isEmpty ? request.endpoint.model : response.model,
        finishReason: response.firstChoice?.finishReason?.value,
        usage: _toUsage(response.usage),
      );
    } on AiClientException {
      rethrow;
    } catch (error) {
      throw AiTransportException(
        'AI completion request failed: ${_describeTransportError(error, request.endpoint)}',
        cause: error,
      );
    } finally {
      client.close();
    }
  }

  @override
  Stream<AiStreamEvent> stream(
    AiRequest request, {
    Future<void>? abortTrigger,
  }) async* {
    _ensureOpen();
    final openai.OpenAIClient client = _buildClient(request.endpoint);
    try {
      await for (final openai.ChatStreamEvent event
          in client.chat.completions.createStream(
            _buildRequest(request),
            abortTrigger: abortTrigger,
          )) {
        final String delta = event.textDelta ?? '';
        final String? finishReason = event.firstChoice?.finishReason?.value;
        if (delta.isNotEmpty || finishReason != null || event.usage != null) {
          yield AiStreamEvent(
            delta: delta,
            model: event.model,
            finishReason: finishReason,
            usage: _toUsage(event.usage),
          );
          // finish_reason is the terminal signal for Chat Completions. Stop
          // consuming the HTTP stream so a close-time transport error cannot
          // turn an already complete answer into a failed request.
          if (finishReason != null) return;
        }
      }
    } on AiClientException {
      rethrow;
    } catch (error) {
      throw AiTransportException(
        'AI streaming request failed: ${_describeTransportError(error, request.endpoint)}',
        cause: error,
      );
    } finally {
      client.close();
    }
  }

  @override
  Future<AiHealthResult> check(AiEndpointConfig endpoint) async {
    final Stopwatch stopwatch = Stopwatch()..start();
    try {
      final AiResponse response = await complete(
        AiRequest(
          endpoint: endpoint,
          messages: const <AiMessage>[AiMessage.user('ping')],
          options: const AiGenerationOptions(
            temperature: 0,
            maxCompletionTokens: 8,
          ),
        ),
      );
      return AiHealthResult(
        success: true,
        message: 'Connection successful.',
        latency: stopwatch.elapsed,
        model: response.model,
      );
    } catch (error) {
      return AiHealthResult(
        success: false,
        message: error.toString(),
        latency: stopwatch.elapsed,
      );
    } finally {
      stopwatch.stop();
    }
  }

  @override
  void close() {
    if (_closed) {
      return;
    }
    _closed = true;
    if (_ownsHttpClient) {
      _httpClient.close();
    }
  }

  openai.OpenAIClient _buildClient(
    AiEndpointConfig endpoint, {
    bool requireModel = true,
    bool normalizeModelResponses = false,
  }) {
    final String baseUrl = _normalizedBaseUrl(endpoint.baseUrl);
    final String chatPath = _normalizedPath(endpoint.chatPath);
    if (chatPath != '/chat/completions') {
      throw AiConfigurationException(
        'Unsupported chat path "$chatPath". '
        'OpenAiDartAiClient requires /chat/completions.',
      );
    }
    final String apiKey = endpoint.apiKey.trim();
    final String apiKeyHeader = endpoint.apiKeyHeader.trim();
    if (apiKey.isEmpty) {
      throw const AiConfigurationException('An API key is required.');
    }
    if (requireModel && endpoint.model.trim().isEmpty) {
      throw const AiConfigurationException('A model name is required.');
    }
    if (apiKeyHeader.isEmpty) {
      throw const AiConfigurationException('An API key header is required.');
    }

    final Map<String, String> headers = <String, String>{
      ...endpoint.defaultHeaders,
      apiKeyHeader: _apiKeyHeaderValue(apiKeyHeader, apiKey),
    };
    return openai.OpenAIClient(
      config: openai.OpenAIConfig(
        baseUrl: baseUrl,
        timeout: endpoint.timeout,
        connectTimeout: endpoint.connectTimeout,
        retryPolicy: openai.RetryPolicy(
          maxRetries: endpoint.retryPolicy.maxRetries,
          initialDelay: endpoint.retryPolicy.initialDelay,
          maxDelay: endpoint.retryPolicy.maxDelay,
          jitter: endpoint.retryPolicy.jitter,
        ),
        defaultHeaders: headers,
      ),
      httpClient: normalizeModelResponses
          ? _CompatibleModelsHttpClient(_httpClient)
          : _httpClient,
      streamClientFactory: _streamClientFactory,
    );
  }

  openai.ChatCompletionCreateRequest _buildRequest(AiRequest request) {
    return openai.ChatCompletionCreateRequest(
      model: request.endpoint.model,
      messages: request.messages.map(_toOpenAiMessage).toList(growable: false),
      temperature: request.options.temperature,
      topP: request.options.topP,
      maxCompletionTokens: request.options.maxCompletionTokens,
      frequencyPenalty: request.options.frequencyPenalty,
      presencePenalty: request.options.presencePenalty,
      user: request.options.user,
      reasoningEffort: _toReasoningEffort(request.options.reasoningEffort),
      serviceTier: request.options.serviceTier,
    );
  }

  openai.ReasoningEffort? _toReasoningEffort(String? value) {
    final String normalized = value?.trim().toLowerCase() ?? '';
    if (normalized.isEmpty ||
        normalized == 'auto' ||
        normalized == 'automatic') {
      return null;
    }
    final openai.ReasoningEffort effort = openai.ReasoningEffort.fromJson(
      normalized,
    );
    if (effort == openai.ReasoningEffort.unknown) {
      throw AiConfigurationException('Unsupported reasoning effort "$value".');
    }
    return effort;
  }

  openai.ChatMessage _toOpenAiMessage(AiMessage message) {
    return switch (message.role) {
      AiMessageRole.system => openai.ChatMessage.system(message.content),
      AiMessageRole.user => openai.ChatMessage.user(message.content),
      AiMessageRole.assistant => openai.ChatMessage.assistant(
        content: message.content,
      ),
    };
  }

  String _normalizedBaseUrl(String value) {
    final String trimmed = value.trim();
    if (trimmed.isEmpty) {
      throw const AiConfigurationException('A base URL is required.');
    }
    return trimmed.endsWith('/')
        ? trimmed.substring(0, trimmed.length - 1)
        : trimmed;
  }

  String _normalizedPath(String value) {
    final String trimmed = value.trim();
    if (trimmed.isEmpty) {
      return '/chat/completions';
    }
    return trimmed.startsWith('/') ? trimmed : '/$trimmed';
  }

  String _apiKeyHeaderValue(String header, String apiKey) {
    if (header.toLowerCase() != 'authorization') {
      return apiKey;
    }
    return apiKey.toLowerCase().startsWith('bearer ')
        ? apiKey
        : 'Bearer $apiKey';
  }

  AiUsage? _toUsage(openai.Usage? usage) {
    if (usage == null) {
      return null;
    }
    return AiUsage(
      promptTokens: usage.promptTokens,
      completionTokens: usage.completionTokens,
      totalTokens: usage.totalTokens,
    );
  }

  String _describeTransportError(Object error, AiEndpointConfig endpoint) {
    final String apiKey = endpoint.apiKey.trim();
    String redact(String value) {
      if (apiKey.isEmpty) {
        return value;
      }
      return value.replaceAll(apiKey, '<redacted>');
    }

    if (error is openai.ApiException) {
      final String message = redact(error.message.trim());
      return 'HTTP ${error.statusCode}${message.isEmpty ? '' : ': $message'}';
    }
    if (error is openai.RequestTimeoutException) {
      final int seconds =
          error.timeout?.inSeconds ?? endpoint.timeout.inSeconds;
      return 'request timed out after ${seconds}s';
    }
    if (error is openai.ConnectionException) {
      final String message = redact(error.message.trim());
      return message.isEmpty ? 'connection failed' : message;
    }
    if (error is openai.ParseException) {
      return 'invalid JSON response';
    }
    if (error is http.ClientException) {
      final String message = redact(error.message.trim());
      return message.isEmpty ? 'network request failed' : message;
    }
    if (error is TimeoutException) {
      return 'request timed out';
    }
    return 'network request failed (${error.runtimeType})';
  }

  void _ensureOpen() {
    if (_closed) {
      throw const AiConfigurationException('The AI client has been closed.');
    }
  }
}

/// Normalizes common OpenAI-compatible `/models` variants before
/// `openai_dart` performs its strict official-schema parsing.
class _CompatibleModelsHttpClient extends http.BaseClient {
  _CompatibleModelsHttpClient(this._inner);

  final http.Client _inner;

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    final http.StreamedResponse response = await _inner.send(request);
    if (request.method != 'GET' || !request.url.path.endsWith('/models')) {
      return response;
    }

    final List<int> bytes = await response.stream.toBytes();
    if (response.statusCode < 200 || response.statusCode >= 300) {
      return _copyResponse(response, bytes);
    }

    try {
      final Object? decoded = jsonDecode(utf8.decode(bytes));
      if (decoded is! Map<String, dynamic> || decoded['data'] is! List) {
        return _copyResponse(response, bytes);
      }
      final List<dynamic> data = decoded['data'] as List<dynamic>;
      final List<Map<String, dynamic>> normalized = data
          .whereType<Map>()
          .map((Map<dynamic, dynamic> raw) {
            final Map<String, dynamic> item = raw.map(
              (dynamic key, dynamic value) => MapEntry('$key', value),
            );
            return <String, dynamic>{
              ...item,
              'id': '${item['id'] ?? ''}',
              'object': item['object'] ?? item['type'] ?? 'model',
              if (item['created'] is int) 'created': item['created'],
              if (item['owned_by'] is String) 'owned_by': item['owned_by'],
            };
          })
          .toList(growable: false);
      final List<int> normalizedBytes = utf8.encode(
        jsonEncode(<String, dynamic>{
          ...decoded,
          'object': decoded['object'] ?? 'list',
          'data': normalized,
        }),
      );
      return _copyResponse(response, normalizedBytes);
    } catch (_) {
      return _copyResponse(response, bytes);
    }
  }

  http.StreamedResponse _copyResponse(
    http.StreamedResponse source,
    List<int> bytes,
  ) {
    return http.StreamedResponse(
      Stream<List<int>>.value(bytes),
      source.statusCode,
      contentLength: bytes.length,
      request: source.request,
      headers: source.headers,
      isRedirect: source.isRedirect,
      persistentConnection: source.persistentConnection,
      reasonPhrase: source.reasonPhrase,
    );
  }
}
