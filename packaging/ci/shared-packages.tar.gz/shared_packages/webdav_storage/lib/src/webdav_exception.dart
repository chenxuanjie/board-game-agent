/// Error raised when a WebDAV operation cannot be completed.
final class WebDavException implements Exception {
  const WebDavException({
    required this.operation,
    required this.uri,
    required this.message,
    this.statusCode,
    this.responseBody,
    this.cause,
  });

  final String operation;
  final Uri uri;
  final String message;
  final int? statusCode;
  final String? responseBody;
  final Object? cause;

  @override
  String toString() {
    final status = statusCode == null ? '' : ' (HTTP $statusCode)';
    return 'WebDavException: $operation failed$status for $uri: $message';
  }
}
