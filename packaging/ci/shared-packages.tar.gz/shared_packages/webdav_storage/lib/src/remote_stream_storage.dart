import 'webdav_read_stream.dart';

/// Optional streaming capability for large remote files.
abstract interface class RemoteStreamStorage {
  /// Opens [path] without buffering the complete response in memory.
  ///
  /// When [startByte] is provided, the server must honor the HTTP Range
  /// request and return a partial response.
  Future<WebDavReadStream> openRead(String path, {int? startByte});
}
