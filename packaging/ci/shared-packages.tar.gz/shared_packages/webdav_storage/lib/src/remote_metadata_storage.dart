import 'webdav_head_result.dart';

/// Optional metadata capability for remote file stores.
abstract interface class RemoteMetadataStorage {
  /// Checks that [path] exists and returns metadata without downloading its
  /// response body.
  Future<WebDavHeadResult> head(String path);
}
