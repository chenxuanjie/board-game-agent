import 'dart:typed_data';

/// Result of a successful WebDAV download.
final class WebDavDownloadResult {
  const WebDavDownloadResult({
    required this.data,
    required this.statusCode,
    required this.headers,
  });

  final Uint8List data;
  final int statusCode;
  final Map<String, String> headers;

  String? get contentType => headers['content-type'];
  String? get etag => headers['etag'];
  String? get lastModified => headers['last-modified'];
}

/// Result of a successful WebDAV upload.
final class WebDavUploadResult {
  const WebDavUploadResult({required this.statusCode, required this.headers});

  final int statusCode;
  final Map<String, String> headers;

  String? get etag => headers['etag'];
  String? get location => headers['location'];
}
