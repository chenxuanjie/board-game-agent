import 'dart:convert';

import 'webdav_transfer_result.dart';

/// App-independent interface for reading and writing remote files.
abstract interface class RemoteStorage {
  /// Downloads [path] and returns its bytes plus response metadata.
  Future<WebDavDownloadResult> downloadBytes(String path);

  /// Downloads [path] as text using [encoding].
  Future<String> downloadText(String path, {Encoding encoding = utf8});

  /// Uploads [data] to [path].
  Future<WebDavUploadResult> uploadBytes(
    String path,
    List<int> data, {
    String? contentType,
    bool overwrite = true,
    String? ifMatch,
    String? ifUnmodifiedSince,
  });

  /// Uploads [text] to [path] using [encoding].
  Future<WebDavUploadResult> uploadText(
    String path,
    String text, {
    Encoding encoding = utf8,
    String contentType = 'text/plain; charset=utf-8',
    bool overwrite = true,
    String? ifMatch,
    String? ifUnmodifiedSince,
  });

  /// Ensures that [path] exists as a remote directory.
  Future<void> ensureDirectory(String path, {bool recursive = true});
}
