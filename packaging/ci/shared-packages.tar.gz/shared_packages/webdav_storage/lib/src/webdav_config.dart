/// Connection settings shared by all requests to one WebDAV endpoint.
final class WebDavConfig {
  WebDavConfig({
    required Uri baseUri,
    this.username,
    this.password,
    this.timeout = const Duration(seconds: 30),
    this.headers = const <String, String>{},
    this.proxyUri,
  }) : baseUri = _normalizeBaseUri(baseUri) {
    if (!this.baseUri.hasScheme || !this.baseUri.hasAuthority) {
      throw ArgumentError.value(
        baseUri,
        'baseUri',
        'Must be an absolute HTTP or HTTPS URI.',
      );
    }
    if (this.baseUri.scheme != 'http' && this.baseUri.scheme != 'https') {
      throw ArgumentError.value(
        baseUri,
        'baseUri',
        'Only HTTP and HTTPS are supported.',
      );
    }
    if (timeout <= Duration.zero) {
      throw ArgumentError.value(
        timeout,
        'timeout',
        'Must be greater than zero.',
      );
    }
    if (proxyUri != null &&
        (!proxyUri!.hasScheme ||
            !proxyUri!.hasAuthority ||
            (proxyUri!.scheme != 'http' && proxyUri!.scheme != 'https'))) {
      throw ArgumentError.value(
        proxyUri,
        'proxyUri',
        'Must be an absolute HTTP or HTTPS URI.',
      );
    }
    if ((username == null) != (password == null)) {
      throw ArgumentError(
        'username and password must either both be set or both be null.',
      );
    }
  }

  /// Root directory used to resolve relative remote paths.
  final Uri baseUri;

  /// Optional HTTP Basic authentication username.
  final String? username;

  /// Optional HTTP Basic authentication password.
  final String? password;

  /// Maximum time allowed for each HTTP request.
  final Duration timeout;

  /// Headers included in every request. Per-operation headers take precedence.
  final Map<String, String> headers;

  /// Optional same-origin HTTP endpoint that forwards requests to WebDAV.
  /// The remote URI is supplied in the proxy request's `url` query parameter.
  final Uri? proxyUri;

  static Uri _normalizeBaseUri(Uri uri) {
    if (uri.query.isNotEmpty || uri.fragment.isNotEmpty) {
      throw ArgumentError.value(
        uri,
        'baseUri',
        'Query parameters and fragments are not supported.',
      );
    }
    final path = uri.path.endsWith('/') ? uri.path : '${uri.path}/';
    return uri.replace(path: path);
  }
}
