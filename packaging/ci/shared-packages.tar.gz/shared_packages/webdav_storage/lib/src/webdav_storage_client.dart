import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';

import 'remote_directory_storage.dart';
import 'remote_delete_storage.dart';
import 'remote_metadata_storage.dart';
import 'remote_storage.dart';
import 'remote_stream_storage.dart';
import 'webdav_config.dart';
import 'webdav_exception.dart';
import 'webdav_head_result.dart';
import 'webdav_read_stream.dart';
import 'webdav_transfer_result.dart';

/// Minimal reusable WebDAV client focused on file upload and download.
final class WebDavStorageClient
    implements
        RemoteStorage,
        RemoteStreamStorage,
        RemoteDirectoryStorage,
        RemoteMetadataStorage,
        RemoteDeleteStorage {
  WebDavStorageClient({required this.config, http.Client? httpClient})
    : _httpClient = httpClient ?? http.Client(),
      _ownsHttpClient = httpClient == null;

  final WebDavConfig config;
  final http.Client _httpClient;
  final bool _ownsHttpClient;
  bool _isClosed = false;

  /// Releases the internally-created HTTP client.
  ///
  /// If a client was injected, its lifecycle remains the caller's responsibility.
  void close() {
    if (_isClosed) return;
    _isClosed = true;
    if (_ownsHttpClient) _httpClient.close();
  }

  @override
  Future<WebDavDownloadResult> downloadBytes(String path) async {
    final uri = _resolvePath(path);
    final response = await _send(
      operation: 'download',
      request: http.Request('GET', uri)
        ..headers.addAll(_headers(_noCacheHeaders)),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw _httpException('download', uri, response);
    }

    return WebDavDownloadResult(
      data: response.bodyBytes,
      statusCode: response.statusCode,
      headers: Map.unmodifiable(response.headers),
    );
  }

  @override
  Future<void> delete(String path) async {
    final uri = _resolvePath(path);
    final response = await _send(
      operation: 'delete',
      request: http.Request('DELETE', uri)
        ..headers.addAll(_headers(_noCacheHeaders)),
    );
    // Only completed file deletion and an already missing file count as success.
    // 202/207 may still contain pending work or per-resource failures.
    if (response.statusCode != 200 &&
        response.statusCode != 204 &&
        response.statusCode != 404) {
      throw _httpException('delete', uri, response);
    }
  }

  @override
  Future<WebDavHeadResult> head(String path) async {
    final uri = _resolvePath(path);
    final response = await _send(
      operation: 'head',
      request: http.Request('HEAD', uri)
        ..headers.addAll(_headers(_noCacheHeaders)),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw _httpException('head', uri, response);
    }

    final headers = <String, String>{...response.headers};
    final immutableHeaders = Map<String, String>.unmodifiable(headers);
    return WebDavHeadResult(
      statusCode: response.statusCode,
      headers: immutableHeaders,
      contentLength: _parseContentLength(immutableHeaders),
    );
  }

  @override
  Future<String> downloadText(String path, {Encoding encoding = utf8}) async {
    final result = await downloadBytes(path);
    return encoding.decode(result.data);
  }

  @override
  Future<WebDavReadStream> openRead(String path, {int? startByte}) async {
    if (startByte != null && startByte < 0) {
      throw ArgumentError.value(
        startByte,
        'startByte',
        'Must not be negative.',
      );
    }
    if (_isClosed) {
      throw StateError('WebDavStorageClient has already been closed.');
    }

    final uri = _resolvePath(path);
    final request = http.Request('GET', uri)
      ..headers.addAll(
        _headers(<String, String>{
          ..._noCacheHeaders,
          if (startByte != null) 'range': 'bytes=$startByte-',
        }),
      );

    try {
      final response = await _httpClient.send(request).timeout(config.timeout);
      final expectedStatus = startByte == null ? 200 : 206;
      if (response.statusCode != expectedStatus) {
        if (startByte != null &&
            (response.statusCode == 200 || response.statusCode == 416)) {
          // An ignored Range can be an entire APK/EXE. Cancel it rather than
          // buffering a large body merely to report range support to the caller.
          await response.stream.listen((_) {}).cancel();
          throw WebDavException(
            operation: 'open stream',
            uri: uri,
            statusCode: response.statusCode,
            message: 'The server did not honor the requested byte range.',
          );
        }
        final buffered = await http.Response.fromStream(
          response,
        ).timeout(config.timeout);
        throw _httpException('open stream', uri, buffered);
      }

      final stream = response.stream.timeout(
        config.timeout,
        onTimeout: (sink) {
          sink
            ..addError(
              WebDavException(
                operation: 'stream download',
                uri: uri,
                message: 'No data received for ${config.timeout}.',
              ),
            )
            ..close();
        },
      );
      return WebDavReadStream(
        bytes: stream,
        statusCode: response.statusCode,
        headers: Map.unmodifiable(response.headers),
        contentLength: response.contentLength,
      );
    } on TimeoutException catch (error) {
      throw WebDavException(
        operation: 'open stream',
        uri: uri,
        message: 'Request timed out after ${config.timeout}.',
        cause: error,
      );
    } on WebDavException {
      rethrow;
    } catch (error) {
      throw WebDavException(
        operation: 'open stream',
        uri: uri,
        message: 'Network request failed.',
        cause: error,
      );
    }
  }

  @override
  Future<WebDavUploadResult> uploadBytes(
    String path,
    List<int> data, {
    String? contentType,
    bool overwrite = true,
    String? ifMatch,
    String? ifUnmodifiedSince,
  }) async {
    if (!overwrite && ifMatch != null) {
      throw ArgumentError(
        'overwrite: false and ifMatch cannot be used together.',
      );
    }
    if (ifMatch != null && ifMatch.isEmpty) {
      throw ArgumentError.value(ifMatch, 'ifMatch', 'Must not be empty.');
    }
    if (ifUnmodifiedSince != null && ifUnmodifiedSince.isEmpty) {
      throw ArgumentError.value(
        ifUnmodifiedSince,
        'ifUnmodifiedSince',
        'Must not be empty.',
      );
    }
    if (ifMatch != null && ifUnmodifiedSince != null) {
      throw ArgumentError(
        'ifMatch and ifUnmodifiedSince cannot be used together.',
      );
    }
    final uri = _resolvePath(path);
    final request = http.Request('PUT', uri)
      ..headers.addAll(
        _headers(<String, String>{
          'content-type': ?contentType,
          if (!overwrite) 'if-none-match': '*',
          'if-match': ?ifMatch,
          'if-unmodified-since': ?ifUnmodifiedSince,
        }),
      )
      ..bodyBytes = data;
    final response = await _send(operation: 'upload', request: request);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw _httpException('upload', uri, response);
    }

    return WebDavUploadResult(
      statusCode: response.statusCode,
      headers: Map.unmodifiable(response.headers),
    );
  }

  @override
  Future<WebDavUploadResult> uploadText(
    String path,
    String text, {
    Encoding encoding = utf8,
    String contentType = 'text/plain; charset=utf-8',
    bool overwrite = true,
    String? ifMatch,
    String? ifUnmodifiedSince,
  }) {
    return uploadBytes(
      path,
      encoding.encode(text),
      contentType: contentType,
      overwrite: overwrite,
      ifMatch: ifMatch,
      ifUnmodifiedSince: ifUnmodifiedSince,
    );
  }

  @override
  Future<void> ensureDirectory(String path, {bool recursive = true}) async {
    final segments = _pathSegments(path, argumentName: 'path');
    final directoryPaths = recursive
        ? <String>[
            for (var count = 1; count <= segments.length; count++)
              segments.take(count).join('/'),
          ]
        : <String>[segments.join('/')];

    for (final directoryPath in directoryPaths) {
      final uri = _resolvePath(directoryPath);
      final response = await _send(
        operation: 'create directory',
        request: http.Request('MKCOL', uri)..headers.addAll(_headers()),
      );
      if ((response.statusCode < 200 || response.statusCode >= 300) &&
          response.statusCode != 405) {
        throw _httpException('create directory', uri, response);
      }
    }
  }

  @override
  Future<List<RemoteResource>> list(String path) async {
    final uri = _resolvePath(path);
    final request = http.Request('PROPFIND', uri)
      ..headers.addAll(
        _headers(<String, String>{
          ..._noCacheHeaders,
          'depth': '1',
          'content-type': 'application/xml; charset=utf-8',
        }),
      )
      ..body = '''<?xml version="1.0" encoding="utf-8" ?>
<d:propfind xmlns:d="DAV:">
  <d:prop>
    <d:resourcetype />
    <d:getetag />
  </d:prop>
</d:propfind>''';
    final response = await _send(operation: 'list directory', request: request);
    if (response.statusCode != 207 &&
        (response.statusCode < 200 || response.statusCode >= 300)) {
      throw _httpException('list directory', uri, response);
    }

    final document = XmlDocument.parse(
      utf8.decode(response.bodyBytes, allowMalformed: true),
    );
    final resources = <RemoteResource>[];
    final requestedPath = _normalizedResourcePath(uri);
    for (final responseElement
        in document.descendants.whereType<XmlElement>()) {
      if (responseElement.localName != 'response') continue;
      final href = responseElement.descendants
          .whereType<XmlElement>()
          .where((element) => element.localName == 'href')
          .map((element) => element.innerText.trim())
          .firstOrNull;
      if (href == null || href.isEmpty) continue;
      final resourceUri = uri.resolve(href);
      if (_normalizedResourcePath(resourceUri) == requestedPath) continue;
      final name = _resourceName(resourceUri);
      if (name.isEmpty) continue;
      final isCollection = responseElement.descendants
          .whereType<XmlElement>()
          .any((element) => element.localName == 'collection');
      final etag = responseElement.descendants
          .whereType<XmlElement>()
          .where((element) => element.localName == 'getetag')
          .map((element) => element.innerText.trim())
          .firstOrNull;
      resources.add(
        RemoteResource(
          name: name,
          isCollection: isCollection,
          etag: etag == null || etag.isEmpty ? null : etag,
        ),
      );
    }
    return List.unmodifiable(resources);
  }

  Future<http.Response> _send({
    required String operation,
    required http.Request request,
  }) async {
    if (_isClosed) {
      throw StateError('WebDavStorageClient has already been closed.');
    }

    try {
      final response = () async {
        final streamed = await _httpClient.send(request);
        return http.Response.fromStream(streamed);
      }();
      return await response.timeout(config.timeout);
    } on TimeoutException catch (error) {
      throw WebDavException(
        operation: operation,
        uri: request.url,
        message: 'Request timed out after ${config.timeout}.',
        cause: error,
      );
    } on WebDavException {
      rethrow;
    } catch (error) {
      throw WebDavException(
        operation: operation,
        uri: request.url,
        message: 'Network request failed.',
        cause: error,
      );
    }
  }

  Map<String, String> _headers([Map<String, String>? operationHeaders]) {
    final headers = <String, String>{...config.headers};
    if (config.username != null) {
      final credentials = base64.encode(
        utf8.encode('${config.username}:${config.password}'),
      );
      headers['authorization'] = 'Basic $credentials';
    }
    if (operationHeaders != null) headers.addAll(operationHeaders);
    return headers;
  }

  static const _noCacheHeaders = <String, String>{
    'cache-control': 'no-cache, no-store, max-age=0',
    'pragma': 'no-cache',
  };

  Uri _resolvePath(String path) {
    final segments = _pathSegments(path, argumentName: 'path');

    final encodedPath = segments.map(Uri.encodeComponent).join('/');
    final remoteUri = config.baseUri.resolve(encodedPath);
    final proxyUri = config.proxyUri;
    if (proxyUri == null) return remoteUri;
    return proxyUri.replace(
      queryParameters: <String, String>{
        ...proxyUri.queryParameters,
        'url': remoteUri.toString(),
      },
    );
  }

  List<String> _pathSegments(String path, {required String argumentName}) {
    final normalized = path.replaceAll('\\', '/');
    final segments = normalized
        .split('/')
        .where((segment) => segment.isNotEmpty)
        .toList(growable: false);

    if (segments.isEmpty) {
      throw ArgumentError.value(path, argumentName, 'Must not be empty.');
    }
    if (segments.any((segment) => segment == '.' || segment == '..')) {
      throw ArgumentError.value(
        path,
        argumentName,
        'Relative path segments "." and ".." are not allowed.',
      );
    }

    return segments;
  }

  WebDavException _httpException(
    String operation,
    Uri uri,
    http.Response response,
  ) {
    const maximumBodyLength = 2048;
    final decoded = utf8.decode(response.bodyBytes, allowMalformed: true);
    final body = decoded.length <= maximumBodyLength
        ? decoded
        : '${decoded.substring(0, maximumBodyLength)}…';
    return WebDavException(
      operation: operation,
      uri: uri,
      statusCode: response.statusCode,
      message: response.reasonPhrase ?? 'Unexpected HTTP response.',
      responseBody: body.isEmpty ? null : body,
    );
  }

  String _resourceName(Uri uri) {
    final segments = uri.path
        .split('/')
        .where((segment) => segment.isNotEmpty)
        .toList(growable: false);
    if (segments.isEmpty) return '';
    return Uri.decodeComponent(segments.last);
  }

  int? _parseContentLength(Map<String, String> headers) {
    final value = headers['content-length'];
    if (value == null) return null;
    return int.tryParse(value.trim());
  }

  String _normalizedResourcePath(Uri uri) {
    final path = uri.path.replaceAll(RegExp(r'/+$'), '');
    return path.isEmpty ? '/' : path;
  }
}
