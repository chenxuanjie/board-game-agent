/// Streaming response returned by a WebDAV file download.
final class WebDavReadStream {
  const WebDavReadStream({
    required this.bytes,
    required this.statusCode,
    required this.headers,
    required this.contentLength,
  });

  final Stream<List<int>> bytes;
  final int statusCode;
  final Map<String, String> headers;
  final int? contentLength;

  String? get contentType => headers['content-type'];
  String? get etag => headers['etag'];
  bool get acceptsRanges => headers['accept-ranges'] == 'bytes';
}
