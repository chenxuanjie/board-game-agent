/// Metadata returned by a successful WebDAV HEAD request.
final class WebDavHeadResult {
  const WebDavHeadResult({
    required this.statusCode,
    required this.headers,
    required this.contentLength,
  });

  final int statusCode;
  final Map<String, String> headers;
  final int? contentLength;

  String? get contentType => headers['content-type'];
  String? get etag => headers['etag'];
  String? get lastModified => headers['last-modified'];
}
