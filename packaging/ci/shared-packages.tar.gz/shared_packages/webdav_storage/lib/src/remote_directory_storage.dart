/// A remote resource returned by a directory enumeration.
final class RemoteResource {
  const RemoteResource({
    required this.name,
    required this.isCollection,
    this.etag,
  });

  /// The final path segment, decoded from the WebDAV `href`.
  final String name;

  final bool isCollection;
  final String? etag;
}

/// Optional directory-enumeration capability for remote file stores.
abstract interface class RemoteDirectoryStorage {
  Future<List<RemoteResource>> list(String path);
}
