/// Optional capability for deleting individual remote files.
abstract interface class RemoteDeleteStorage {
  /// Deletes [path]. An already absent file is treated as success.
  Future<void> delete(String path);
}
