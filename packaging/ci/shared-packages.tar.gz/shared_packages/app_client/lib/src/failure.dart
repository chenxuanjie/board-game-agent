class AppClientFailure implements Exception {
  const AppClientFailure(this.message, {this.status, this.code});
  final String message;
  final int? status;
  final String? code;
  @override
  String toString() => message;
}
